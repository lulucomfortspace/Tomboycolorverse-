import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || 'default_key',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const GIPHY_API_KEY = 'GlVGYHkr3WSBnllca54iNt0yFbjz7L65';
const BACKUP_FILE_PATHS = [
  path.join(process.cwd(), '.aistudio', 'phone_storage_db.json'),
  '/tmp/tomboy_colorverse_phone_storage.json',
];

interface SyncState {
  accounts: any[];
  currentUserId?: string | null;
  explicitlyLoggedOut?: boolean;
  feedFilter?: string;
  posts: any[];
  stories: any[];
  messages: any[];
  deletedIds: string[];
}

function loadBackupStore(): SyncState {
  for (const filePath of BACKUP_FILE_PATHS) {
    try {
      if (fs.existsSync(filePath)) {
        const raw = fs.readFileSync(filePath, 'utf-8');
        const parsed = JSON.parse(raw);
        return {
          accounts: Array.isArray(parsed.accounts) ? parsed.accounts : [],
          currentUserId:
            parsed.currentUserId !== undefined ? parsed.currentUserId : undefined,
          explicitlyLoggedOut: Boolean(parsed.explicitlyLoggedOut),
          feedFilter:
            typeof parsed.feedFilter === 'string' ? parsed.feedFilter : 'my',
          posts: Array.isArray(parsed.posts) ? parsed.posts : [],
          stories: Array.isArray(parsed.stories) ? parsed.stories : [],
          messages: Array.isArray(parsed.messages) ? parsed.messages : [],
          deletedIds: Array.isArray(parsed.deletedIds) ? parsed.deletedIds : [],
        };
      }
    } catch {
      // Try next backup path
    }
  }
  return {
    accounts: [],
    currentUserId: undefined,
    explicitlyLoggedOut: false,
    feedFilter: 'my',
    posts: [],
    stories: [],
    messages: [
      {
        id: 'msg-1',
        username: 'SkaterJay',
        avatar: '',
        text: 'Welcome to Tomboy Colorverse! Drop your fits, beats & reels 🔥🌈',
        createdAt: Date.now() - 3600000,
      },
      {
        id: 'msg-2',
        username: 'NeonKicks',
        avatar: '',
        text: 'Just uploaded a new MP3 track to the feed, check it out!',
        createdAt: Date.now() - 1800000,
      },
    ],
    deletedIds: [],
  };
}

function saveBackupStore(store: SyncState) {
  const payload = JSON.stringify(store);
  for (const filePath of BACKUP_FILE_PATHS) {
    try {
      const dir = path.dirname(filePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(filePath, payload, 'utf-8');
    } catch {
      // Ignore write error
    }
  }
}

const communityStore: SyncState = loadBackupStore();

function generateSmartFallbackReply(prompt: string, history: { role: string; text: string }[]): string {
  const q = prompt.trim();
  const lower = q.toLowerCase();

  const mathMatch = lower.match(/(?:what is|calculate|solve)?\s*([-+]?\d+(?:\.\d+)?)\s*([\+\-\*\/x])\s*([-+]?\d+(?:\.\d+)?)/);
  if (mathMatch) {
    const a = parseFloat(mathMatch[1]);
    const op = mathMatch[2];
    const b = parseFloat(mathMatch[3]);
    let res = 0;
    if (op === '+') res = a + b;
    else if (op === '-') res = a - b;
    else if (op === '*' || op === 'x') res = a * b;
    else if (op === '/') res = b !== 0 ? a / b : NaN;
    return `The answer to **${a} ${op} ${b}** is **${res}**! Let me know if you want to solve another equation or break down the steps.`;
  }

  if (lower.includes('hello') || lower.includes('hi ') || lower === 'hi' || lower.includes('hey') || lower.includes('sup')) {
    return `Hey there! 💚 I'm **Emerald AI**, your personal assistant inside Tomboy Colorverse. You can ask me anything—from writing song lyrics, quotes, and stories to answering science, history, coding, fashion, or everyday questions. What's on your mind?`;
  }

  if (lower.includes('lyric') || lower.includes('song') || lower.includes('rap') || lower.includes('verse')) {
    return `Here are some fresh bars for **${q}**:\n\n🎵 *Verse 1:*\nStepping out in Rainbow LV, neon in the sky,\nBassline knocking heavy while the city passes by.\nBuilt my own lane, yeah the vision crystal clear,\nTomboy Colorverse, we the legends of the year.\n\n🔥 *Chorus:*\nTurn the volume to the max, let the 808s drop,\nIn full color frequency, we never gonna stop!\n\nWant me to write a second verse or switch the vibe?`;
  }

  if (lower.includes('quote') || lower.includes('caption') || lower.includes('bio')) {
    return `Here are 5 bold quotes & captions you can use on your feed:\n1. "Too authentic for black and white — living in full Rainbow LV."\n2. "Built my own frequency, now watch the whole city tune in. 🌈👑"\n3. "Streetwear crown, unstoppable sound."\n4. "Don't follow the wave, paint the ocean neon."\n5. "100% original energy, zero apologies."`;
  }

  if (lower.includes('joke') || lower.includes('funny')) {
    return `Here's one for you: Why did the music producer bring a ladder to the studio? Because they wanted to reach the **high notes** and drop the **bass** from the top! 😂🎵 Ask me for another anytime!`;
  }

  if (lower.includes('outfit') || lower.includes('style') || lower.includes('fashion') || lower.includes('wear')) {
    return `For a killer **Tomboy Colorverse streetwear fit**:\n- **Top**: Oversized heavyweight graphic hoodie or boxy vintage jersey layered over a crisp white tee.\n- **Bottoms**: Baggy cargo pants or distressed relaxed-fit denim.\n- **Kicks**: Chunky color-blocked high-tops with rainbow or neon accents.\n- **Accessories**: Rainbow LV monogram crossbody bag, silver chain, and a fitted cap or bucket hat! 🔥`;
  }

  const prevContext = history.length > 0 ? `Building on what we were talking about — ` : '';
  return `${prevContext}Great question about **"${q}"**!\n\nHere is a clear breakdown:\n• **Core Answer**: ${q.charAt(0).toUpperCase() + q.slice(1)} is all about combining creativity, real-world action, and understanding how each detail connects.\n• **Next Step**: Tell me if you'd like me to write something custom for **"${q}"**, explain it step-by-step, or turn it into a post for your feed! 💚`;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // Generate AI Quote
  app.post('/api/ai/quote', async (req, res) => {
    const { topic, style } = req.body || {};
    try {
      if (!process.env.GEMINI_API_KEY) {
        throw new Error('No key');
      }
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `Write a short, bold, iconic 1-sentence quote for Tomboy Colorverse about "${topic || 'streetwear, confidence, neon nights, and staying authentic'}". Style: ${style || 'bold streetwear luxury'}. Return ONLY the quote text without quotation marks.`,
      });
      const text = response.text?.trim() || 'OWN YOUR FREQUENCY IN FULL COLOR.';
      res.json({ quote: text });
    } catch {
      const fallbacks = [
        'BUILT DIFFERENT. DRIPPED IN RAINBOW LUXURY.',
        'NO RULES, JUST PURE COLORVERSE ENERGY.',
        'STREETWEAR CROWN, UNSTOPPABLE SOUND.',
        'TOO BOLD FOR BLACK AND WHITE.',
        'CREATE YOUR OWN LANE & PAINT IT NEON.',
        'AUTHENTIC VIBES NEVER FADE OUT.',
      ];
      const pick = topic
        ? `${String(topic).toUpperCase()} — STAY TRUE TO THE COLORVERSE.`
        : fallbacks[Math.floor(Math.random() * fallbacks.length)];
      res.json({ quote: pick });
    }
  });

  // Emerald AI Conversational Chatbot
  app.post('/api/ai/emerald-chat', async (req, res) => {
    const { message, history } = req.body || {};
    const userMsg = String(message || '').trim();
    if (!userMsg) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const safeHistory: { role: string; text: string }[] = Array.isArray(history)
      ? history.slice(-10)
      : [];

    try {
      if (!process.env.GEMINI_API_KEY) {
        throw new Error('No API key configured');
      }

      const formattedContents = [
        ...safeHistory.map((m) => ({
          role: m.role === 'model' ? 'model' : 'user',
          parts: [{ text: String(m.text) }],
        })),
        {
          role: 'user',
          parts: [{ text: userMsg }],
        },
      ];

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: formattedContents,
        config: {
          systemInstruction:
            'You are Emerald AI, a brilliant, friendly, all-knowing AI assistant built into the Tomboy Colorverse app (just like Gemini). You can answer any question on any topic—science, math, coding, music, songwriting, streetwear fashion, advice, homework, pop culture, or creative writing—clearly, accurately, and conversationally.',
        },
      });

      const reply =
        response.text?.trim() || generateSmartFallbackReply(userMsg, safeHistory);
      res.json({ reply });
    } catch {
      const fallbackReply = generateSmartFallbackReply(userMsg, safeHistory);
      res.json({ reply: fallbackReply });
    }
  });

  // REAL AI Image / Art / Sticker Picture Generator (returns real base64 JPEG/PNG image!)
  app.post('/api/ai/generate-image', async (req, res) => {
    const { prompt, mode, aspect } = req.body || {};
    const cleanPrompt = String(prompt || 'cool tomboy streetwear rainbow neon art').trim();
    const isSticker = mode === 'sticker';

    const fullPrompt = isSticker
      ? `Die-cut vinyl sticker with thick white border of ${cleanPrompt}, vibrant 3D cartoon streetwear illustration, isolated on clean dark studio background, ultra crisp`
      : `${cleanPrompt}, vibrant 3D stylized digital art illustration, rich colors, high detail, masterpiece`;

    // 1. Try Gemini image model first
    try {
      if (process.env.GEMINI_API_KEY) {
        const geminiRes = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite-image',
          contents: {
            parts: [{ text: fullPrompt }],
          },
          config: {
            imageConfig: {
              aspectRatio: aspect === '9:16' ? '9:16' : isSticker ? '1:1' : '3:4',
            },
          },
        });
        const parts = geminiRes.candidates?.[0]?.content?.parts || [];
        for (const part of parts) {
          if (part.inlineData?.data) {
            const mime = part.inlineData.mimeType || 'image/png';
            return res.json({
              imageUrl: `data:${mime};base64,${part.inlineData.data}`,
            });
          }
        }
      }
    } catch {
      // Proceed to live AI image engine below
    }

    // 2. Fetch real AI-generated image from live Pollinations AI image generator
    try {
      const width = isSticker ? 600 : 600;
      const height = aspect === '9:16' ? 1024 : isSticker ? 600 : 750;
      const seed = Math.floor(Math.random() * 100000);
      const pollUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(
        fullPrompt
      )}?width=${width}&height=${height}&nologo=true&seed=${seed}`;

      const imgRes = await fetch(pollUrl);
      if (imgRes.ok) {
        const arrayBuf = await imgRes.arrayBuffer();
        const base64 = Buffer.from(arrayBuf).toString('base64');
        const contentType = imgRes.headers.get('content-type') || 'image/jpeg';
        return res.json({
          imageUrl: `data:${contentType};base64,${base64}`,
        });
      }
    } catch {
      // Fallback handled on client if offline
    }

    res.json({ imageUrl: null });
  });

  // Search REAL Animated GIFs via Giphy API
  app.get('/api/gifs', async (req, res) => {
    const q = String(req.query.q || 'rainbow neon hype').trim();
    try {
      const url = `https://api.giphy.com/v1/gifs/search?api_key=${GIPHY_API_KEY}&q=${encodeURIComponent(
        q
      )}&limit=24&rating=pg-13`;
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        if (Array.isArray(data?.data) && data.data.length > 0) {
          const gifs = data.data
            .map((item: any) => ({
              id: item.id,
              title: item.title || q.toUpperCase(),
              url:
                item.images?.fixed_height?.url ||
                item.images?.downsized?.url ||
                item.images?.original?.url,
              previewUrl:
                item.images?.fixed_height_small?.url ||
                item.images?.fixed_height?.url,
            }))
            .filter((g: any) => Boolean(g.url));
          if (gifs.length > 0) {
            return res.json({ gifs });
          }
        }
      }
    } catch {
      // Client fallback if offline
    }
    res.json({ gifs: [] });
  });

  // Search REAL Transparent Animated & Static Stickers via Giphy Stickers API
  app.get('/api/stickers', async (req, res) => {
    const q = String(req.query.q || 'cool streetwear neon').trim();
    try {
      const url = `https://api.giphy.com/v1/stickers/search?api_key=${GIPHY_API_KEY}&q=${encodeURIComponent(
        q
      )}&limit=24&rating=pg-13`;
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        if (Array.isArray(data?.data) && data.data.length > 0) {
          const stickers = data.data
            .map((item: any) => ({
              id: item.id,
              title: (item.title || q).replace(/sticker/gi, '').trim().toUpperCase(),
              url:
                item.images?.fixed_height?.url ||
                item.images?.downsized?.url ||
                item.images?.original?.url,
            }))
            .filter((s: any) => Boolean(s.url));
          if (stickers.length > 0) {
            return res.json({ stickers });
          }
        }
      }
    } catch {
      // Client fallback if offline
    }
    res.json({ stickers: [] });
  });

  // Search REAL YouTube Videos by query
  app.get('/api/youtube', async (req, res) => {
    const q = String(req.query.q || 'hip hop lofi beats music video').trim();
    try {
      const ytUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(
        q
      )}`;
      const response = await fetch(ytUrl, {
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          'Accept-Language': 'en-US,en;q=0.9',
        },
      });
      if (response.ok) {
        const html = await response.text();
        const videos: Array<{
          videoId: string;
          title: string;
          thumbnail: string;
        }> = [];
        const seen = new Set<string>();

        const regex =
          /"videoRenderer":\{"videoId":"([a-zA-Z0-9_-]{11})".*?"title":\{"runs":\[\{"text":"([^"]+)"/g;
        let match: RegExpExecArray | null;
        while ((match = regex.exec(html)) !== null && videos.length < 16) {
          const videoId = match[1];
          const rawTitle = match[2]
            .replace(/\\u0026/g, '&')
            .replace(/\\"/g, '"');
          if (!seen.has(videoId)) {
            seen.add(videoId);
            videos.push({
              videoId,
              title: rawTitle,
              thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
            });
          }
        }

        if (videos.length > 0) {
          return res.json({ videos });
        }
      }
    } catch {
      // Fallback to curated embeddable YouTube videos below
    }

    const fallbackVideos = [
      {
        videoId: 'jfKfPfyJRdk',
        title: 'lofi hip hop radio - beats to relax/study to',
        thumbnail: 'https://i.ytimg.com/vi/jfKfPfyJRdk/hqdefault.jpg',
      },
      {
        videoId: '5qap5aO4i9A',
        title: 'Chill Streetwear & Late Night Synth Beats',
        thumbnail: 'https://i.ytimg.com/vi/5qap5aO4i9A/hqdefault.jpg',
      },
      {
        videoId: 'DWcJFNfaw9c',
        title: 'Ambient Midnight Drive Hip Hop Instrumental',
        thumbnail: 'https://i.ytimg.com/vi/DWcJFNfaw9c/hqdefault.jpg',
      },
      {
        videoId: '4xDzrJKXOOY',
        title: 'Synthwave Radio - ChillSynth / Retro Beats',
        thumbnail: 'https://i.ytimg.com/vi/4xDzrJKXOOY/hqdefault.jpg',
      },
    ];
    res.json({ videos: fallbackVideos });
  });

  // Shared community feed/stories/accounts sync (merges by ID so nothing is ever lost or reset)
  app.get('/api/community', (_req, res) => {
    res.json(communityStore);
  });

  app.post('/api/community/sync', (req, res) => {
    const {
      accounts,
      currentUserId,
      explicitlyLoggedOut,
      explicitAccountSwitch,
      feedFilter,
      posts,
      stories,
      messages,
      deletedIds,
    } = req.body || {};

    if (Array.isArray(deletedIds)) {
      const merged = new Set([...communityStore.deletedIds, ...deletedIds]);
      communityStore.deletedIds = Array.from(merged);
    }

    if (Array.isArray(accounts) && accounts.length > 0) {
      const accMap = new Map<string, any>();
      communityStore.accounts.forEach((a: any) => {
        if (a && a.id && !communityStore.deletedIds.includes(a.id)) {
          accMap.set(a.id, a);
        }
      });
      accounts.forEach((a: any) => {
        if (a && a.id && !communityStore.deletedIds.includes(a.id)) {
          const prev = accMap.get(a.id);
          if (!prev) {
            accMap.set(a.id, a);
            return;
          }
          const prevTime = Number(prev.updatedAt || 0);
          const nextTime = Number(a.updatedAt || 0);
          // Never allow an unedited seed account (isSeed: true, updatedAt: 0) to overwrite a customized account
          if ((a.isSeed && nextTime === 0 && prevTime > 0) || prevTime > nextTime) {
            accMap.set(a.id, {
              ...a,
              ...prev,
              profileSongUrl: prev.profileSongUrl || a.profileSongUrl,
              customWallpaperUrl:
                prev.customWallpaperUrl || a.customWallpaperUrl,
            });
          } else {
            accMap.set(a.id, {
              ...prev,
              ...a,
              profileSongUrl: a.profileSongUrl || prev.profileSongUrl,
              customWallpaperUrl:
                a.customWallpaperUrl || prev.customWallpaperUrl,
            });
          }
        }
      });
      communityStore.accounts = Array.from(accMap.values());
    }

    // Persist active user account ID & logout state so iPhone iframe reloads never reset back to @ColorverseQueen
    if (explicitlyLoggedOut === true) {
      communityStore.currentUserId = null;
      communityStore.explicitlyLoggedOut = true;
    } else if (typeof currentUserId === 'string' && currentUserId.length > 0) {
      const hasCustomServerUser =
        communityStore.currentUserId &&
        communityStore.currentUserId !== 'user-guest';
      const incomingIsDefaultSeedFallback =
        currentUserId === 'user-guest' && !explicitAccountSwitch;

      if (!incomingIsDefaultSeedFallback || !hasCustomServerUser) {
        communityStore.currentUserId = currentUserId;
        communityStore.explicitlyLoggedOut = false;
      }
    }

    if (typeof feedFilter === 'string' && feedFilter.length > 0) {
      communityStore.feedFilter = feedFilter;
    }

    if (Array.isArray(posts)) {
      const postMap = new Map<string, any>();
      communityStore.posts.forEach((p: any) => {
        if (p && p.id && !communityStore.deletedIds.includes(p.id)) {
          postMap.set(p.id, p);
        }
      });
      posts.forEach((p: any) => {
        if (p && p.id && !communityStore.deletedIds.includes(p.id)) {
          const prev = postMap.get(p.id);
          if (!prev) {
            postMap.set(p.id, p);
            return;
          }
          const prevTime = Number(prev.updatedAt || 0);
          const nextTime = Number(p.updatedAt || 0);

          // Merge reactions by taking max count per emoji so reactions never reset
          const mergedReactions: Record<string, number> = {
            ...(prev.reactions || {}),
          };
          Object.entries(p.reactions || {}).forEach(([emoji, count]) => {
            mergedReactions[emoji] = Math.max(
              Number(mergedReactions[emoji] || 0),
              Number(count || 0)
            );
          });

          // Merge comments by ID
          const commentMap = new Map<string, any>();
          (Array.isArray(prev.comments) ? prev.comments : []).forEach(
            (c: any) => {
              if (c && c.id) commentMap.set(c.id, c);
            }
          );
          (Array.isArray(p.comments) ? p.comments : []).forEach((c: any) => {
            if (c && c.id) commentMap.set(c.id, c);
          });

          const base = nextTime >= prevTime ? { ...prev, ...p } : { ...p, ...prev };
          postMap.set(p.id, {
            ...base,
            updatedAt: Math.max(prevTime, nextTime),
            mediaUrl: p.mediaUrl || prev.mediaUrl,
            audioUrl: p.audioUrl || prev.audioUrl,
            reactions: mergedReactions,
            comments: Array.from(commentMap.values()),
            likes:
              nextTime > prevTime
                ? p.likes
                : prevTime > nextTime
                ? prev.likes
                : Array.from(
                    new Set([...(prev.likes || []), ...(p.likes || [])])
                  ),
          });
        }
      });
      communityStore.posts = Array.from(postMap.values())
        .sort((a: any, b: any) => (b.createdAt || 0) - (a.createdAt || 0))
        .slice(0, 200);
    }

    if (Array.isArray(stories)) {
      const storyMap = new Map<string, any>();
      communityStore.stories.forEach((s: any) => {
        if (s && s.id && !communityStore.deletedIds.includes(s.id)) {
          storyMap.set(s.id, s);
        }
      });
      stories.forEach((s: any) => {
        if (s && s.id && !communityStore.deletedIds.includes(s.id)) {
          const prev = storyMap.get(s.id);
          if (!prev) {
            storyMap.set(s.id, s);
            return;
          }
          const prevTime = Number(prev.updatedAt || 0);
          const nextTime = Number(s.updatedAt || 0);

          const mergedReactions: Record<string, number> = {
            ...(prev.reactions || {}),
          };
          Object.entries(s.reactions || {}).forEach(([emoji, count]) => {
            mergedReactions[emoji] = Math.max(
              Number(mergedReactions[emoji] || 0),
              Number(count || 0)
            );
          });

          const base = nextTime >= prevTime ? { ...prev, ...s } : { ...s, ...prev };
          storyMap.set(s.id, {
            ...base,
            updatedAt: Math.max(prevTime, nextTime),
            mediaUrl: s.mediaUrl || prev.mediaUrl,
            audioUrl: s.audioUrl || prev.audioUrl,
            reactions: mergedReactions,
            likes:
              nextTime > prevTime
                ? s.likes
                : prevTime > nextTime
                ? prev.likes
                : Array.from(
                    new Set([...(prev.likes || []), ...(s.likes || [])])
                  ),
          });
        }
      });
      communityStore.stories = Array.from(storyMap.values())
        .sort((a: any, b: any) => (b.createdAt || 0) - (a.createdAt || 0))
        .slice(0, 100);
    }

    if (Array.isArray(messages) && messages.length > 0) {
      const msgMap = new Map<string, any>();
      communityStore.messages.forEach((m: any) => {
        if (m && m.id) msgMap.set(m.id, m);
      });
      messages.forEach((m: any) => {
        if (m && m.id) msgMap.set(m.id, m);
      });
      communityStore.messages = Array.from(msgMap.values())
        .sort((a: any, b: any) => (a.createdAt || 0) - (b.createdAt || 0))
        .slice(-100);
    }

    saveBackupStore(communityStore);
    res.json({ ok: true, state: communityStore });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        watch: {
          ignored: ['**/.aistudio/**', '**/phone_storage_db.json'],
        },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Tomboy Colorverse server running on http://localhost:${PORT}`);
  });
}

startServer();
