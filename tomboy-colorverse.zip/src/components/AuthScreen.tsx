import React, { useState } from 'react';
import { AvatarCustomizationConfig, UserAccount } from '../types';
import {
  createSynthBeatWavUrl,
  DEFAULT_AVATAR_CONFIG,
  getRainbowLVWallpaperSvg,
  PRESET_PROFILE_SONGS,
  renderCustomAvatarSvg,
} from '../utils/mediaEngine';
import { fileToDataUrl } from '../utils/phoneStorage';
import { AvatarCustomizerModal } from './AvatarCustomizerModal';
import {
  Camera,
  UserPlus,
  LogIn,
  Sparkles,
  Trash2,
  Music,
} from 'lucide-react';

interface AuthScreenProps {
  accounts: UserAccount[];
  onLogin: (account: UserAccount) => void;
  onCreateAccount: (account: UserAccount) => void;
  onDeleteAccount?: (accountId: string) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  accounts,
  onLogin,
  onCreateAccount,
  onDeleteAccount,
}) => {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [bio, setBio] = useState('');
  const [avatarConfig, setAvatarConfig] = useState<AvatarCustomizationConfig>(
    DEFAULT_AVATAR_CONFIG
  );
  const [avatarUrl, setAvatarUrl] = useState<string>(() =>
    renderCustomAvatarSvg(DEFAULT_AVATAR_CONFIG)
  );
  const [showAvatarModal, setShowAvatarModal] = useState(false);
  const [profileSongUrl, setProfileSongUrl] = useState<string>(() =>
    createSynthBeatWavUrl(
      PRESET_PROFILE_SONGS[0].freq,
      PRESET_PROFILE_SONGS[0].durationSec
    )
  );
  const [profileSongTitle, setProfileSongTitle] = useState<string>(
    PRESET_PROFILE_SONGS[0].title
  );
  const [wallpaperMode, setWallpaperMode] = useState<
    'lv-light' | 'lv-dark' | 'midnight'
  >('lv-light');
  const [error, setError] = useState('');

  const bgPattern = getRainbowLVWallpaperSvg('dark');

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const dataUrl = await fileToDataUrl(file);
    setAvatarUrl(dataUrl);
  };

  const handleProfileSongUpload = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const dataUrl = await fileToDataUrl(file);
    const cleanName = file.name.replace(/\.[^/.]+$/, '');
    setProfileSongUrl(dataUrl);
    setProfileSongTitle(cleanName || 'My Profile Anthem');
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const cleanName = username.trim();
    if (!cleanName) {
      setError('Please enter your username.');
      return;
    }

    const existing = accounts.find(
      (a) => a.username.toLowerCase() === cleanName.toLowerCase()
    );
    if (existing) {
      onLogin(existing);
    } else {
      const newAcc: UserAccount = {
        id: `user-${Date.now()}`,
        username: cleanName,
        password: password || '123',
        avatar: renderCustomAvatarSvg(DEFAULT_AVATAR_CONFIG),
        avatarConfig: DEFAULT_AVATAR_CONFIG,
        bio: 'Tomboy Colorverse Creator 🌈',
        wallpaperMode: 'lv-light',
        profileSongUrl,
        profileSongTitle,
        createdAt: Date.now(),
      };
      onCreateAccount(newAcc);
    }
  };

  const handleSignupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const cleanName = username.trim();
    if (!cleanName) {
      setError('Please choose a username for your account.');
      return;
    }
    const existing = accounts.find(
      (a) => a.username.toLowerCase() === cleanName.toLowerCase()
    );
    if (existing) {
      onLogin(existing);
      return;
    }

    const newAcc: UserAccount = {
      id: `user-${Date.now()}`,
      username: cleanName,
      password: password || '123',
      avatar: avatarUrl || renderCustomAvatarSvg(avatarConfig),
      avatarConfig,
      bio: bio.trim() || `${cleanName}'s Personal Colorverse Feed 🌈👑`,
      wallpaperMode,
      profileSongUrl,
      profileSongTitle,
      profileSongEnabled: true,
      createdAt: Date.now(),
    };

    onCreateAccount(newAcc);
  };

  return (
    <div
      className="min-h-screen w-full flex flex-col justify-between p-5 relative overflow-y-auto"
      style={{
        backgroundImage: `url("${bgPattern}")`,
        backgroundSize: '280px 280px',
        backgroundRepeat: 'repeat',
      }}
    >
      <div className="fixed inset-0 bg-black/75 backdrop-blur-[2px] pointer-events-none" />

      <div className="relative z-10 w-full max-w-md mx-auto my-auto py-6">
        {/* Brand Lockup */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="story-rainbow-circle w-20 h-20 mb-4">
            <div className="story-rainbow-inner flex items-center justify-center bg-gradient-to-br from-pink-500 via-orange-400 to-amber-300">
              <span className="font-lv font-black text-3xl text-black tracking-tighter">
                LV
              </span>
            </div>
          </div>
          <h1 className="font-lv font-black text-3xl sm:text-4xl tracking-wider rainbow-lv-text">
            TOMBOY COLORVERSE
          </h1>
          <p className="text-xs sm:text-sm text-zinc-300 mt-1.5 max-w-xs">
            Create your account, customize your avatar, add your profile song,
            and build your own personal feed saved on your phone.
          </p>
        </div>

        {/* Top Mode Tabs: Log In vs Sign Up */}
        <div className="grid grid-cols-2 gap-2 bg-[#121216]/90 p-1.5 rounded-2xl border border-white/15 mb-4">
          <button
            type="button"
            onClick={() => {
              setError('');
              setMode('login');
            }}
            className={`h-11 rounded-xl font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 transition ${
              mode === 'login'
                ? 'bg-gradient-to-r from-fuchsia-500 via-purple-500 to-cyan-400 text-black shadow-lg'
                : 'text-zinc-300 hover:text-white'
            }`}
          >
            <LogIn className="w-4 h-4" />
            Log In
          </button>
          <button
            type="button"
            onClick={() => {
              setError('');
              setMode('signup');
            }}
            className={`h-11 rounded-xl font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 transition ${
              mode === 'signup'
                ? 'bg-gradient-to-r from-emerald-400 via-cyan-400 to-fuchsia-500 text-black shadow-lg'
                : 'text-zinc-300 hover:text-white'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            Sign Up / Create
          </button>
        </div>

        {mode === 'login' ? (
          <div className="bg-[#121216]/95 border border-white/15 rounded-3xl p-6 shadow-2xl space-y-5">
            <h2 className="text-lg font-extrabold text-center text-white">
              Log Into Your Feed
            </h2>

            {error && (
              <div className="bg-red-500/20 border border-red-500/40 text-red-200 text-xs font-medium px-3.5 py-2.5 rounded-xl text-center">
                {error}
              </div>
            )}

            <form onSubmit={handleLoginSubmit} className="space-y-3.5">
              <div>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter Username"
                  className="w-full h-12 px-4 rounded-xl bg-zinc-900/90 border border-white/15 text-white placeholder-zinc-400 text-sm focus:outline-none focus:border-pink-500"
                />
              </div>
              <div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Password"
                  className="w-full h-12 px-4 rounded-xl bg-zinc-900/90 border border-white/15 text-white placeholder-zinc-400 text-sm focus:outline-none focus:border-pink-500"
                />
              </div>
              <button
                type="submit"
                className="w-full h-12 rounded-xl bg-gradient-to-r from-fuchsia-500 via-purple-500 to-cyan-400 text-black font-extrabold text-base flex items-center justify-center gap-2 shadow-lg active:scale-[0.99] transition"
              >
                <LogIn className="w-5 h-5" />
                Log In
              </button>
            </form>

            {/* Saved Accounts on Phone Storage */}
            {accounts.length > 0 && (
              <div className="pt-3 border-t border-white/10 space-y-2.5">
                <p className="text-xs font-extrabold text-zinc-400 text-center">
                  Saved Accounts on Phone Storage (Tap to Open Feed):
                </p>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {accounts.map((acc) => (
                    <div
                      key={acc.id}
                      className="flex items-center justify-between gap-2 bg-zinc-900/90 hover:bg-zinc-800 border border-white/10 rounded-2xl px-3 py-2 transition"
                    >
                      <button
                        type="button"
                        onClick={() => onLogin(acc)}
                        className="flex items-center gap-3 flex-1 text-left min-w-0"
                      >
                        <div className="story-rainbow-circle w-10 h-10 shrink-0">
                          <div className="story-rainbow-inner">
                            <img
                              src={acc.avatar}
                              alt={acc.username}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          </div>
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-extrabold text-white truncate">
                            @{acc.username}
                          </p>
                          <p className="text-[11px] text-zinc-400 truncate">
                            {acc.profileSongTitle
                              ? `🎵 ${acc.profileSongTitle}`
                              : acc.bio || 'Personal Feed saved on phone'}
                          </p>
                        </div>
                      </button>

                      {onDeleteAccount && accounts.length > 1 && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteAccount(acc.id);
                          }}
                          title="Remove account from phone"
                          className="w-8 h-8 rounded-full bg-zinc-800 hover:bg-red-500/30 text-zinc-400 hover:text-red-300 flex items-center justify-center shrink-0"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  setError('');
                  setMode('signup');
                }}
                className="w-full h-12 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-md transition"
              >
                <UserPlus className="w-4 h-4" />
                Create New Account (Sign Up)
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-[#121216]/95 border border-white/15 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-extrabold text-white">
                Sign Up &amp; Create Your Account
              </h2>
              <span className="text-xs font-bold text-pink-400 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                Own Feed
              </span>
            </div>

            {error && (
              <div className="bg-red-500/20 border border-red-500/40 text-red-200 text-xs font-medium px-3.5 py-2.5 rounded-xl text-center">
                {error}
              </div>
            )}

            <form onSubmit={handleSignupSubmit} className="space-y-3.5">
              {/* Customize Avatar or Upload Photo */}
              <div className="flex flex-col items-center gap-2">
                <div className="story-rainbow-circle w-24 h-24">
                  <div className="story-rainbow-inner flex items-center justify-center bg-zinc-900">
                    <img
                      src={avatarUrl}
                      alt="New Avatar"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap justify-center">
                  <button
                    type="button"
                    onClick={() => setShowAvatarModal(true)}
                    className="h-9 px-3.5 rounded-full bg-gradient-to-r from-pink-500 via-amber-400 to-cyan-400 text-black font-extrabold text-xs flex items-center gap-1.5 shadow"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    Customize Own Avatar
                  </button>
                  <label className="h-9 px-3.5 rounded-full bg-zinc-800 hover:bg-zinc-700 border border-white/15 text-cyan-300 font-extrabold text-xs flex items-center gap-1.5 cursor-pointer">
                    <Camera className="w-3.5 h-3.5" />
                    Upload Photo
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleAvatarUpload}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <div>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Choose Your Username"
                  className="w-full h-12 px-4 rounded-xl bg-zinc-900/90 border border-white/15 text-white placeholder-zinc-400 text-sm focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Create Password"
                  className="w-full h-12 px-4 rounded-xl bg-zinc-900/90 border border-white/15 text-white placeholder-zinc-400 text-sm focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <input
                  type="text"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Your Bio (optional)"
                  className="w-full h-12 px-4 rounded-xl bg-zinc-900/90 border border-white/15 text-white placeholder-zinc-400 text-sm focus:outline-none focus:border-cyan-400"
                />
              </div>

              {/* Optional Profile Song on Sign Up */}
              <div className="bg-zinc-900/80 border border-white/10 rounded-2xl p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-pink-400 flex items-center gap-1.5">
                    <Music className="w-3.5 h-3.5" />
                    Profile Song: {profileSongTitle}
                  </span>
                  <label className="text-[11px] font-extrabold text-cyan-400 cursor-pointer hover:underline">
                    Upload MP3
                    <input
                      type="file"
                      accept="audio/*,.mp3,.m4a,.wav"
                      onChange={handleProfileSongUpload}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* Choose Feed Wallpaper Theme */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-zinc-400">
                  Choose Your Feed Wallpaper:
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setWallpaperMode('lv-light')}
                    className={`h-9 rounded-xl text-[11px] font-extrabold border ${
                      wallpaperMode === 'lv-light'
                        ? 'bg-white text-black border-pink-500'
                        : 'bg-zinc-900 text-zinc-300 border-white/10'
                    }`}
                  >
                    LV White
                  </button>
                  <button
                    type="button"
                    onClick={() => setWallpaperMode('lv-dark')}
                    className={`h-9 rounded-xl text-[11px] font-extrabold border ${
                      wallpaperMode === 'lv-dark'
                        ? 'bg-pink-500 text-white border-white'
                        : 'bg-zinc-900 text-zinc-300 border-white/10'
                    }`}
                  >
                    LV Dark
                  </button>
                  <button
                    type="button"
                    onClick={() => setWallpaperMode('midnight')}
                    className={`h-9 rounded-xl text-[11px] font-extrabold border ${
                      wallpaperMode === 'midnight'
                        ? 'bg-cyan-400 text-black border-white'
                        : 'bg-zinc-900 text-zinc-300 border-white/10'
                    }`}
                  >
                    Midnight
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full h-12 rounded-xl bg-gradient-to-r from-emerald-400 via-cyan-400 to-fuchsia-500 text-black font-extrabold text-base flex items-center justify-center gap-2 shadow-lg active:scale-[0.99] transition"
              >
                <UserPlus className="w-5 h-5" />
                Sign Up &amp; Open My Feed
              </button>
            </form>
          </div>
        )}
      </div>

      {showAvatarModal && (
        <AvatarCustomizerModal
          initialConfig={avatarConfig}
          onSave={(newUrl, newCfg) => {
            setAvatarUrl(newUrl);
            setAvatarConfig(newCfg);
            setShowAvatarModal(false);
          }}
          onClose={() => setShowAvatarModal(false)}
        />
      )}

      <footer className="relative z-10 text-center text-xs text-zinc-400 pb-2">
        Tomboy Colorverse • Saved to Phone Storage
      </footer>
    </div>
  );
};
