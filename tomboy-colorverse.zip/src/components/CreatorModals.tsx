import React, { useEffect, useRef, useState } from 'react';
import { ChatMessage, FeedPost, StoryReel, UserAccount } from '../types';
import {
  createSynthBeatWavUrl,
  extractYouTubeId,
  generateAIArtworkDataUrl,
  generateCustomAiArtAsync,
  playAutoChime,
  renderQuoteImage,
} from '../utils/mediaEngine';
import { fileToDataUrl } from '../utils/phoneStorage';
import {
  downloadStandaloneGithubHtml,
  generateAnimatedSvgGif,
  generateCustomAiStickerDataUrl,
  GifItem,
} from '../utils/gifAndExport';
import {
  X,
  Upload,
  Sparkles,
  Music,
  Search,
  Send,
  Download,
  Palette,
  Video,
  Image as ImageIcon,
  Wand2,
  Bot,
  Sticker,
  Youtube,
} from 'lucide-react';

export type ActiveModalType =
  | null
  | 'upload'
  | 'story-upload'
  | 'draw'
  | 'quote'
  | 'ai-img'
  | 'sonic'
  | 'emerald'
  | 'tube'
  | 'gif'
  | 'sticker'
  | 'web'
  | 'chat';

interface EmeraldChatTurn {
  id: string;
  role: 'user' | 'model';
  text: string;
}

interface CreatorModalsProps {
  activeModal: ActiveModalType;
  currentUser: UserAccount;
  messages: ChatMessage[];
  onClose: () => void;
  onAddPost: (post: FeedPost) => void;
  onAddStory: (story: StoryReel) => void;
  onSendMessage: (text: string) => void;
  onSetWallpaper: (url: string) => void;
}

function isAudioFile(file: File): boolean {
  if (file.type.startsWith('audio/')) return true;
  return /\.(mp3|wav|m4a|aac|ogg|flac|opus|wma)$/i.test(file.name);
}

function isVideoFile(file: File): boolean {
  if (file.type.startsWith('video/')) return true;
  return /\.(mp4|mov|webm|m4v|avi|mkv)$/i.test(file.name);
}

export const CreatorModals: React.FC<CreatorModalsProps> = ({
  activeModal,
  currentUser,
  messages,
  onClose,
  onAddPost,
  onAddStory,
  onSendMessage,
  onSetWallpaper,
}) => {
  // Upload state
  const [uploadTarget, setUploadTarget] = useState<'feed' | 'story'>(
    activeModal === 'story-upload' ? 'story' : 'feed'
  );
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadedDataUrl, setUploadedDataUrl] = useState('');
  const [uploadedAudioUrl, setUploadedAudioUrl] = useState('');
  const [uploadMediaKind, setUploadMediaKind] = useState<'image' | 'video' | 'music'>('image');

  // Quote Generator state
  const [quoteText, setQuoteText] = useState('OWN YOUR FREQUENCY IN FULL COLOR');
  const [quoteFont, setQuoteFont] = useState<'rainbow-lv' | 'neon' | 'chrome' | 'street'>('rainbow-lv');
  const [quoteBg, setQuoteBg] = useState('lv-rainbow');
  const [customQuoteBgUrl, setCustomQuoteBgUrl] = useState('');
  const [quotePreviewUrl, setQuotePreviewUrl] = useState('');
  const [loadingAiQuote, setLoadingAiQuote] = useState(false);

  // Draw Canvas state
  const drawCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [brushColor, setBrushColor] = useState('#ec4899');
  const [drawTitle, setDrawTitle] = useState('NEON ART');

  // AI Image & Wallpaper state (Real AI Art Pictures)
  const [aiPrompt, setAiPrompt] = useState('Cool tomboy girl in oversized hoodie on pink graffiti van with rainbow sunset');
  const [aiPreviewUrl, setAiPreviewUrl] = useState('');
  const [generatingAiArt, setGeneratingAiArt] = useState(false);

  // Sonic MP3 Music Upload & Beat Studio state
  const [songTitle, setSongTitle] = useState('COLORVERSE ANTHEM 808');
  const [beatSeed, setBeatSeed] = useState(120);
  const [customSongDataUrl, setCustomSongDataUrl] = useState('');
  const [customSongCoverUrl, setCustomSongCoverUrl] = useState('');

  // Real GIF Search state
  const [gifQuery, setGifQuery] = useState('powerpuff girls');
  const [gifResults, setGifResults] = useState<GifItem[]>([]);
  const [searchingGifs, setSearchingGifs] = useState(false);

  // Real Sticker Search & Custom AI Sticker Creator state
  const [stickerPrompt, setStickerPrompt] = useState('cool skate cat');
  const [stickerPreviewUrl, setStickerPreviewUrl] = useState('');
  const [stickerGallery, setStickerGallery] = useState<{ id: string; title: string; url: string }[]>([]);
  const [creatingSticker, setCreatingSticker] = useState(false);
  const [searchingStickers, setSearchingStickers] = useState(false);

  // Emerald AI Chatbot state
  const [emeraldChat, setEmeraldChat] = useState<EmeraldChatTurn[]>([
    {
      id: 'em-welcome',
      role: 'model',
      text: "Hey! I'm Emerald AI 💚 Ask me anything—song lyrics, homework, math, science, streetwear ideas, stories, coding, or life advice—and I'll answer right back!",
    },
  ]);
  const [emeraldInput, setEmeraldInput] = useState('');
  const [emeraldLoading, setEmeraldLoading] = useState(false);
  const emeraldScrollRef = useRef<HTMLDivElement | null>(null);

  // Community Chat state
  const [chatInput, setChatInput] = useState('');

  // YouTube Video Studio state (TUBE modal)
  const [ytUrlInput, setYtUrlInput] = useState('');
  const [ytSearchQuery, setYtSearchQuery] = useState('hip hop music video');
  const [ytSearchResults, setYtSearchResults] = useState<
    Array<{ videoId: string; title: string; thumbnail: string }>
  >([]);
  const [searchingYt, setSearchingYt] = useState(false);
  const [selectedYtId, setSelectedYtId] = useState('jfKfPfyJRdk');
  const [ytPostTitle, setYtPostTitle] = useState('YOUTUBE VIDEO DROP');
  const [ytTarget, setYtTarget] = useState<'feed' | 'story'>('feed');

  const handleSearchYouTube = async (queryOverride?: string) => {
    const q = (queryOverride ?? ytSearchQuery).trim() || 'hip hop music video';
    setSearchingYt(true);
    try {
      const res = await fetch(`/api/youtube?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      if (Array.isArray(data?.videos) && data.videos.length > 0) {
        setYtSearchResults(data.videos);
        setSelectedYtId(data.videos[0].videoId);
        setYtPostTitle(data.videos[0].title.slice(0, 48).toUpperCase());
      }
    } catch {
      // Keep existing or default preview
    } finally {
      setSearchingYt(false);
    }
  };

  useEffect(() => {
    if (activeModal === 'story-upload') {
      setUploadTarget('story');
    } else if (activeModal === 'upload') {
      setUploadTarget('feed');
    } else if (activeModal === 'tube') {
      handleSearchYouTube('hip hop music video');
    }
  }, [activeModal]);

  useEffect(() => {
    if (activeModal === 'draw' && drawCanvasRef.current) {
      const ctx = drawCanvasRef.current.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#0d0d10';
        ctx.fillRect(0, 0, 500, 500);
      }
    }
  }, [activeModal]);

  useEffect(() => {
    if (activeModal === 'quote') {
      renderQuoteImage(quoteText || 'TOMBOY COLORVERSE', quoteFont, quoteBg, customQuoteBgUrl).then(
        setQuotePreviewUrl
      );
    }
  }, [activeModal, quoteText, quoteFont, quoteBg, customQuoteBgUrl]);

  // Trigger real AI Art generation when AI IMG modal opens
  useEffect(() => {
    if (activeModal === 'ai-img') {
      handleGenerateAiArtClick(undefined, aiPrompt);
    }
  }, [activeModal]);

  // Trigger real GIF search when GIF modal opens
  useEffect(() => {
    if (activeModal === 'gif') {
      handleRealGifSearch('powerpuff girls');
    }
  }, [activeModal]);

  // Trigger real Sticker search when STICKER modal opens
  useEffect(() => {
    if (activeModal === 'sticker') {
      handleSearchRealStickers('cool skate cat');
    }
  }, [activeModal]);

  useEffect(() => {
    if (emeraldScrollRef.current) {
      emeraldScrollRef.current.scrollTop = emeraldScrollRef.current.scrollHeight;
    }
  }, [emeraldChat, emeraldLoading]);

  if (!activeModal) return null;

  const handleFileChange = async (
    e: React.ChangeEvent<HTMLInputElement>,
    forceMusic = false
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    let dataUrl = await fileToDataUrl(file);
    const defaultName = file.name.replace(/\.[^/.]+$/, '').toUpperCase();
    if (!uploadTitle) {
      setUploadTitle(defaultName);
    }
    if (forceMusic || isAudioFile(file)) {
      if (dataUrl.startsWith('data:application/octet-stream')) {
        dataUrl = dataUrl.replace('data:application/octet-stream', 'data:audio/mpeg');
      }
      setUploadMediaKind('music');
      setUploadedAudioUrl(dataUrl);
      setUploadedDataUrl(generateAIArtworkDataUrl(defaultName, '3:4'));
    } else if (isVideoFile(file)) {
      setUploadMediaKind('video');
      setUploadedDataUrl(dataUrl);
    } else {
      setUploadMediaKind('image');
      setUploadedDataUrl(dataUrl);
    }
  };

  const submitUpload = () => {
    if (!uploadedDataUrl) return;
    playAutoChime(587.33);

    if (uploadTarget === 'story') {
      const newStory: StoryReel = {
        id: `story-${Date.now()}`,
        authorId: currentUser.id,
        authorName: currentUser.username,
        authorAvatar: currentUser.avatar,
        mediaType: uploadMediaKind === 'video' ? 'video' : 'image',
        mediaUrl: uploadedDataUrl,
        audioUrl: uploadedAudioUrl || createSynthBeatWavUrl(130, 6),
        caption: uploadTitle || 'New Story Reel 🔥',
        likes: [],
        createdAt: Date.now(),
        beatFreq: 130,
      };
      onAddStory(newStory);
    } else {
      const newPost: FeedPost = {
        id: `post-${Date.now()}`,
        authorId: currentUser.id,
        authorName: currentUser.username,
        authorAvatar: currentUser.avatar,
        type: uploadMediaKind,
        title: (uploadTitle || 'COLORVERSE DROP').toUpperCase(),
        mediaUrl: uploadedDataUrl,
        audioUrl: uploadedAudioUrl || createSynthBeatWavUrl(125, 6),
        likes: [],
        comments: [],
        createdAt: Date.now(),
        beatFreq: 125,
      };
      onAddPost(newPost);
    }

    setUploadedDataUrl('');
    setUploadedAudioUrl('');
    setUploadTitle('');
    onClose();
  };

  // Real AI Art & Wallpaper Generator handler
  const handleGenerateAiArtClick = async (
    e?: React.FormEvent,
    promptOverride?: string
  ) => {
    if (e) e.preventDefault();
    const clean = (promptOverride ?? aiPrompt).trim() || 'Rainbow LV Streetwear';
    setGeneratingAiArt(true);
    playAutoChime(587.33);
    try {
      const url = await generateCustomAiArtAsync(clean, '3:4', 'art');
      setAiPreviewUrl(url);
    } finally {
      setGeneratingAiArt(false);
    }
  };

  const handleGenerateAiQuote = async () => {
    setLoadingAiQuote(true);
    try {
      const res = await fetch('/api/ai/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: quoteText, style: 'rainbow lv tomboy streetwear' }),
      });
      const data = await res.json();
      if (data?.quote) {
        setQuoteText(data.quote);
      }
    } catch {
      setQuoteText('STAY UNAPOLOGETIC IN FULL RAINBOW LUXURY.');
    } finally {
      setLoadingAiQuote(false);
    }
  };

  const handlePostQuote = async () => {
    const imgUrl = await renderQuoteImage(
      quoteText || 'TOMBOY COLORVERSE',
      quoteFont,
      quoteBg,
      customQuoteBgUrl
    );
    playAutoChime(659.25);
    onAddPost({
      id: `post-${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.username,
      authorAvatar: currentUser.avatar,
      type: 'quote',
      title: quoteText.slice(0, 28).toUpperCase(),
      mediaUrl: imgUrl,
      quoteText,
      quoteFont,
      quoteBg,
      likes: [],
      comments: [],
      createdAt: Date.now(),
      beatFreq: 140,
    });
    onClose();
  };

  // Drawing handlers
  const getCanvasPoint = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = drawCanvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const startDraw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const ctx = drawCanvasRef.current?.getContext('2d');
    if (!ctx) return;
    const pt = getCanvasPoint(e);
    ctx.beginPath();
    ctx.moveTo(pt.x, pt.y);
  };

  const moveDraw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const ctx = drawCanvasRef.current?.getContext('2d');
    if (!ctx) return;
    const pt = getCanvasPoint(e);
    ctx.strokeStyle = brushColor;
    ctx.shadowColor = brushColor;
    ctx.shadowBlur = 14;
    ctx.lineWidth = 7;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineTo(pt.x, pt.y);
    ctx.stroke();
  };

  const endDraw = () => {
    setIsDrawing(false);
  };

  const saveDrawingToFeed = () => {
    if (!drawCanvasRef.current) return;
    const dataUrl = drawCanvasRef.current.toDataURL('image/png');
    playAutoChime(523.25);
    onAddPost({
      id: `post-${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.username,
      authorAvatar: currentUser.avatar,
      type: 'drawing',
      title: (drawTitle || 'NEON SKETCH').toUpperCase(),
      mediaUrl: dataUrl,
      likes: [],
      comments: [],
      createdAt: Date.now(),
      beatFreq: 110,
    });
    onClose();
  };

  // REAL Animated GIF Search via Giphy API
  const handleRealGifSearch = async (qOverride?: string) => {
    const q = (qOverride ?? gifQuery).trim() || 'rainbow hype';
    setSearchingGifs(true);
    try {
      const res = await fetch(`/api/gifs?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      if (Array.isArray(data?.gifs) && data.gifs.length > 0) {
        setGifResults(data.gifs);
      } else {
        setGifResults(
          Array.from({ length: 6 }, (_, i) => generateAnimatedSvgGif(q, i))
        );
      }
    } catch {
      setGifResults(
        Array.from({ length: 6 }, (_, i) => generateAnimatedSvgGif(q, i))
      );
    } finally {
      setSearchingGifs(false);
    }
  };

  // Search Real Transparent Stickers via Giphy Stickers API
  const handleSearchRealStickers = async (qOverride?: string) => {
    const q = (qOverride ?? stickerPrompt).trim() || 'cool skate cat';
    setSearchingStickers(true);
    try {
      const res = await fetch(`/api/stickers?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      if (Array.isArray(data?.stickers) && data.stickers.length > 0) {
        setStickerGallery(data.stickers);
      } else {
        setStickerGallery([
          {
            id: 'fb-1',
            title: q.toUpperCase(),
            url: generateCustomAiStickerDataUrl(q, 'circle'),
          },
        ]);
      }
    } catch {
      setStickerGallery([
        {
          id: 'fb-1',
          title: q.toUpperCase(),
          url: generateCustomAiStickerDataUrl(q, 'circle'),
        },
      ]);
    } finally {
      setSearchingStickers(false);
    }
  };

  // Create a Real Custom AI Die-Cut Sticker Picture + fetch matching real stickers
  const handleCreateCustomSticker = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const prompt = stickerPrompt.trim() || 'cool skate cat';
    setCreatingSticker(true);
    playAutoChime(659.25);

    // Search real transparent stickers simultaneously
    handleSearchRealStickers(prompt);

    try {
      const aiStickerUrl = await generateCustomAiArtAsync(prompt, '1:1', 'sticker');
      setStickerPreviewUrl(aiStickerUrl);
    } finally {
      setCreatingSticker(false);
    }
  };

  // Ask Emerald AI Chatbot anything
  const handleAskEmerald = async (customQuestion?: string) => {
    const question = (customQuestion ?? emeraldInput).trim();
    if (!question || emeraldLoading) return;

    const userTurn: EmeraldChatTurn = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: question,
    };
    const updatedHistory = [...emeraldChat, userTurn];
    setEmeraldChat(updatedHistory);
    setEmeraldInput('');
    setEmeraldLoading(true);
    playAutoChime(523.25);

    try {
      const res = await fetch('/api/ai/emerald-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: question,
          history: updatedHistory.map((m) => ({ role: m.role, text: m.text })),
        }),
      });
      const data = await res.json();
      const replyText =
        data?.reply ||
        "I'm right here! Tell me more about what you'd like to explore or create.";
      playAutoChime(659.25);
      setEmeraldChat((prev) => [
        ...prev,
        {
          id: `m-${Date.now()}`,
          role: 'model',
          text: replyText,
        },
      ]);
    } catch {
      setEmeraldChat((prev) => [
        ...prev,
        {
          id: `m-${Date.now()}`,
          role: 'model',
          text: `Here's my take on "${question}": Stay bold, keep creating in full color, and ask me any follow-up question anytime! 💚`,
        },
      ]);
    } finally {
      setEmeraldLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-md bg-[#121216] border border-white/15 rounded-3xl p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
        {/* UPLOAD / STORY UPLOAD MODAL */}
        {(activeModal === 'upload' || activeModal === 'story-upload') && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Upload className="w-5 h-5 text-pink-400" />
                {activeModal === 'story-upload'
                  ? 'Upload 24H Story Reel'
                  : 'Upload Photo, Video or MP3 Music'}
              </h3>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 bg-zinc-900 p-1 rounded-2xl border border-white/10">
              <button
                type="button"
                onClick={() => setUploadTarget('feed')}
                className={`py-2 rounded-xl text-xs font-extrabold transition ${
                  uploadTarget === 'feed'
                    ? 'bg-gradient-to-r from-fuchsia-500 to-cyan-400 text-black'
                    : 'text-zinc-400'
                }`}
              >
                Home Screen Feed
              </button>
              <button
                type="button"
                onClick={() => setUploadTarget('story')}
                className={`py-2 rounded-xl text-xs font-extrabold transition ${
                  uploadTarget === 'story'
                    ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-black'
                    : 'text-zinc-400'
                }`}
              >
                24H Story Reel Loop
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <label className="cursor-pointer border-2 border-dashed border-cyan-400/50 hover:border-cyan-400 rounded-2xl p-4 flex flex-col items-center justify-center text-center bg-zinc-900/70 transition">
                <div className="flex items-center gap-2 mb-1.5 text-cyan-400">
                  <ImageIcon className="w-5 h-5" />
                  <Video className="w-5 h-5 text-pink-400" />
                </div>
                <span className="text-xs font-extrabold text-white">
                  Photo or Video
                </span>
                <span className="text-[10px] text-zinc-400 mt-0.5">
                  Camera Roll / Gallery
                </span>
                <input
                  type="file"
                  accept="image/*,video/*"
                  onChange={(e) => handleFileChange(e, false)}
                  className="hidden"
                />
              </label>

              <label className="cursor-pointer border-2 border-dashed border-pink-500/70 hover:border-pink-400 rounded-2xl p-4 flex flex-col items-center justify-center text-center bg-zinc-900/70 transition">
                <div className="flex items-center gap-2 mb-1.5 text-pink-400">
                  <Music className="w-6 h-6" />
                </div>
                <span className="text-xs font-extrabold text-white">
                  Upload MP3 / Music
                </span>
                <span className="text-[10px] text-zinc-400 mt-0.5">
                  MP3, WAV, M4A, Audio
                </span>
                <input
                  type="file"
                  accept="audio/*,audio/mpeg,audio/mp3,audio/mp4,audio/wav,audio/x-m4a,.mp3,.wav,.m4a,.aac,.ogg,.flac"
                  onChange={(e) => handleFileChange(e, true)}
                  className="hidden"
                />
              </label>
            </div>

            {uploadedDataUrl && (
              <div className="rounded-2xl overflow-hidden bg-black border border-white/10 p-2 space-y-2">
                <div className="max-h-48 flex items-center justify-center overflow-hidden rounded-xl">
                  {uploadMediaKind === 'video' ? (
                    <video
                      src={uploadedDataUrl}
                      controls
                      autoPlay
                      muted={false}
                      className="max-h-48 w-full object-contain"
                    />
                  ) : (
                    <img
                      src={uploadedDataUrl}
                      alt="Preview"
                      referrerPolicy="no-referrer"
                      className="max-h-48 w-full object-contain"
                    />
                  )}
                </div>

                {uploadMediaKind === 'music' && uploadedAudioUrl && (
                  <div className="bg-zinc-900 p-2.5 rounded-xl border border-pink-500/40 space-y-2">
                    <p className="text-xs font-extrabold text-pink-400 flex items-center gap-1.5">
                      <Music className="w-4 h-4" />
                      MP3 Music Loaded (Playing Preview):
                    </p>
                    <audio
                      src={uploadedAudioUrl}
                      controls
                      autoPlay
                      className="w-full h-9"
                    />
                  </div>
                )}
              </div>
            )}

            <input
              type="text"
              value={uploadTitle}
              onChange={(e) => setUploadTitle(e.target.value)}
              placeholder="Title or caption (e.g. MY MP3 TRACK)"
              className="w-full h-11 px-4 rounded-xl bg-zinc-900 border border-white/15 text-sm text-white placeholder-zinc-500"
            />

            <button
              type="button"
              disabled={!uploadedDataUrl}
              onClick={submitUpload}
              className="w-full h-12 rounded-xl bg-gradient-to-r from-fuchsia-500 via-purple-500 to-cyan-400 disabled:opacity-40 text-black font-extrabold text-sm shadow-lg"
            >
              Post {uploadMediaKind === 'music' ? 'MP3 Music' : 'Content'} to{' '}
              {uploadTarget === 'story' ? '24H Stories' : 'Home Feed'}
            </button>
          </>
        )}

        {/* YOUTUBE VIDEO STUDIO & POSTER MODAL (TUBE) */}
        {activeModal === 'tube' && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Youtube className="w-5 h-5 text-red-500" />
                Post YouTube Video (TUBE)
              </h3>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Choose Target: Home Screen Feed vs 24H Story Reel */}
            <div className="grid grid-cols-2 gap-2 bg-zinc-900 p-1 rounded-2xl border border-white/10">
              <button
                type="button"
                onClick={() => setYtTarget('feed')}
                className={`py-2 rounded-xl text-xs font-extrabold transition ${
                  ytTarget === 'feed'
                    ? 'bg-gradient-to-r from-red-500 to-amber-400 text-black'
                    : 'text-zinc-400'
                }`}
              >
                Post to My Feed
              </button>
              <button
                type="button"
                onClick={() => setYtTarget('story')}
                className={`py-2 rounded-xl text-xs font-extrabold transition ${
                  ytTarget === 'story'
                    ? 'bg-gradient-to-r from-pink-500 to-cyan-400 text-black'
                    : 'text-zinc-400'
                }`}
              >
                Post to 24H Story Loop
              </button>
            </div>

            {/* Option 1: Paste Any YouTube Link or Video ID */}
            <div className="bg-zinc-900/90 border border-white/10 rounded-2xl p-3 space-y-2">
              <label className="block text-xs font-extrabold text-red-400">
                1. Paste Any YouTube Video or Shorts Link:
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={ytUrlInput}
                  onChange={(e) => {
                    const val = e.target.value;
                    setYtUrlInput(val);
                    const extracted = extractYouTubeId(val);
                    if (extracted) {
                      setSelectedYtId(extracted);
                    }
                  }}
                  placeholder="https://www.youtube.com/watch?v=... or youtu.be/..."
                  className="flex-1 h-10 px-3 rounded-xl bg-zinc-950 border border-white/15 text-xs text-white placeholder-zinc-500"
                />
                <button
                  type="button"
                  onClick={() => {
                    const extracted = extractYouTubeId(ytUrlInput);
                    if (extracted) {
                      setSelectedYtId(extracted);
                    }
                  }}
                  className="h-10 px-3.5 rounded-xl bg-red-500 hover:bg-red-400 text-white font-extrabold text-xs shrink-0"
                >
                  Load Link
                </button>
              </div>
            </div>

            {/* Option 2: Search YouTube Videos Directly */}
            <div className="bg-zinc-900/90 border border-white/10 rounded-2xl p-3 space-y-2.5">
              <label className="block text-xs font-extrabold text-cyan-400">
                2. Or Search YouTube Videos to Post:
              </label>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSearchYouTube();
                }}
                className="flex gap-2"
              >
                <input
                  type="text"
                  value={ytSearchQuery}
                  onChange={(e) => setYtSearchQuery(e.target.value)}
                  placeholder="Search songs, artists, skate clips, gaming..."
                  className="flex-1 h-10 px-3 rounded-xl bg-zinc-950 border border-white/15 text-xs text-white"
                />
                <button
                  type="submit"
                  disabled={searchingYt}
                  className="h-10 px-3.5 rounded-xl bg-cyan-400 text-black font-extrabold text-xs flex items-center gap-1 shrink-0 disabled:opacity-60"
                >
                  <Search className="w-3.5 h-3.5" />
                  {searchingYt ? '...' : 'Search'}
                </button>
              </form>

              {ytSearchResults.length > 0 && (
                <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto pr-1 pt-1">
                  {ytSearchResults.map((vid) => {
                    const isPicked = selectedYtId === vid.videoId;
                    return (
                      <button
                        key={vid.videoId}
                        type="button"
                        onClick={() => {
                          setSelectedYtId(vid.videoId);
                          setYtPostTitle(vid.title.slice(0, 48).toUpperCase());
                        }}
                        className={`text-left rounded-xl overflow-hidden border transition ${
                          isPicked
                            ? 'border-red-500 ring-2 ring-red-500/40 bg-zinc-800'
                            : 'border-white/10 bg-zinc-950 hover:border-white/30'
                        }`}
                      >
                        <img
                          src={vid.thumbnail}
                          alt={vid.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-20 object-cover"
                        />
                        <p className="p-1.5 text-[10px] font-bold text-white line-clamp-2 leading-tight">
                          {vid.title}
                        </p>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Live YouTube Video Embed Preview */}
            {selectedYtId && (
              <div className="space-y-2">
                <div className="aspect-video w-full rounded-2xl overflow-hidden bg-black border border-red-500/40 shadow-lg">
                  <iframe
                    src={`https://www.youtube.com/embed/${selectedYtId}?playsinline=1&rel=0`}
                    title="YouTube video preview"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowFullScreen
                    className="w-full h-full border-0"
                  />
                </div>

                <input
                  type="text"
                  value={ytPostTitle}
                  onChange={(e) => setYtPostTitle(e.target.value)}
                  placeholder="Video Title / Caption"
                  className="w-full h-11 px-3.5 rounded-xl bg-zinc-900 border border-white/15 text-xs font-bold text-white"
                />

                <button
                  type="button"
                  onClick={() => {
                    const thumbUrl = `https://i.ytimg.com/vi/${selectedYtId}/hqdefault.jpg`;
                    if (ytTarget === 'story') {
                      onAddStory({
                        id: `story-yt-${Date.now()}`,
                        authorId: currentUser.id,
                        authorName: currentUser.username,
                        authorAvatar: currentUser.avatar,
                        mediaType: 'youtube',
                        mediaUrl: thumbUrl,
                        youtubeId: selectedYtId,
                        caption: ytPostTitle.trim() || 'YouTube Video Reel 🎬',
                        likes: [],
                        createdAt: Date.now(),
                      });
                    } else {
                      onAddPost({
                        id: `post-yt-${Date.now()}`,
                        authorId: currentUser.id,
                        authorName: currentUser.username,
                        authorAvatar: currentUser.avatar,
                        type: 'youtube',
                        title: ytPostTitle.trim() || 'YOUTUBE VIDEO',
                        mediaUrl: thumbUrl,
                        youtubeId: selectedYtId,
                        likes: [],
                        comments: [],
                        createdAt: Date.now(),
                      });
                    }
                    onClose();
                  }}
                  className="w-full h-12 rounded-xl bg-gradient-to-r from-red-500 via-pink-500 to-amber-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg"
                >
                  <Youtube className="w-5 h-5" />
                  Post YouTube Video to{' '}
                  {ytTarget === 'story' ? '24H Story Loop' : 'My Feed'}
                </button>
              </div>
            )}
          </>
        )}

        {/* RAINBOW LV QUOTE GENERATOR MODAL */}
        {activeModal === 'quote' && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                Rainbow LV Quote Studio
              </h3>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {quotePreviewUrl && (
              <div className="rounded-2xl overflow-hidden border border-white/15 aspect-square max-h-60 mx-auto">
                <img
                  src={quotePreviewUrl}
                  alt="Quote Preview"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            <div className="flex gap-2">
              <input
                type="text"
                value={quoteText}
                onChange={(e) => setQuoteText(e.target.value)}
                placeholder="Type your quote..."
                className="flex-1 h-11 px-3.5 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white"
              />
              <button
                type="button"
                onClick={handleGenerateAiQuote}
                disabled={loadingAiQuote}
                className="h-11 px-3.5 rounded-xl bg-amber-400 text-black font-extrabold text-xs shrink-0 flex items-center gap-1"
              >
                <Wand2 className="w-4 h-4" />
                {loadingAiQuote ? '...' : 'AI Quote'}
              </button>
            </div>

            <div>
              <p className="text-xs font-bold text-zinc-400 mb-1.5">Font Style:</p>
              <div className="grid grid-cols-4 gap-1.5">
                {[
                  { id: 'rainbow-lv', label: 'Rainbow LV' },
                  { id: 'neon', label: 'Neon Glow' },
                  { id: 'chrome', label: 'Chrome' },
                  { id: 'street', label: 'Street Gold' },
                ].map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setQuoteFont(f.id as any)}
                    className={`py-2 rounded-xl text-[11px] font-extrabold border ${
                      quoteFont === f.id
                        ? 'bg-pink-500 text-white border-white'
                        : 'bg-zinc-900 text-zinc-300 border-white/10'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="text-xs font-bold text-zinc-400 mb-1.5">
                Quote Background (Preset, Color, or Upload Photo):
              </p>
              <div className="flex items-center gap-2 flex-wrap">
                {[
                  { id: 'lv-rainbow', label: 'LV Monogram' },
                  { id: 'cyber-pink', label: 'Cyber Pink' },
                  { id: 'sunset-gold', label: 'Sunset' },
                  { id: 'emerald-matrix', label: 'Emerald' },
                ].map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => {
                      setCustomQuoteBgUrl('');
                      setQuoteBg(b.id);
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold border ${
                      quoteBg === b.id && !customQuoteBgUrl
                        ? 'bg-cyan-400 text-black border-white'
                        : 'bg-zinc-900 text-zinc-300 border-white/10'
                    }`}
                  >
                    {b.label}
                  </button>
                ))}

                <input
                  type="color"
                  onChange={(e) => {
                    setCustomQuoteBgUrl('');
                    setQuoteBg(e.target.value);
                  }}
                  title="Pick any color"
                  className="w-9 h-9 rounded-xl bg-zinc-900 border border-white/20 cursor-pointer"
                />

                <label className="px-3 py-1.5 rounded-xl text-xs font-bold bg-zinc-800 hover:bg-zinc-700 text-pink-300 border border-pink-400/30 cursor-pointer">
                  + Photo BG
                  <input
                    type="file"
                    accept="image/*"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const url = await fileToDataUrl(file);
                        setCustomQuoteBgUrl(url);
                      }
                    }}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            <button
              type="button"
              onClick={handlePostQuote}
              className="w-full h-12 rounded-xl bg-gradient-to-r from-pink-500 via-amber-400 to-cyan-400 text-black font-extrabold text-sm shadow-lg"
            >
              Post Rainbow Quote to Feed
            </button>
          </>
        )}

        {/* DRAW STUDIO MODAL */}
        {activeModal === 'draw' && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Palette className="w-5 h-5 text-pink-400" />
                Neon Draw Pad
              </h3>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <canvas
              ref={drawCanvasRef}
              width={500}
              height={500}
              onPointerDown={startDraw}
              onPointerMove={moveDraw}
              onPointerUp={endDraw}
              onPointerLeave={endDraw}
              className="w-full aspect-square rounded-2xl border border-white/15 bg-[#0d0d10] touch-none cursor-crosshair"
            />

            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                {['#ec4899', '#06b6d4', '#fde047', '#10b981', '#a855f7', '#ffffff'].map(
                  (hex) => (
                    <button
                      key={hex}
                      type="button"
                      onClick={() => setBrushColor(hex)}
                      className={`w-7 h-7 rounded-full border-2 ${
                        brushColor === hex ? 'border-white scale-110' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: hex }}
                    />
                  )
                )}
              </div>
              <button
                type="button"
                onClick={() => {
                  const ctx = drawCanvasRef.current?.getContext('2d');
                  if (ctx) {
                    ctx.fillStyle = '#0d0d10';
                    ctx.fillRect(0, 0, 500, 500);
                  }
                }}
                className="px-3 py-1.5 rounded-xl bg-zinc-800 text-xs font-bold text-zinc-300"
              >
                Clear
              </button>
            </div>

            <input
              type="text"
              value={drawTitle}
              onChange={(e) => setDrawTitle(e.target.value)}
              placeholder="Drawing Title (e.g. N 💖 M)"
              className="w-full h-11 px-3.5 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white"
            />

            <button
              type="button"
              onClick={saveDrawingToFeed}
              className="w-full h-12 rounded-xl bg-white text-black font-extrabold text-sm"
            >
              Post Artwork to Feed
            </button>
          </>
        )}

        {/* REAL AI ART PICTURE & WALLPAPER GENERATOR MODAL */}
        {activeModal === 'ai-img' && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Wand2 className="w-5 h-5 text-amber-400" />
                Real AI Art &amp; Picture Generator
              </h3>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-zinc-300">
              Describe any scene, character, or aesthetic and AI will generate a real picture!
            </p>

            <div className="rounded-2xl overflow-hidden border border-white/15 min-h-[240px] max-h-72 flex items-center justify-center bg-black relative">
              {aiPreviewUrl && (
                <img
                  src={aiPreviewUrl}
                  alt="AI Generated Picture"
                  referrerPolicy="no-referrer"
                  className="max-h-72 w-full object-contain"
                />
              )}
              {generatingAiArt && (
                <div className="absolute inset-0 bg-black/70 backdrop-blur-xs flex flex-col items-center justify-center text-xs font-extrabold text-amber-300 gap-2 p-4 text-center">
                  <Sparkles className="w-6 h-6 animate-spin" />
                  <span>Generating Real AI Picture...</span>
                </div>
              )}
            </div>

            <form
              onSubmit={(e) => handleGenerateAiArtClick(e)}
              className="flex gap-2"
            >
              <input
                type="text"
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="Describe any picture (e.g. Powerpuff skater girls, neon cat)..."
                className="flex-1 h-11 px-3.5 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white"
              />
              <button
                type="submit"
                disabled={generatingAiArt}
                className="h-11 px-4 rounded-xl bg-amber-400 disabled:opacity-50 text-black font-extrabold text-xs shrink-0 flex items-center gap-1"
              >
                <Wand2 className="w-4 h-4" />
                {generatingAiArt ? 'Making...' : 'Create Art'}
              </button>
            </form>

            {/* Quick AI Art Prompt Chips */}
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
              {[
                '3D Tomboy Skater Girl in Rainbow Hoodie',
                'Cute Cat Wearing Headphones & Gold Chain',
                'Pink Graffiti Camper Van Under Rainbow',
                'Neon Cyberpunk Sports Car in Miami',
              ].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => {
                    setAiPrompt(preset);
                    handleGenerateAiArtClick(undefined, preset);
                  }}
                  className="px-3 py-1 rounded-full bg-zinc-800 hover:bg-zinc-700 text-amber-300 text-[11px] font-bold whitespace-nowrap shrink-0 border border-amber-400/30"
                >
                  {preset}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                disabled={!aiPreviewUrl || generatingAiArt}
                onClick={() => {
                  playAutoChime(587.33);
                  onAddPost({
                    id: `post-${Date.now()}`,
                    authorId: currentUser.id,
                    authorName: currentUser.username,
                    authorAvatar: currentUser.avatar,
                    type: 'image',
                    title: (aiPrompt || 'AI ART').slice(0, 24).toUpperCase(),
                    mediaUrl: aiPreviewUrl,
                    likes: [],
                    comments: [],
                    createdAt: Date.now(),
                    beatFreq: 135,
                  });
                  onClose();
                }}
                className="h-11 rounded-xl bg-gradient-to-r from-amber-400 to-pink-500 disabled:opacity-40 text-black font-extrabold text-xs shadow-lg"
              >
                Post AI Picture to Feed
              </button>
              <button
                type="button"
                disabled={!aiPreviewUrl || generatingAiArt}
                onClick={() => {
                  playAutoChime(659.25);
                  onSetWallpaper(aiPreviewUrl);
                  onClose();
                }}
                className="h-11 rounded-xl bg-emerald-500 disabled:opacity-40 text-black font-extrabold text-xs shadow-lg"
              >
                Set App Wallpaper
              </button>
            </div>
          </>
        )}

        {/* EMERALD AI CHATBOT MODAL */}
        {activeModal === 'emerald' && (
          <>
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-400 to-cyan-500 flex items-center justify-center text-black shadow-lg">
                  <Bot className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white leading-tight">
                    Emerald AI Assistant
                  </h3>
                  <p className="text-[11px] text-emerald-400 font-semibold">
                    Ask anything • Answers back instantly
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
              {[
                'Write a hype rap verse',
                'Give me 5 Rainbow LV quotes',
                'Outfit ideas for tonight',
                'Tell me a fun fact',
              ].map((sug) => (
                <button
                  key={sug}
                  type="button"
                  onClick={() => handleAskEmerald(sug)}
                  className="px-3 py-1.5 rounded-full bg-emerald-500/15 hover:bg-emerald-500/30 border border-emerald-400/30 text-emerald-300 text-[11px] font-bold whitespace-nowrap shrink-0 transition"
                >
                  {sug}
                </button>
              ))}
            </div>

            <div
              ref={emeraldScrollRef}
              className="space-y-3 max-h-72 min-h-[240px] overflow-y-auto bg-zinc-950/90 p-3.5 rounded-2xl border border-white/10"
            >
              {emeraldChat.map((turn) => (
                <div
                  key={turn.id}
                  className={`flex flex-col ${
                    turn.role === 'user' ? 'items-end' : 'items-start'
                  }`}
                >
                  <div
                    className={`max-w-[86%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed whitespace-pre-wrap ${
                      turn.role === 'user'
                        ? 'bg-gradient-to-r from-emerald-400 to-cyan-400 text-black font-bold rounded-br-xs'
                        : 'bg-zinc-900 border border-emerald-500/30 text-zinc-100 rounded-bl-xs'
                    }`}
                  >
                    {turn.text}
                  </div>
                  {turn.role === 'model' && turn.id !== 'em-welcome' && (
                    <button
                      type="button"
                      onClick={async () => {
                        const cleanQuote = turn.text.slice(0, 90);
                        const imgUrl = await renderQuoteImage(
                          cleanQuote,
                          'rainbow-lv',
                          'emerald-matrix'
                        );
                        onAddPost({
                          id: `post-${Date.now()}`,
                          authorId: currentUser.id,
                          authorName: currentUser.username,
                          authorAvatar: currentUser.avatar,
                          type: 'quote',
                          title: 'EMERALD AI DROP',
                          mediaUrl: imgUrl,
                          quoteText: cleanQuote,
                          likes: [],
                          comments: [],
                          createdAt: Date.now(),
                          beatFreq: 140,
                        });
                        onClose();
                      }}
                      className="text-[10px] font-bold text-emerald-400 hover:underline mt-1 px-1"
                    >
                      + Post Emerald Answer to Feed
                    </button>
                  )}
                </div>
              ))}

              {emeraldLoading && (
                <div className="flex items-center gap-2 text-xs text-emerald-400 font-bold px-2">
                  <Sparkles className="w-4 h-4 animate-spin" />
                  Emerald AI is thinking...
                </div>
              )}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleAskEmerald();
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={emeraldInput}
                onChange={(e) => setEmeraldInput(e.target.value)}
                placeholder="Ask Emerald AI anything..."
                className="flex-1 h-11 px-3.5 rounded-xl bg-zinc-900 border border-emerald-500/40 text-xs text-white placeholder-zinc-400 focus:outline-none focus:border-emerald-400"
              />
              <button
                type="submit"
                disabled={emeraldLoading || !emeraldInput.trim()}
                className="h-11 px-4 rounded-xl bg-emerald-400 disabled:opacity-40 text-black font-extrabold text-xs flex items-center gap-1.5 shadow-lg"
              >
                <Send className="w-4 h-4" />
                Ask
              </button>
            </form>
          </>
        )}

        {/* SONIC MP3 MUSIC UPLOAD & BEAT STUDIO MODAL */}
        {activeModal === 'sonic' && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Music className="w-5 h-5 text-pink-400" />
                Upload MP3 Music &amp; Sonic Studio
              </h3>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <label className="block w-full py-5 px-4 rounded-2xl bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-cyan-500/20 border-2 border-dashed border-pink-400 text-center cursor-pointer hover:bg-pink-500/30 transition">
              <Music className="w-8 h-8 text-pink-400 mx-auto mb-1.5" />
              <span className="block text-sm font-extrabold text-white">
                {customSongDataUrl
                  ? '✅ MP3 / Audio Track Loaded!'
                  : 'Tap to Upload MP3 or Music File from Phone'}
              </span>
              <span className="block text-[11px] text-zinc-300 mt-0.5">
                Supports .MP3, .WAV, .M4A, .AAC &amp; All Phone Audio Files
              </span>
              <input
                type="file"
                accept="audio/*,audio/mpeg,audio/mp3,audio/mp4,audio/wav,audio/x-m4a,.mp3,.wav,.m4a,.aac,.ogg,.flac"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    let url = await fileToDataUrl(file);
                    if (url.startsWith('data:application/octet-stream')) {
                      url = url.replace('data:application/octet-stream', 'data:audio/mpeg');
                    }
                    setCustomSongDataUrl(url);
                    setSongTitle(file.name.replace(/\.[^/.]+$/, '').toUpperCase());
                  }
                }}
                className="hidden"
              />
            </label>

            {customSongDataUrl && (
              <div className="bg-zinc-900 p-3 rounded-2xl border border-pink-500/40 space-y-2">
                <p className="text-xs font-bold text-pink-300">
                  Playing Your Uploaded MP3 Track:
                </p>
                <audio
                  src={customSongDataUrl}
                  controls
                  autoPlay
                  className="w-full h-9"
                />
              </div>
            )}

            <div className="flex items-center justify-between gap-2 bg-zinc-900/90 p-2.5 rounded-xl border border-white/10">
              <span className="text-xs font-bold text-zinc-300">
                {customSongCoverUrl
                  ? '✅ Custom Album Cover Added'
                  : 'Optional: Add Custom Cover Photo'}
              </span>
              <label className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-extrabold text-cyan-300 cursor-pointer border border-cyan-400/30">
                Choose Cover
                <input
                  type="file"
                  accept="image/*"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const url = await fileToDataUrl(file);
                      setCustomSongCoverUrl(url);
                    }
                  }}
                  className="hidden"
                />
              </label>
            </div>

            <div className="space-y-2">
              <p className="text-xs font-bold text-zinc-400">
                Or Generate an Instant Synth Beat:
              </p>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: '808 Bass Bounce', freq: 110 },
                  { label: 'Neon Hyperpop', freq: 146 },
                  { label: 'Midnight Trap', freq: 98 },
                ].map((b) => (
                  <button
                    key={b.freq}
                    type="button"
                    onClick={() => {
                      setCustomSongDataUrl('');
                      setBeatSeed(b.freq);
                      playAutoChime(b.freq * 3);
                    }}
                    className={`py-2.5 rounded-xl text-xs font-extrabold border ${
                      beatSeed === b.freq && !customSongDataUrl
                        ? 'bg-pink-500 text-white border-white'
                        : 'bg-zinc-900 text-zinc-300 border-white/10'
                    }`}
                  >
                    {b.label}
                  </button>
                ))}
              </div>
            </div>

            <input
              type="text"
              value={songTitle}
              onChange={(e) => setSongTitle(e.target.value)}
              placeholder="Song / MP3 Track Title"
              className="w-full h-11 px-3.5 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white"
            />

            <button
              type="button"
              onClick={() => {
                const audioUrl =
                  customSongDataUrl || createSynthBeatWavUrl(beatSeed, 6);
                const coverUrl =
                  customSongCoverUrl ||
                  generateAIArtworkDataUrl(songTitle || 'Music Track', '3:4');
                onAddPost({
                  id: `post-${Date.now()}`,
                  authorId: currentUser.id,
                  authorName: currentUser.username,
                  authorAvatar: currentUser.avatar,
                  type: 'music',
                  title: (songTitle || 'COLORVERSE TRACK').toUpperCase(),
                  mediaUrl: coverUrl,
                  audioUrl,
                  likes: [],
                  comments: [],
                  createdAt: Date.now(),
                  beatFreq: beatSeed,
                });
                setCustomSongDataUrl('');
                setCustomSongCoverUrl('');
                onClose();
              }}
              className="w-full h-12 rounded-xl bg-gradient-to-r from-pink-500 via-fuchsia-500 to-amber-400 text-black font-extrabold text-sm shadow-lg"
            >
              Post MP3 Music Track to Home Feed
            </button>
          </>
        )}

        {/* REAL ANIMATED GIF SEARCH & GENERATOR MODAL */}
        {activeModal === 'gif' && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Search className="w-5 h-5 text-purple-400" />
                Search &amp; Post Real Animated GIFs
              </h3>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleRealGifSearch();
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={gifQuery}
                onChange={(e) => setGifQuery(e.target.value)}
                placeholder="Search any real GIF (e.g. powerpuff, skate, cat, dance)..."
                className="flex-1 h-11 px-3.5 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white"
              />
              <button
                type="submit"
                disabled={searchingGifs}
                className="h-11 px-4 rounded-xl bg-gradient-to-r from-purple-500 to-pink-500 text-white font-extrabold text-xs shrink-0"
              >
                {searchingGifs ? '...' : 'Search GIFs'}
              </button>
            </form>

            {/* Quick Trending GIF Categories */}
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
              {['Powerpuff Girls', 'Skateboarding', 'Cool Cat', 'Hip Hop Dance', 'Neon Aesthetic', 'Anime Vibe'].map(
                (tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => {
                      setGifQuery(tag);
                      handleRealGifSearch(tag);
                    }}
                    className="px-3 py-1 rounded-full bg-purple-500/20 hover:bg-purple-500/35 border border-purple-400/30 text-purple-200 text-[11px] font-bold whitespace-nowrap shrink-0"
                  >
                    {tag}
                  </button>
                )
              )}
            </div>

            <div className="grid grid-cols-2 gap-2.5 max-h-72 overflow-y-auto pr-1">
              {gifResults.map((gif) => (
                <button
                  key={gif.id}
                  type="button"
                  onClick={() => {
                    playAutoChime(587.33);
                    onAddPost({
                      id: `post-${Date.now()}`,
                      authorId: currentUser.id,
                      authorName: currentUser.username,
                      authorAvatar: currentUser.avatar,
                      type: 'gif',
                      title: (gif.title || gifQuery || 'ANIMATED GIF')
                        .slice(0, 24)
                        .toUpperCase(),
                      mediaUrl: gif.url,
                      likes: [],
                      comments: [],
                      createdAt: Date.now(),
                      beatFreq: 130,
                    });
                    onClose();
                  }}
                  className="group relative rounded-2xl overflow-hidden border border-white/15 bg-black aspect-square"
                >
                  <img
                    src={gif.url}
                    alt={gif.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition"
                  />
                  <span className="absolute bottom-1.5 right-1.5 bg-purple-600/95 text-white text-[10px] font-extrabold px-2 py-0.5 rounded-md shadow">
                    POST GIF
                  </span>
                </button>
              ))}
            </div>
          </>
        )}

        {/* REAL STICKER & AI DIE-CUT STICKER CREATOR MODAL */}
        {activeModal === 'sticker' && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Sticker className="w-5 h-5 text-cyan-400" />
                Real Stickers &amp; AI Sticker Maker
              </h3>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomSticker} className="space-y-2">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={stickerPrompt}
                  onChange={(e) => setStickerPrompt(e.target.value)}
                  placeholder="Ask for any sticker (e.g. skate cat, sneaker, crown)..."
                  className="flex-1 h-11 px-3.5 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white"
                />
                <button
                  type="button"
                  onClick={() => handleSearchRealStickers()}
                  disabled={searchingStickers}
                  className="h-11 px-3.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-cyan-300 border border-cyan-400/40 font-extrabold text-xs shrink-0"
                >
                  {searchingStickers ? '...' : 'Search'}
                </button>
                <button
                  type="submit"
                  disabled={creatingSticker}
                  className="h-11 px-3.5 rounded-xl bg-cyan-400 text-black font-extrabold text-xs shrink-0 flex items-center gap-1"
                >
                  <Wand2 className="w-4 h-4" />
                  {creatingSticker ? '...' : 'AI Make'}
                </button>
              </div>
            </form>

            {/* Quick Sticker Tags */}
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
              {['Skate Cat', 'Powerpuff', 'Sneakers', 'Boombox', 'Neon Heart', 'Crown'].map(
                (tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => {
                      setStickerPrompt(tag);
                      handleSearchRealStickers(tag);
                    }}
                    className="px-3 py-1 rounded-full bg-cyan-500/15 hover:bg-cyan-500/30 border border-cyan-400/30 text-cyan-300 text-[11px] font-bold whitespace-nowrap shrink-0"
                  >
                    {tag}
                  </button>
                )
              )}
            </div>

            {/* Custom AI-Generated Picture Sticker Preview (when user taps AI Make) */}
            {(stickerPreviewUrl || creatingSticker) && (
              <div className="bg-zinc-950 border border-cyan-400/40 rounded-2xl p-3 flex flex-col items-center gap-2.5 relative">
                {creatingSticker ? (
                  <div className="h-40 flex flex-col items-center justify-center text-xs font-extrabold text-cyan-300 gap-2">
                    <Sparkles className="w-6 h-6 animate-spin" />
                    <span>Generating Custom AI Die-Cut Sticker...</span>
                  </div>
                ) : (
                  <>
                    <img
                      src={stickerPreviewUrl}
                      alt={stickerPrompt}
                      referrerPolicy="no-referrer"
                      className="w-44 h-44 rounded-xl object-contain"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        playAutoChime(659.25);
                        onAddPost({
                          id: `post-${Date.now()}`,
                          authorId: currentUser.id,
                          authorName: currentUser.username,
                          authorAvatar: currentUser.avatar,
                          type: 'sticker',
                          title: (stickerPrompt || 'AI STICKER')
                            .toUpperCase()
                            .slice(0, 24),
                          mediaUrl: stickerPreviewUrl,
                          likes: [],
                          comments: [],
                          createdAt: Date.now(),
                          beatFreq: 150,
                        });
                        onClose();
                      }}
                      className="w-full h-10 rounded-xl bg-gradient-to-r from-cyan-400 via-pink-500 to-amber-400 text-black font-extrabold text-xs shadow-lg"
                    >
                      Post Custom AI Sticker to Feed
                    </button>
                  </>
                )}
              </div>
            )}

            {/* Real Transparent Animated & Die-Cut Stickers Grid */}
            <div>
              <p className="text-[11px] font-bold text-zinc-400 mb-1.5">
                Tap any real sticker below to post to your feed:
              </p>
              <div className="grid grid-cols-3 gap-2 max-h-60 overflow-y-auto pr-1">
                {stickerGallery.map((st, idx) => (
                  <button
                    key={`${st.id}-${idx}`}
                    type="button"
                    onClick={() => {
                      playAutoChime(587.33);
                      onAddPost({
                        id: `post-${Date.now()}`,
                        authorId: currentUser.id,
                        authorName: currentUser.username,
                        authorAvatar: currentUser.avatar,
                        type: 'sticker',
                        title: (st.title || stickerPrompt || 'STICKER').slice(0, 24),
                        mediaUrl: st.url,
                        likes: [],
                        comments: [],
                        createdAt: Date.now(),
                        beatFreq: 150,
                      });
                      onClose();
                    }}
                    className="rounded-2xl overflow-hidden border border-white/15 bg-zinc-900/80 p-2 aspect-square relative group flex items-center justify-center hover:border-cyan-400"
                  >
                    <img
                      src={st.url}
                      alt={st.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain group-hover:scale-110 transition"
                    />
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {/* WEB & GITHUB HTML EXPORT MODAL */}
        {activeModal === 'web' && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-white">
                Web &amp; GitHub HTML Export
              </h3>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed">
              Tomboy Colorverse automatically saves all your photos, videos, MP3 music, and profiles in your phone storage. You can also download a standalone{' '}
              <code className="text-pink-400 font-bold">index.html</code> file ready to upload directly to your GitHub repository!
            </p>
            <button
              type="button"
              onClick={downloadStandaloneGithubHtml}
              className="w-full h-12 rounded-xl bg-gradient-to-r from-pink-500 via-amber-400 to-cyan-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg"
            >
              <Download className="w-4 h-4" />
              Download index.html for GitHub
            </button>
          </>
        )}

        {/* COMMUNITY CHAT MODAL */}
        {activeModal === 'chat' && (
          <>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-extrabold text-white">
                Colorverse Lounge Chat
              </h3>
              <button
                type="button"
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2.5 max-h-64 overflow-y-auto bg-zinc-950 p-3 rounded-2xl border border-white/10">
              {messages.map((m) => (
                <div key={m.id} className="flex items-start gap-2 text-xs">
                  <span className="font-extrabold text-pink-400 shrink-0">
                    {m.username}:
                  </span>
                  <span className="text-zinc-200">{m.text}</span>
                </div>
              ))}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!chatInput.trim()) return;
                onSendMessage(chatInput.trim());
                setChatInput('');
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Message everyone..."
                className="flex-1 h-11 px-3.5 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white"
              />
              <button
                type="submit"
                className="h-11 px-4 rounded-xl bg-blue-500 text-white font-extrabold text-xs flex items-center gap-1"
              >
                <Send className="w-3.5 h-3.5" />
                Send
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
