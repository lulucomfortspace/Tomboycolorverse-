import React, { useState } from 'react';
import { AvatarCustomizationConfig } from '../types';
import {
  DEFAULT_AVATAR_CONFIG,
  generateCustomAiArtAsync,
  renderCustomAvatarSvg,
} from '../utils/mediaEngine';
import { Shuffle, Sparkles, Check, X, Wand2 } from 'lucide-react';

interface AvatarCustomizerModalProps {
  initialConfig?: AvatarCustomizationConfig;
  onSave: (avatarDataUrl: string, config: AvatarCustomizationConfig) => void;
  onClose: () => void;
}

const SKIN_TONES = [
  { label: 'Honey', hex: '#e0a96d' },
  { label: 'Bronze', hex: '#c68642' },
  { label: 'Espresso', hex: '#5c3824' },
  { label: 'Mahogany', hex: '#8d5524' },
  { label: 'Golden', hex: '#f1c27d' },
  { label: 'Porcelain', hex: '#ffdbac' },
  { label: 'Rich Cocoa', hex: '#3d2314' },
  { label: 'Cyber Blue', hex: '#38bdf8' },
];

const HAIR_STYLES: Array<{
  id: AvatarCustomizationConfig['hairStyle'];
  label: string;
}> = [
  { id: 'snapback', label: 'LV Snapback' },
  { id: 'beanie', label: 'Skater Beanie' },
  { id: 'long-waves', label: 'Long Waves' },
  { id: 'space-buns', label: 'Space Buns' },
  { id: 'ponytail', label: 'High Ponytail' },
  { id: 'locs', label: 'Gold Cuff Locs' },
  { id: 'spiky', label: 'Spiky Street' },
  { id: 'bucket', label: 'Bucket Hat' },
  { id: 'afro', label: 'Curly Afro' },
  { id: 'waves', label: 'Waves / Fade' },
];

const COLORS = [
  '#18181b',
  '#ec4899',
  '#06b6d4',
  '#10b981',
  '#f59e0b',
  '#9333ea',
  '#ef4444',
  '#fde047',
  '#ffffff',
];

const EYEWEAR_OPTIONS: Array<{
  id: AvatarCustomizationConfig['eyewear'];
  label: string;
}> = [
  { id: 'lv-shades', label: 'LV Shades' },
  { id: 'cyber-visor', label: 'Cyber Visor' },
  { id: 'star-glasses', label: 'Star Shades' },
  { id: 'round-gold', label: 'Gold Round' },
  { id: 'none', label: 'No Glasses' },
];

const OUTFIT_OPTIONS: Array<{
  id: AvatarCustomizationConfig['outfit'];
  label: string;
}> = [
  { id: 'lv-hoodie', label: 'LV Hoodie' },
  { id: 'bomber', label: 'Bomber Jacket' },
  { id: 'track-jacket', label: 'Track Jacket' },
  { id: 'gold-chain', label: 'Gold Chain Tee' },
  { id: 'street-tee', label: 'Colorverse Tee' },
];

const EXPRESSIONS: Array<{
  id: AvatarCustomizationConfig['expression'];
  label: string;
}> = [
  { id: 'smirk', label: 'Smirk' },
  { id: 'smile', label: 'Big Smile' },
  { id: 'wink', label: 'Wink' },
  { id: 'chill', label: 'Chill' },
  { id: 'bubblegum', label: 'Bubblegum' },
];

const BG_STYLES: Array<{
  id: AvatarCustomizationConfig['bgStyle'];
  label: string;
}> = [
  { id: 'rainbow', label: 'Rainbow LV' },
  { id: 'cyber-cyan', label: 'Cyber Cyan' },
  { id: 'sunset-pink', label: 'Sunset Pink' },
  { id: 'midnight-gold', label: 'Midnight Stars' },
  { id: 'emerald', label: 'Emerald Glow' },
];

export const AvatarCustomizerModal: React.FC<AvatarCustomizerModalProps> = ({
  initialConfig,
  onSave,
  onClose,
}) => {
  const [config, setConfig] = useState<AvatarCustomizationConfig>({
    ...DEFAULT_AVATAR_CONFIG,
    ...(initialConfig || {}),
    gender: initialConfig?.gender || 'female',
  });
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiAvatarUrl, setAiAvatarUrl] = useState<string | null>(null);
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  const previewUrl = aiAvatarUrl || renderCustomAvatarSvg(config);

  const handleRandomize = () => {
    setAiAvatarUrl(null);
    const pick = <T,>(arr: T[]): T =>
      arr[Math.floor(Math.random() * arr.length)];
    setConfig({
      gender: config.gender,
      skinTone: pick(SKIN_TONES).hex,
      hairStyle: pick(HAIR_STYLES).id,
      hairColor: pick(COLORS),
      hatColor: pick(COLORS),
      eyewear: pick(EYEWEAR_OPTIONS).id,
      outfit: pick(OUTFIT_OPTIONS).id,
      outfitColor: pick(COLORS),
      expression: pick(EXPRESSIONS).id,
      bgStyle: pick(BG_STYLES).id,
    });
  };

  const handleGenerateAiAvatar = async () => {
    const genderWord =
      config.gender === 'female' ? 'female girl' : 'male boy';
    const promptText =
      aiPrompt.trim() ||
      `Stylized ${genderWord} streetwear character in Rainbow LV Drip`;
    setIsGeneratingAi(true);
    const generated = await generateCustomAiArtAsync(
      `${promptText} (${genderWord} character avatar portrait vibrant streetwear)`,
      '1:1',
      'sticker'
    );
    setAiAvatarUrl(generated);
    setIsGeneratingAi(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-[#121217] border border-white/20 rounded-3xl max-w-lg w-full p-5 shadow-2xl space-y-4 my-auto max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-pink-400" />
            <h2 className="text-lg font-extrabold text-white">
              Customize Your Own Avatar
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-zinc-800 hover:bg-zinc-700 text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Avatar Preview + Female / Male Selector */}
        <div className="flex flex-col items-center gap-3 bg-zinc-900/90 border border-white/10 rounded-2xl p-4">
          <div className="story-rainbow-circle w-28 h-28">
            <div className="story-rainbow-inner">
              <img
                src={previewUrl}
                alt="Custom Avatar Preview"
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Female / Male Switcher */}
          <div className="grid grid-cols-2 gap-2 w-full max-w-xs bg-zinc-950 p-1 rounded-2xl border border-white/15">
            <button
              type="button"
              onClick={() => {
                setAiAvatarUrl(null);
                setConfig({
                  ...config,
                  gender: 'female',
                  hairStyle:
                    config.hairStyle === 'waves'
                      ? 'long-waves'
                      : config.hairStyle,
                });
              }}
              className={`h-10 rounded-xl font-extrabold text-xs flex items-center justify-center gap-1.5 transition ${
                config.gender === 'female'
                  ? 'bg-gradient-to-r from-pink-500 to-fuchsia-500 text-white shadow-md'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Female ♀
            </button>
            <button
              type="button"
              onClick={() => {
                setAiAvatarUrl(null);
                setConfig({
                  ...config,
                  gender: 'male',
                  hairStyle:
                    config.hairStyle === 'long-waves' ||
                    config.hairStyle === 'space-buns' ||
                    config.hairStyle === 'ponytail'
                      ? 'waves'
                      : config.hairStyle,
                });
              }}
              className={`h-10 rounded-xl font-extrabold text-xs flex items-center justify-center gap-1.5 transition ${
                config.gender === 'male'
                  ? 'bg-gradient-to-r from-cyan-400 to-blue-500 text-black shadow-md'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              Male ♂
            </button>
          </div>

          <div className="flex items-center gap-2 flex-wrap justify-center">
            <button
              type="button"
              onClick={handleRandomize}
              className="h-9 px-3.5 rounded-full bg-gradient-to-r from-pink-500 via-amber-400 to-cyan-400 text-black font-extrabold text-xs flex items-center gap-1.5 shadow"
            >
              <Shuffle className="w-3.5 h-3.5" />
              Randomize {config.gender === 'female' ? 'Female' : 'Male'} Look
            </button>
            {aiAvatarUrl && (
              <button
                type="button"
                onClick={() => setAiAvatarUrl(null)}
                className="h-9 px-3.5 rounded-full bg-zinc-800 text-zinc-200 font-bold text-xs"
              >
                Back to 2D Builder
              </button>
            )}
          </div>
        </div>

        {/* Customization Controls */}
        <div className="space-y-3.5 text-xs">
          {/* Skin Tone */}
          <div>
            <label className="block font-extrabold text-zinc-300 mb-1.5">
              1. Skin Tone
            </label>
            <div className="flex items-center gap-2 flex-wrap">
              {SKIN_TONES.map((tone) => (
                <button
                  key={tone.hex}
                  type="button"
                  onClick={() => {
                    setAiAvatarUrl(null);
                    setConfig({ ...config, skinTone: tone.hex });
                  }}
                  title={tone.label}
                  className={`w-8 h-8 rounded-full border-2 transition ${
                    config.skinTone === tone.hex
                      ? 'border-white scale-110 shadow-lg'
                      : 'border-white/20'
                  }`}
                  style={{ backgroundColor: tone.hex }}
                />
              ))}
            </div>
          </div>

          {/* Hairstyle / Hat */}
          <div>
            <label className="block font-extrabold text-zinc-300 mb-1.5">
              2. Hair &amp; Hat Style
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
              {HAIR_STYLES.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setAiAvatarUrl(null);
                    setConfig({ ...config, hairStyle: item.id });
                  }}
                  className={`h-9 px-2 rounded-xl font-extrabold text-[11px] border transition ${
                    config.hairStyle === item.id
                      ? 'bg-pink-500 text-white border-white'
                      : 'bg-zinc-900 text-zinc-300 border-white/10'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Hat & Hair Color */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-extrabold text-zinc-300 mb-1.5">
                3. Hair Color
              </label>
              <div className="flex items-center gap-1.5 flex-wrap">
                {COLORS.map((hex) => (
                  <button
                    key={`hair-${hex}`}
                    type="button"
                    onClick={() => {
                      setAiAvatarUrl(null);
                      setConfig({ ...config, hairColor: hex });
                    }}
                    className={`w-6 h-6 rounded-full border-2 ${
                      config.hairColor === hex
                        ? 'border-white scale-110'
                        : 'border-white/20'
                    }`}
                    style={{ backgroundColor: hex }}
                  />
                ))}
              </div>
            </div>

            <div>
              <label className="block font-extrabold text-zinc-300 mb-1.5">
                4. Hat / Cap Color
              </label>
              <div className="flex items-center gap-1.5 flex-wrap">
                {COLORS.map((hex) => (
                  <button
                    key={`hat-${hex}`}
                    type="button"
                    onClick={() => {
                      setAiAvatarUrl(null);
                      setConfig({ ...config, hatColor: hex });
                    }}
                    className={`w-6 h-6 rounded-full border-2 ${
                      config.hatColor === hex
                        ? 'border-white scale-110'
                        : 'border-white/20'
                    }`}
                    style={{ backgroundColor: hex }}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Eyewear / Shades */}
          <div>
            <label className="block font-extrabold text-zinc-300 mb-1.5">
              5. Shades &amp; Eyewear
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
              {EYEWEAR_OPTIONS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setAiAvatarUrl(null);
                    setConfig({ ...config, eyewear: item.id });
                  }}
                  className={`h-9 px-2 rounded-xl font-extrabold text-[11px] border transition ${
                    config.eyewear === item.id
                      ? 'bg-cyan-400 text-black border-white'
                      : 'bg-zinc-900 text-zinc-300 border-white/10'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Streetwear Outfit & Color */}
          <div>
            <label className="block font-extrabold text-zinc-300 mb-1.5">
              6. Streetwear Outfit &amp; Color
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5 mb-2">
              {OUTFIT_OPTIONS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setAiAvatarUrl(null);
                    setConfig({ ...config, outfit: item.id });
                  }}
                  className={`h-9 px-2 rounded-xl font-extrabold text-[11px] border transition ${
                    config.outfit === item.id
                      ? 'bg-amber-400 text-black border-white'
                      : 'bg-zinc-900 text-zinc-300 border-white/10'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              {COLORS.map((hex) => (
                <button
                  key={`outfit-${hex}`}
                  type="button"
                  onClick={() => {
                    setAiAvatarUrl(null);
                    setConfig({ ...config, outfitColor: hex });
                  }}
                  className={`w-6 h-6 rounded-full border-2 ${
                    config.outfitColor === hex
                      ? 'border-white scale-110'
                      : 'border-white/20'
                  }`}
                  style={{ backgroundColor: hex }}
                />
              ))}
            </div>
          </div>

          {/* Expression & Backdrop */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-extrabold text-zinc-300 mb-1.5">
                7. Expression
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {EXPRESSIONS.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setAiAvatarUrl(null);
                      setConfig({ ...config, expression: item.id });
                    }}
                    className={`h-8 rounded-lg font-extrabold text-[11px] border ${
                      config.expression === item.id
                        ? 'bg-emerald-400 text-black border-white'
                        : 'bg-zinc-900 text-zinc-300 border-white/10'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block font-extrabold text-zinc-300 mb-1.5">
                8. Backdrop Theme
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {BG_STYLES.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setAiAvatarUrl(null);
                      setConfig({ ...config, bgStyle: item.id });
                    }}
                    className={`h-8 rounded-lg font-extrabold text-[10px] border ${
                      config.bgStyle === item.id
                        ? 'bg-purple-500 text-white border-white'
                        : 'bg-zinc-900 text-zinc-300 border-white/10'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Optional AI Avatar Generator */}
          <div className="bg-zinc-900/90 border border-white/10 rounded-2xl p-3 space-y-2">
            <label className="block font-extrabold text-amber-400 flex items-center gap-1.5">
              <Wand2 className="w-3.5 h-3.5" />
              Or Generate Custom AI {config.gender === 'female' ? 'Female' : 'Male'} Avatar
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder={`e.g. Cool ${config.gender} skater with rainbow LV hoodie...`}
                className="flex-1 h-9 px-3 rounded-xl bg-zinc-950 border border-white/15 text-xs text-white"
              />
              <button
                type="button"
                disabled={isGeneratingAi}
                onClick={handleGenerateAiAvatar}
                className="h-9 px-3.5 rounded-xl bg-amber-400 text-black font-extrabold text-xs shrink-0 disabled:opacity-60"
              >
                {isGeneratingAi ? 'Making...' : 'AI Avatar'}
              </button>
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="pt-2 flex gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="h-11 px-4 rounded-xl bg-zinc-800 text-zinc-300 font-bold text-xs"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => onSave(previewUrl, config)}
            className="flex-1 h-11 rounded-xl bg-gradient-to-r from-pink-500 via-amber-400 to-cyan-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg"
          >
            <Check className="w-4 h-4" />
            Save {config.gender === 'female' ? 'Female' : 'Male'} Avatar
          </button>
        </div>
      </div>
    </div>
  );
};
