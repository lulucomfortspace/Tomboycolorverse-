import React, { useEffect, useRef, useState } from 'react';
import { StoryReel, UserAccount } from '../types';
import { createSynthBeatWavUrl } from '../utils/mediaEngine';
import { X, Heart, Trash2, ChevronLeft, ChevronRight, Volume2, Sparkles } from 'lucide-react';

interface StoryReelViewerProps {
  stories: StoryReel[];
  initialIndex: number;
  currentUser: UserAccount;
  onClose: () => void;
  onToggleLikeStory: (storyId: string) => void;
  onReactStory: (storyId: string, emoji: string) => void;
  onDeleteStory: (storyId: string) => void;
}

interface FloatingReactionParticle {
  id: string;
  emoji: string;
  leftPct: number;
  driftPx: number;
  scale: number;
  delayMs: number;
}

const STORY_QUICK_REACTIONS = ['❤️', '🔥', '😂', '🌈', '👑', '💯'];

export const StoryReelViewer: React.FC<StoryReelViewerProps> = ({
  stories,
  initialIndex,
  currentUser,
  onClose,
  onToggleLikeStory,
  onReactStory,
  onDeleteStory,
}) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [progress, setProgress] = useState(0);
  const [floatingReactions, setFloatingReactions] = useState<FloatingReactionParticle[]>([]);
  const [lastClickedEmoji, setLastClickedEmoji] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const story = stories[currentIndex] || stories[0];

  useEffect(() => {
    if (!story) {
      onClose();
    }
  }, [story, onClose]);

  const goNext = () => {
    setProgress(0);
    setFloatingReactions([]);
    setCurrentIndex((prev) => (prev + 1) % stories.length);
  };

  const goPrev = () => {
    setProgress(0);
    setFloatingReactions([]);
    setCurrentIndex((prev) => (prev - 1 + stories.length) % stories.length);
  };

  const spawnFloatingBurst = (emoji: string) => {
    const now = Date.now();
    const burstCount = 6;
    const newParticles: FloatingReactionParticle[] = Array.from({ length: burstCount }).map(
      (_, idx) => ({
        id: `fr-${now}-${idx}-${Math.random().toString(36).slice(2, 6)}`,
        emoji,
        leftPct: 16 + Math.random() * 68,
        driftPx: Math.round((Math.random() - 0.5) * 110),
        scale: Number((0.95 + Math.random() * 0.65).toFixed(2)),
        delayMs: idx * 55,
      })
    );

    setFloatingReactions((prev) => [...prev.slice(-24), ...newParticles]);
    setLastClickedEmoji(emoji);

    window.setTimeout(() => {
      const idsToRemove = new Set(newParticles.map((p) => p.id));
      setFloatingReactions((prev) => prev.filter((p) => !idsToRemove.has(p.id)));
    }, 1750);
  };

  const handleQuickReaction = (emoji: string) => {
    if (!story) return;
    spawnFloatingBurst(emoji);
    onReactStory(story.id, emoji);
  };

  const isYouTubeStory = Boolean(
    story && (story.youtubeId || story.mediaType === 'youtube')
  );
  const isActualVideoFile =
    story &&
    (story.mediaUrl.startsWith('data:video') ||
      story.mediaUrl.endsWith('.mp4') ||
      story.mediaUrl.endsWith('.webm'));

  useEffect(() => {
    if (!story) return;
    setProgress(0);

    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }

    if (isYouTubeStory) {
      setProgress(100);
      return;
    }

    if (isActualVideoFile) {
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
        videoRef.current.muted = false;
        videoRef.current.volume = 1.0;
        videoRef.current.play().catch(() => {});
      }
      return;
    }

    const soundUrl =
      story.audioUrl || createSynthBeatWavUrl(story.beatFreq || 120, 6);
    const audio = new Audio(soundUrl);
    audio.loop = true;
    audio.volume = 0.9;
    audio.play().catch(() => {});
    audioRef.current = audio;

    const durationMs = 6000;
    const intervalMs = 60;
    let elapsed = 0;
    const timer = setInterval(() => {
      elapsed += intervalMs;
      const pct = Math.min(100, (elapsed / durationMs) * 100);
      setProgress(pct);
      if (elapsed >= durationMs) {
        clearInterval(timer);
        goNext();
      }
    }, intervalMs);

    return () => {
      clearInterval(timer);
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, [currentIndex, story?.id, isYouTubeStory, isActualVideoFile]);

  if (!story) return null;

  const isLiked = story.likes.includes(currentUser.id);
  const reactionsMap = story.reactions || {};
  const totalReactionsCount = Object.values(reactionsMap).reduce(
    (sum, val) => sum + (Number(val) || 0),
    0
  );
  const recentEvents = story.reactionEvents || [];
  const latestReactionEvent =
    recentEvents.length > 0 ? recentEvents[recentEvents.length - 1] : null;

  return (
    <div className="fixed inset-0 z-50 bg-black flex items-center justify-center">
      <div className="relative w-full h-full max-w-md mx-auto bg-zinc-950 flex flex-col justify-between overflow-hidden">
        {/* Top Story Progress Bars */}
        <div className="relative z-20 pt-3 px-3 space-y-3 bg-gradient-to-b from-black/85 via-black/45 to-transparent pb-6">
          <div className="flex gap-1.5">
            {stories.map((s, idx) => (
              <div
                key={s.id}
                className="flex-1 h-1 rounded-full bg-white/30 overflow-hidden"
              >
                <div
                  className="h-full bg-gradient-to-r from-pink-500 via-amber-400 to-cyan-400 transition-all duration-75"
                  style={{
                    width:
                      idx < currentIndex
                        ? '100%'
                        : idx === currentIndex
                        ? `${progress}%`
                        : '0%',
                  }}
                />
              </div>
            ))}
          </div>

          {/* Author Info & Delete / Close Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="story-rainbow-circle w-10 h-10 shrink-0">
                <div className="story-rainbow-inner">
                  <img
                    src={story.authorAvatar}
                    alt={story.authorName}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <div>
                <p className="text-sm font-extrabold text-white leading-tight">
                  {story.authorName}
                </p>
                <p className="text-[11px] text-cyan-300 flex items-center gap-1">
                  <Volume2 className="w-3 h-3 animate-pulse" />
                  Rainbow Loop Story • 24H
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  onDeleteStory(story.id);
                  if (stories.length <= 1) onClose();
                }}
                className="h-10 px-3 rounded-full bg-red-500/25 border border-red-400/50 flex items-center gap-1 text-red-200 hover:bg-red-500/40 text-xs font-bold"
                title="Delete Story"
              >
                <Trash2 className="w-4 h-4" />
                Delete
              </button>
              <button
                type="button"
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-white/15 flex items-center justify-center text-white hover:bg-white/25"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Full-Screen Media Canvas */}
        <div className="absolute inset-0 flex items-center justify-center bg-black">
          {isYouTubeStory && story.youtubeId ? (
            <div className="w-full px-2 z-20">
              <div className="aspect-video w-full rounded-2xl overflow-hidden border border-white/20 shadow-2xl">
                <iframe
                  src={`https://www.youtube.com/embed/${story.youtubeId}?autoplay=1&playsinline=1&rel=0`}
                  title={story.caption}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                  className="w-full h-full border-0"
                />
              </div>
            </div>
          ) : isActualVideoFile ? (
            <video
              ref={videoRef}
              src={story.mediaUrl}
              autoPlay
              playsInline
              muted={false}
              onTimeUpdate={(e) => {
                const el = e.currentTarget;
                if (el.duration) {
                  setProgress((el.currentTime / el.duration) * 100);
                }
              }}
              onEnded={() => {
                if (stories.length === 1 && videoRef.current) {
                  videoRef.current.currentTime = 0;
                  videoRef.current.play().catch(() => {});
                } else {
                  goNext();
                }
              }}
              className="w-full h-full object-contain"
            />
          ) : (
            <img
              src={story.mediaUrl}
              alt={story.caption}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          )}
        </div>

        {/* Floating Quick-Reaction Emoji Overlay */}
        <div className="pointer-events-none absolute inset-0 z-30 overflow-hidden">
          {floatingReactions.map((item) => (
            <span
              key={item.id}
              className="story-floating-reaction text-3xl sm:text-4xl"
              style={
                {
                  left: `${item.leftPct}%`,
                  animationDelay: `${item.delayMs}ms`,
                  '--drift-x': `${item.driftPx}px`,
                  '--reaction-scale': item.scale,
                } as React.CSSProperties
              }
            >
              {item.emoji}
            </span>
          ))}
        </div>

        {/* Left / Right Tap Navigation Zones */}
        <button
          type="button"
          onClick={goPrev}
          aria-label="Previous Story"
          className="absolute left-0 top-20 bottom-40 w-1/4 z-10 flex items-center justify-start pl-2 opacity-0 hover:opacity-100 transition-opacity"
        >
          <div className="w-9 h-9 rounded-full bg-black/50 flex items-center justify-center text-white">
            <ChevronLeft className="w-5 h-5" />
          </div>
        </button>
        <button
          type="button"
          onClick={goNext}
          aria-label="Next Story"
          className="absolute right-0 top-20 bottom-40 w-1/4 z-10 flex items-center justify-end pr-2 opacity-0 hover:opacity-100 transition-opacity"
        >
          <div className="w-9 h-9 rounded-full bg-black/50 flex items-center justify-center text-white">
            <ChevronRight className="w-5 h-5" />
          </div>
        </button>

        {/* Bottom Engagement Metadata, Quick-Reaction Bar & Caption */}
        <div className="relative z-20 p-3.5 bg-gradient-to-t from-black/95 via-black/75 to-transparent space-y-2.5">
          {/* Live Story Engagement Metadata Pill */}
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-[11px] font-extrabold text-white">
              <Sparkles className="w-3 h-3 text-amber-300" />
              <span>
                {totalReactionsCount} {totalReactionsCount === 1 ? 'Reaction' : 'Reactions'}
              </span>
              <span className="text-white/40">•</span>
              <span className="text-pink-300">
                {story.likes.length} {story.likes.length === 1 ? 'Like' : 'Likes'}
              </span>
            </div>

            {latestReactionEvent && (
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-pink-500/20 border border-pink-400/40 text-[11px] font-bold text-pink-100 animate-pulse">
                <span>{latestReactionEvent.emoji}</span>
                <span className="truncate max-w-[140px]">
                  @{latestReactionEvent.username} reacted
                </span>
              </div>
            )}
          </div>

          {/* Quick-Reaction Emoji Bar (❤️, 🔥, 😂, 🌈, 👑, 💯) */}
          <div className="flex items-center justify-between gap-1.5 bg-black/65 backdrop-blur-md border border-white/20 rounded-2xl px-2.5 py-2 shadow-xl">
            {STORY_QUICK_REACTIONS.map((emoji) => {
              const count = reactionsMap[emoji] || 0;
              const isJustClicked = lastClickedEmoji === emoji;
              return (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => handleQuickReaction(emoji)}
                  className={`flex-1 h-11 rounded-xl flex items-center justify-center gap-1 border transition active:scale-125 ${
                    count > 0
                      ? 'bg-gradient-to-b from-white/20 to-white/10 border-pink-400/60 text-white shadow-sm'
                      : 'bg-white/5 border-white/10 text-zinc-200 hover:bg-white/15'
                  } ${isJustClicked ? 'ring-2 ring-amber-300' : ''}`}
                  title={`React with ${emoji}`}
                >
                  <span className="text-lg sm:text-xl leading-none select-none">
                    {emoji}
                  </span>
                  {count > 0 && (
                    <span className="text-[11px] font-extrabold text-amber-300">
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Caption & Heart Like Button */}
          <div className="flex items-center justify-between gap-3 pt-0.5">
            <p className="text-sm font-bold text-white drop-shadow line-clamp-2">
              {story.caption}
            </p>
            <button
              type="button"
              onClick={() => {
                if (!isLiked) {
                  spawnFloatingBurst('❤️');
                }
                onToggleLikeStory(story.id);
              }}
              className={`h-10 px-4 rounded-full flex items-center gap-1.5 font-bold text-xs border shrink-0 transition active:scale-95 ${
                isLiked
                  ? 'bg-pink-500 text-white border-pink-400 shadow-[0_0_12px_rgba(236,72,153,0.6)]'
                  : 'bg-black/60 text-white border-white/25 hover:bg-white/15'
              }`}
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
              <span>{story.likes.length}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
