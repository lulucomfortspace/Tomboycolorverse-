import React, { useEffect, useState } from 'react';
import { AvatarCustomizationConfig, FeedPost, UserAccount } from '../types';
import {
  createSynthBeatWavUrl,
  generateCustomAiArtAsync,
  PRESET_PROFILE_SONGS,
} from '../utils/mediaEngine';
import { fileToDataUrl } from '../utils/phoneStorage';
import { downloadStandaloneGithubHtml } from '../utils/gifAndExport';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { AvatarCustomizerModal } from './AvatarCustomizerModal';
import {
  Camera,
  Check,
  Wand2,
  Image as ImageIcon,
  Heart,
  Trash2,
  Play,
  Download,
  Smartphone,
  Settings,
  LogOut,
  Music,
  Sparkles,
  Upload,
  X,
  Volume2,
  VolumeX,
  Pause,
} from 'lucide-react';

interface ProfileSettingsViewProps {
  currentUser: UserAccount;
  userPosts: FeedPost[];
  isSongPlaying: boolean;
  activeSongUrl?: string;
  activeSongTitle?: string;
  onToggleSongPlaying: () => void;
  onUpdateUser: (updated: UserAccount) => void;
  onSelectPost: (post: FeedPost) => void;
  onToggleLike: (postId: string) => void;
  onReactPost: (postId: string, emoji: string) => void;
  onDeletePost: (postId: string) => void;
  onLogout: () => void;
}

const POST_REACTIONS = ['❤️', '🔥', '😂', '🌈', '👑', '💯'];

export const ProfileSettingsView: React.FC<ProfileSettingsViewProps> = ({
  currentUser,
  userPosts,
  isSongPlaying,
  activeSongUrl,
  activeSongTitle,
  onToggleSongPlaying,
  onUpdateUser,
  onSelectPost,
  onToggleLike,
  onReactPost,
  onDeletePost,
  onLogout,
}) => {
  const [username, setUsername] = useState(currentUser.username);
  const [bio, setBio] = useState(currentUser.bio);
  const [savedNotice, setSavedNotice] = useState('');
  const [wallpaperPrompt, setWallpaperPrompt] = useState(
    'Rainbow LV Monogram Clouds & Neon Streetwear'
  );
  const [generatedWallpaper, setGeneratedWallpaper] = useState('');
  const [isGeneratingWallpaper, setIsGeneratingWallpaper] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [showAvatarCustomizer, setShowAvatarCustomizer] = useState(false);
  const [customSongTitle, setCustomSongTitle] = useState(
    currentUser.profileSongTitle || ''
  );

  useEffect(() => {
    setUsername(currentUser.username);
    setBio(currentUser.bio);
    setCustomSongTitle(currentUser.profileSongTitle || '');
  }, [currentUser.id]);

  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();

  const flashSaved = (msg: string) => {
    setSavedNotice(msg);
    setTimeout(() => setSavedNotice(''), 2800);
  };

  const getMergedBaseUser = (): UserAccount => ({
    ...currentUser,
    username: username.trim() || currentUser.username,
    bio: bio.trim(),
    updatedAt: Date.now(),
    isSeed: false,
  });

  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await fileToDataUrl(file);
    onUpdateUser({
      ...getMergedBaseUser(),
      avatar: url,
    });
    flashSaved('Profile picture uploaded & saved to phone storage!');
  };

  const handleSaveCustomAvatar = (
    avatarDataUrl: string,
    config: AvatarCustomizationConfig
  ) => {
    onUpdateUser({
      ...getMergedBaseUser(),
      avatar: avatarDataUrl,
      avatarConfig: config,
    });
    setShowAvatarCustomizer(false);
    flashSaved('Custom Avatar saved to your profile & phone storage!');
  };

  const handleSaveUsernameAndBio = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!username.trim()) return;
    onUpdateUser(getMergedBaseUser());
    flashSaved('Username & profile saved!');
  };

  const handleProfileSongUpload = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    let audioDataUrl = await fileToDataUrl(file);
    if (audioDataUrl.startsWith('data:application/octet-stream')) {
      audioDataUrl = audioDataUrl.replace(
        'data:application/octet-stream',
        'data:audio/mpeg'
      );
    }
    const cleanFileName = file.name.replace(/\.[^/.]+$/, '');
    const titleToUse = customSongTitle.trim() || cleanFileName || 'My Profile Song';
    setCustomSongTitle(titleToUse);
    onUpdateUser({
      ...getMergedBaseUser(),
      profileSongUrl: audioDataUrl,
      profileSongTitle: titleToUse,
      profileSongEnabled: true,
    });
    flashSaved(`Song "${titleToUse}" uploaded & auto-playing!`);
  };

  const handleSelectPresetSong = (
    title: string,
    freq: number,
    durationSec: number
  ) => {
    const wavUrl = createSynthBeatWavUrl(freq, durationSec);
    setCustomSongTitle(title);
    onUpdateUser({
      ...getMergedBaseUser(),
      profileSongUrl: wavUrl,
      profileSongTitle: title,
      profileSongEnabled: true,
    });
    flashSaved(`Profile song "${title}" set & auto-playing!`);
  };

  const handleRemoveProfileSong = () => {
    setCustomSongTitle('');
    onUpdateUser({
      ...getMergedBaseUser(),
      profileSongUrl: undefined,
      profileSongTitle: undefined,
      profileSongEnabled: false,
    });
    flashSaved('Profile song removed.');
  };

  const handleCustomBgUpload = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await fileToDataUrl(file);
    onUpdateUser({
      ...getMergedBaseUser(),
      wallpaperMode: 'custom',
      customWallpaperUrl: url,
    });
    flashSaved('Custom background uploaded & applied!');
  };

  const handleGenerateAiWallpaper = async () => {
    setIsGeneratingWallpaper(true);
    const url = await generateCustomAiArtAsync(
      `${wallpaperPrompt} ${Math.floor(Math.random() * 1000)}`,
      '9:16',
      'art'
    );
    setGeneratedWallpaper(url);
    onUpdateUser({
      ...getMergedBaseUser(),
      wallpaperMode: 'custom',
      customWallpaperUrl: url,
    });
    setIsGeneratingWallpaper(false);
    flashSaved('AI Wallpaper generated & set as background!');
  };

  return (
    <div className="max-w-3xl mx-auto px-4 pt-4 pb-28 space-y-6">
      {/* Profile Header Card */}
      <div className="bg-[#111115]/95 border border-white/15 rounded-3xl p-5 shadow-2xl space-y-5">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-pink-400" />
            <h2 className="text-lg font-extrabold text-white">
              @{currentUser.username}&apos;s Profile &amp; Settings
            </h2>
          </div>
          <div className="flex items-center gap-2">
            {savedNotice && (
              <span className="text-xs font-extrabold text-emerald-400 flex items-center gap-1">
                <Check className="w-4 h-4" />
                {savedNotice}
              </span>
            )}
            <button
              type="button"
              onClick={() => {
                if (
                  username.trim() &&
                  (username.trim() !== currentUser.username ||
                    bio.trim() !== currentUser.bio)
                ) {
                  onUpdateUser({
                    ...currentUser,
                    username: username.trim(),
                    bio: bio.trim(),
                  });
                }
                onLogout();
              }}
              className="h-9 px-3.5 rounded-full bg-zinc-800 hover:bg-red-500/20 border border-white/15 text-white hover:text-red-200 font-extrabold text-xs flex items-center gap-1.5 transition"
            >
              <LogOut className="w-3.5 h-3.5" />
              Log Out / Switch Account
            </button>
          </div>
        </div>

        {/* Avatar Customizer + Photo Upload + Username Editor */}
        <div className="flex flex-col sm:flex-row items-center gap-5">
          <div className="flex flex-col items-center gap-2 shrink-0">
            <div className="relative group">
              <div className="story-rainbow-circle w-28 h-28">
                <div className="story-rainbow-inner">
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.username}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <label
                title="Upload Photo Avatar"
                className="absolute bottom-0 right-0 z-10 w-9 h-9 rounded-full bg-cyan-400 text-black flex items-center justify-center shadow-lg border-2 border-black cursor-pointer hover:scale-105 transition"
              >
                <Camera className="w-4 h-4" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarUpload}
                  className="hidden"
                />
              </label>
            </div>

            <button
              type="button"
              onClick={() => setShowAvatarCustomizer(true)}
              className="h-9 px-3.5 rounded-full bg-gradient-to-r from-pink-500 via-amber-400 to-cyan-400 text-black font-extrabold text-xs flex items-center gap-1.5 shadow-md hover:scale-105 transition"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Customize Avatar
            </button>
          </div>

          <form
            onSubmit={handleSaveUsernameAndBio}
            className="flex-1 w-full space-y-3"
          >
            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1">
                Change Username
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                onBlur={() => {
                  if (
                    username.trim() &&
                    username.trim() !== currentUser.username
                  ) {
                    handleSaveUsernameAndBio();
                  }
                }}
                className="w-full h-11 px-3.5 rounded-xl bg-zinc-900 border border-white/15 text-sm font-bold text-white focus:outline-none focus:border-pink-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1">
                Bio
              </label>
              <input
                type="text"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                onBlur={() => {
                  if (bio.trim() !== currentUser.bio) {
                    handleSaveUsernameAndBio();
                  }
                }}
                className="w-full h-11 px-3.5 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white focus:outline-none focus:border-pink-500"
              />
            </div>
            <button
              type="submit"
              className="h-11 px-5 rounded-xl bg-gradient-to-r from-pink-500 via-amber-400 to-cyan-400 text-black font-extrabold text-xs shadow-md"
            >
              Save Username &amp; Profile
            </button>
          </form>
        </div>

        {/* PROFILE THEME SONG STUDIO (Plays Automatically + Turn ON/OFF) */}
        <div className="pt-4 border-t border-white/10 space-y-3.5">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Music className="w-4 h-4 text-pink-400" />
              Profile &amp; Feed Song (Plays Automatically • Turn ON or OFF)
            </h3>
            <div className="flex items-center gap-2">
              {(currentUser.profileSongUrl || activeSongUrl) && (
                <button
                  type="button"
                  onClick={onToggleSongPlaying}
                  className={`h-9 px-3.5 rounded-full font-extrabold text-xs flex items-center gap-1.5 border transition shadow-md ${
                    isSongPlaying
                      ? 'bg-emerald-400 text-black border-white shadow-[0_0_12px_rgba(16,185,129,0.5)]'
                      : 'bg-zinc-800 text-zinc-300 border-white/20 hover:bg-zinc-700'
                  }`}
                >
                  {isSongPlaying ? (
                    <>
                      <Volume2 className="w-4 h-4 animate-pulse" />
                      <span>SONG: ON (Playing)</span>
                    </>
                  ) : (
                    <>
                      <VolumeX className="w-4 h-4 text-red-400" />
                      <span>SONG: OFF (Paused)</span>
                    </>
                  )}
                </button>
              )}

              {currentUser.profileSongUrl && (
                <button
                  type="button"
                  onClick={handleRemoveProfileSong}
                  className="h-9 px-3 rounded-full bg-red-500/15 border border-red-400/30 text-xs font-bold text-red-300 hover:bg-red-500/25 flex items-center gap-1"
                >
                  <X className="w-3.5 h-3.5" />
                  Remove
                </button>
              )}
            </div>
          </div>

          {/* Current Active Profile Song Player */}
          {currentUser.profileSongUrl || activeSongUrl ? (
            <div className="bg-gradient-to-r from-pink-500/15 via-purple-500/15 to-cyan-500/15 border border-pink-500/40 rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <div
                  className={`w-10 h-10 rounded-full bg-pink-500 text-black flex items-center justify-center shrink-0 ${
                    isSongPlaying ? 'animate-spin' : ''
                  }`}
                >
                  <Music className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <p className="text-[11px] font-bold text-pink-300 uppercase tracking-wider flex items-center gap-1.5">
                    <span>
                      {isSongPlaying
                        ? 'Auto-Playing on Profile & Feed'
                        : 'Song Paused (Tap ON to Play)'}
                    </span>
                  </p>
                  <p className="text-xs sm:text-sm font-extrabold text-white truncate">
                    {currentUser.profileSongTitle ||
                      activeSongTitle ||
                      'My Profile Anthem'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={onToggleSongPlaying}
                className={`h-10 px-4 rounded-xl font-extrabold text-xs flex items-center justify-center gap-1.5 shrink-0 border transition ${
                  isSongPlaying
                    ? 'bg-pink-500 text-white border-pink-300 hover:bg-pink-600'
                    : 'bg-emerald-400 text-black border-white hover:bg-emerald-300'
                }`}
              >
                {isSongPlaying ? (
                  <>
                    <Pause className="w-4 h-4 fill-current" />
                    Turn Song OFF
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    Turn Song ON
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="bg-zinc-900/80 border border-white/10 rounded-2xl p-3.5 text-xs text-zinc-400">
              No profile song selected yet. Upload an MP3 song from your phone or
              pick a track below and it will play automatically!
            </div>
          )}

          {/* Upload MP3 / Audio File from Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <input
              type="text"
              value={customSongTitle}
              onChange={(e) => setCustomSongTitle(e.target.value)}
              placeholder="Song Title (optional before uploading)"
              className="h-11 px-3.5 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white"
            />
            <label className="h-11 px-4 rounded-xl bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-400 text-black font-extrabold text-xs flex items-center justify-center gap-2 cursor-pointer shadow-lg hover:opacity-95 transition">
              <Upload className="w-4 h-4" />
              Upload MP3 / Audio Song from Phone
              <input
                type="file"
                accept="audio/*,.mp3,.m4a,.wav,.ogg"
                onChange={handleProfileSongUpload}
                className="hidden"
              />
            </label>
          </div>

          {/* Preset Profile Songs */}
          <div className="space-y-1.5">
            <p className="text-[11px] font-bold text-zinc-400">
              Or tap a Colorverse Anthem to set as your Profile Song:
            </p>
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
              {PRESET_PROFILE_SONGS.map((track) => {
                const isSelected =
                  currentUser.profileSongTitle === track.title;
                return (
                  <button
                    key={track.id}
                    type="button"
                    onClick={() =>
                      handleSelectPresetSong(
                        track.title,
                        track.freq,
                        track.durationSec
                      )
                    }
                    className={`h-9 px-3 rounded-xl text-xs font-extrabold flex items-center gap-1.5 shrink-0 border transition ${
                      isSelected
                        ? 'bg-pink-500 text-white border-white shadow-md'
                        : 'bg-zinc-900 text-zinc-300 border-white/10 hover:text-white'
                    }`}
                  >
                    <Music className="w-3.5 h-3.5" />
                    {track.title}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Change Background & AI Wallpaper Generator */}
        <div className="pt-4 border-t border-white/10 space-y-4">
          <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-cyan-400" />
            App Background &amp; AI Wallpaper Generator
          </h3>

          {/* Preset & Upload Background Buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              type="button"
              onClick={() => {
                onUpdateUser({ ...currentUser, wallpaperMode: 'lv-light' });
                flashSaved('Rainbow LV White Wallpaper applied!');
              }}
              className={`h-11 rounded-xl text-xs font-extrabold border ${
                currentUser.wallpaperMode === 'lv-light'
                  ? 'bg-white text-black border-pink-500'
                  : 'bg-zinc-900 text-zinc-200 border-white/10'
              }`}
            >
              LV Rainbow Light
            </button>
            <button
              type="button"
              onClick={() => {
                onUpdateUser({ ...currentUser, wallpaperMode: 'lv-dark' });
                flashSaved('Rainbow LV Dark Wallpaper applied!');
              }}
              className={`h-11 rounded-xl text-xs font-extrabold border ${
                currentUser.wallpaperMode === 'lv-dark'
                  ? 'bg-pink-500 text-white border-white'
                  : 'bg-zinc-900 text-zinc-200 border-white/10'
              }`}
            >
              LV Rainbow Dark
            </button>
            <button
              type="button"
              onClick={() => {
                onUpdateUser({ ...currentUser, wallpaperMode: 'midnight' });
                flashSaved('Sleek Midnight Black applied!');
              }}
              className={`h-11 rounded-xl text-xs font-extrabold border ${
                currentUser.wallpaperMode === 'midnight'
                  ? 'bg-cyan-400 text-black border-white'
                  : 'bg-zinc-900 text-zinc-200 border-white/10'
              }`}
            >
              Sleek Dark Mode
            </button>
            <label className="h-11 rounded-xl bg-zinc-800 hover:bg-zinc-700 border border-pink-500/40 text-pink-300 text-xs font-extrabold flex items-center justify-center gap-1.5 cursor-pointer">
              <Camera className="w-4 h-4" />
              Upload Photo BG
              <input
                type="file"
                accept="image/*"
                onChange={handleCustomBgUpload}
                className="hidden"
              />
            </label>
          </div>

          {/* AI Wallpaper Generator Box */}
          <div className="bg-zinc-900/90 border border-white/10 rounded-2xl p-3.5 space-y-3">
            <label className="block text-xs font-extrabold text-amber-400 flex items-center gap-1.5">
              <Wand2 className="w-4 h-4" />
              AI Wallpaper Generator
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={wallpaperPrompt}
                onChange={(e) => setWallpaperPrompt(e.target.value)}
                placeholder="Describe your dream wallpaper..."
                className="flex-1 h-11 px-3.5 rounded-xl bg-zinc-950 border border-white/15 text-xs text-white"
              />
              <button
                type="button"
                disabled={isGeneratingWallpaper}
                onClick={handleGenerateAiWallpaper}
                className="h-11 px-4 rounded-xl bg-gradient-to-r from-amber-400 to-pink-500 text-black font-extrabold text-xs shrink-0 disabled:opacity-60"
              >
                {isGeneratingWallpaper ? 'Painting...' : 'Generate & Apply'}
              </button>
            </div>
            {generatedWallpaper && (
              <div className="flex items-center gap-3 pt-1">
                <img
                  src={generatedWallpaper}
                  alt="Generated AI Wallpaper"
                  referrerPolicy="no-referrer"
                  className="w-14 h-20 rounded-xl object-cover border border-white/20"
                />
                <p className="text-xs text-zinc-300">
                  Your custom AI Wallpaper is active and saved to phone storage!
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Save to Phone Home Screen & GitHub HTML Download */}
        <div className="pt-4 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {!isInstalled && (
            <button
              type="button"
              onClick={() => {
                if (isInstallable) {
                  install();
                } else {
                  setShowIOSGuide(true);
                }
              }}
              className="h-11 rounded-xl bg-emerald-500 text-black font-extrabold text-xs flex items-center justify-center gap-2"
            >
              <Smartphone className="w-4 h-4" />
              {isIOS
                ? 'Save App to iPhone Home Screen'
                : 'Save App to Home Screen'}
            </button>
          )}
          <button
            type="button"
            onClick={downloadStandaloneGithubHtml}
            className="h-11 rounded-xl bg-zinc-800 hover:bg-zinc-700 border border-white/15 text-white font-extrabold text-xs flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4 text-pink-400" />
            Download index.html for GitHub
          </button>
        </div>
      </div>

      {/* Custom Avatar Builder Modal */}
      {showAvatarCustomizer && (
        <AvatarCustomizerModal
          initialConfig={currentUser.avatarConfig}
          onSave={handleSaveCustomAvatar}
          onClose={() => setShowAvatarCustomizer(false)}
        />
      )}

      {/* iOS Add to Home Screen Guide Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-white/15 rounded-3xl p-6 max-w-sm w-full space-y-3 text-center">
            <h3 className="text-base font-extrabold text-white">
              Save Tomboy Colorverse to Phone
            </h3>
            <p className="text-xs text-zinc-300 leading-relaxed">
              1. Tap the <strong>Share</strong> icon in your browser menu.
              <br />
              2. Tap <strong>Add to Home Screen</strong> to launch Tomboy
              Colorverse anytime like a full phone app!
            </p>
            <button
              type="button"
              onClick={() => setShowIOSGuide(false)}
              className="w-full h-11 rounded-xl bg-pink-500 text-white font-extrabold text-xs"
            >
              Got It
            </button>
          </div>
        </div>
      )}

      {/* User's Own Posts Section */}
      <div className="space-y-3">
        <h3 className="text-lg font-extrabold text-white drop-shadow">
          Your Uploaded Content ({userPosts.length})
        </h3>
        {userPosts.length === 0 ? (
          <div className="bg-[#121216]/90 border border-white/10 rounded-2xl p-8 text-center text-xs text-zinc-400">
            You haven&apos;t posted yet. Head to Home and tap UPLOAD, QUOTE, or
            GIF!
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
            {userPosts.map((post) => {
              const isLiked = post.likes.includes(currentUser.id);
              const isVideoOrMusic =
                post.type === 'video' || post.type === 'music';
              return (
                <div
                  key={post.id}
                  className="bg-[#121215] rounded-2xl overflow-hidden border border-white/15 shadow-xl flex flex-col"
                >
                  <div
                    onClick={() => onSelectPost(post)}
                    className="relative aspect-[4/5] bg-black cursor-pointer group overflow-hidden flex items-center justify-center"
                  >
                    {post.mediaUrl.startsWith('data:video') ? (
                      <video
                        src={post.mediaUrl}
                        muted
                        loop
                        playsInline
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <img
                        src={post.mediaUrl}
                        alt={post.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                      />
                    )}
                    {isVideoOrMusic && (
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <div className="w-12 h-12 rounded-full bg-zinc-800/90 border border-white/25 flex items-center justify-center text-white shadow-lg">
                          <Play className="w-6 h-6 fill-current ml-0.5" />
                        </div>
                      </div>
                    )}
                  </div>
                  {/* Emoji Reactions Bar on Profile Post Card */}
                  <div className="px-2 py-1.5 bg-[#101014] border-t border-white/10 flex items-center justify-between gap-1">
                    {POST_REACTIONS.map((emoji) => {
                      const count = post.reactions?.[emoji] || 0;
                      return (
                        <button
                          key={emoji}
                          type="button"
                          onClick={() => onReactPost(post.id, emoji)}
                          className={`flex-1 h-7 rounded-lg flex items-center justify-center gap-0.5 text-xs border transition active:scale-125 ${
                            count > 0
                              ? 'bg-pink-500/20 border-pink-400/50 text-white'
                              : 'bg-zinc-900/90 border-white/5 text-zinc-300 hover:bg-zinc-800'
                          }`}
                          title={`React ${emoji}`}
                        >
                          <span className="text-xs leading-none select-none">
                            {emoji}
                          </span>
                          {count > 0 && (
                            <span className="text-[10px] font-extrabold text-amber-300 tabular-nums">
                              {count}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <div className="px-3 py-2.5 flex items-center justify-between gap-2 bg-[#141418] border-t border-white/5">
                    <span className="text-[11px] font-extrabold text-zinc-300 uppercase truncate">
                      {post.title}
                    </span>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => onToggleLike(post.id)}
                        className="text-white hover:text-pink-400 flex items-center gap-1 text-xs font-bold"
                      >
                        <Heart
                          className={`w-4 h-4 ${
                            isLiked ? 'fill-pink-500 text-pink-500' : ''
                          }`}
                        />
                        {post.likes.length > 0 && (
                          <span>{post.likes.length}</span>
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeletePost(post.id)}
                        className="text-zinc-400 hover:text-red-400"
                        title="Delete Post"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
