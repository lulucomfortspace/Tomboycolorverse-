import React, { useEffect, useRef, useState } from 'react';
import { FeedPost, UserAccount } from '../types';
import { createSynthBeatWavUrl } from '../utils/mediaEngine';
import { X, Heart, Trash2, Send, Volume2, Music, Sparkles } from 'lucide-react';

interface PostLightboxModalProps {
  post: FeedPost;
  currentUser: UserAccount;
  onClose: () => void;
  onToggleLike: (postId: string) => void;
  onReactPost: (postId: string, emoji: string) => void;
  onDeletePost: (postId: string) => void;
  onAddComment: (postId: string, text: string) => void;
}

interface FloatingReactionParticle {
  id: string;
  emoji: string;
  leftPct: number;
  driftPx: number;
  scale: number;
  delayMs: number;
}

const POST_QUICK_REACTIONS = ['❤️', '🔥', '😂', '🌈', '👑', '💯'];

export const PostLightboxModal: React.FC<PostLightboxModalProps> = ({
  post,
  currentUser,
  onClose,
  onToggleLike,
  onReactPost,
  onDeletePost,
  onAddComment,
}) => {
  const [commentText, setCommentText] = useState('');
  const [floatingReactions, setFloatingReactions] = useState<FloatingReactionParticle[]>([]);
  const [lastClickedEmoji, setLastClickedEmoji] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const isYouTube = Boolean(post.youtubeId || post.type === 'youtube');
  const isActualVideo =
    post.mediaUrl.startsWith('data:video') ||
    post.mediaUrl.endsWith('.mp4') ||
    post.mediaUrl.endsWith('.webm');

  useEffect(() => {
    if (isYouTube) {
      return;
    }

    if (isActualVideo) {
      if (videoRef.current) {
        videoRef.current.muted = false;
        videoRef.current.volume = 1.0;
        videoRef.current.play().catch(() => {});
      }
      return;
    }

    if (post.type === 'music' && post.audioUrl) {
      return;
    }

    const soundUrl =
      post.audioUrl || createSynthBeatWavUrl(post.beatFreq || 130, 6);
    const audio = new Audio(soundUrl);
    audio.loop = true;
    audio.volume = 0.9;
    audio.play().catch(() => {});
    audioRef.current = audio;

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, [post.id, isYouTube, isActualVideo, post.type, post.audioUrl]);

  const spawnFloatingBurst = (emoji: string) => {
    const now = Date.now();
    const newParticles: FloatingReactionParticle[] = Array.from({ length: 6 }).map(
      (_, idx) => ({
        id: `pfr-${now}-${idx}-${Math.random().toString(36).slice(2, 6)}`,
        emoji,
        leftPct: 16 + Math.random() * 68,
        driftPx: Math.round((Math.random() - 0.5) * 100),
        scale: Number((0.95 + Math.random() * 0.6).toFixed(2)),
        delayMs: idx * 50,
      })
    );

    setFloatingReactions((prev) => [...prev.slice(-24), ...newParticles]);
    setLastClickedEmoji(emoji);

    window.setTimeout(() => {
      const idsToRemove = new Set(newParticles.map((p) => p.id));
      setFloatingReactions((prev) => prev.filter((p) => !idsToRemove.has(p.id)));
    }, 1700);
  };

  const handleQuickReaction = (emoji: string) => {
    spawnFloatingBurst(emoji);
    onReactPost(post.id, emoji);
  };

  const isLiked = post.likes.includes(currentUser.id);
  const reactionsMap = post.reactions || {};
  const totalReactionsCount = Object.values(reactionsMap).reduce(
    (sum, val) => sum + (Number(val) || 0),
    0
  );
  const recentEvents = post.reactionEvents || [];
  const latestReactionEvent =
    recentEvents.length > 0 ? recentEvents[recentEvents.length - 1] : null;

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    onAddComment(post.id, commentText.trim());
    setCommentText('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="w-full max-w-lg bg-[#141418] border border-white/15 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[94vh]">
        {/* Header */}
        <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <img
              src={post.authorAvatar}
              alt={post.authorName}
              referrerPolicy="no-referrer"
              className="w-9 h-9 rounded-full object-cover border border-pink-400"
            />
            <div>
              <h3 className="text-sm font-extrabold text-white">
                @{post.authorName}
              </h3>
              <p className="text-[11px] text-emerald-400 flex items-center gap-1">
                <Volume2 className="w-3 h-3 animate-pulse" />
                {isYouTube ? 'YouTube Video Player' : 'Playing with Sound'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                onDeletePost(post.id);
                onClose();
              }}
              className="h-9 px-3 rounded-full bg-red-500/25 border border-red-500/50 text-red-200 text-xs font-bold flex items-center gap-1.5 hover:bg-red-500/40"
              title="Delete Post"
            >
              <Trash2 className="w-4 h-4" />
              Delete
            </button>
            <button
              type="button"
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-zinc-800 text-white flex items-center justify-center hover:bg-zinc-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Media Display */}
        <div className="relative bg-black flex-1 min-h-[260px] max-h-[48vh] flex items-center justify-center overflow-hidden">
          {isYouTube && post.youtubeId ? (
            <iframe
              src={`https://www.youtube.com/embed/${post.youtubeId}?autoplay=1&playsinline=1&rel=0`}
              title={post.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              className="w-full aspect-video min-h-[260px] border-0"
            />
          ) : isActualVideo ? (
            <video
              ref={videoRef}
              src={post.mediaUrl}
              controls
              autoPlay
              loop
              playsInline
              muted={false}
              className="w-full h-full max-h-[48vh] object-contain"
            />
          ) : (
            <img
              src={post.mediaUrl}
              alt={post.title}
              referrerPolicy="no-referrer"
              className="w-full h-full max-h-[48vh] object-contain"
            />
          )}

          {/* Floating Emoji Burst Overlay */}
          <div className="pointer-events-none absolute inset-0 z-30 overflow-hidden">
            {floatingReactions.map((item) => (
              <span
                key={item.id}
                className="story-floating-reaction text-3xl sm:text-4xl"
                style={
                  {
                    left: `${item.leftPct}%`,
                    bottom: '24px',
                    animationDelay: `${item.delayMs}ms`,
                    '--drift-x': `${item.driftPx}px`,
                    '--reaction-scale': item.scale,
                  } as React.CSSProperties
                }
              >
                {item.emoji}
              </span>
            ))}
          </div>

          {post.type === 'music' && (
            <div className="absolute bottom-3 left-3 right-3 bg-black/85 backdrop-blur-md border border-pink-500/50 rounded-2xl p-3 flex flex-col gap-2 z-20">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500 to-amber-400 flex items-center justify-center text-black shrink-0 animate-spin">
                  <Music className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-extrabold text-white truncate">
                    {post.title}
                  </p>
                  <p className="text-[11px] text-pink-300">
                    MP3 / Audio Track • Playing with Sound
                  </p>
                </div>
              </div>
              <audio
                src={post.audioUrl || createSynthBeatWavUrl(post.beatFreq || 120, 6)}
                controls
                autoPlay
                loop
                className="w-full h-9"
              />
            </div>
          )}
        </div>

        {/* Post Title, Quick Emoji Reactions, Likes, and Comments */}
        <div className="p-4 space-y-3 overflow-y-auto">
          <div className="flex items-center justify-between gap-2">
            <h4 className="font-display font-black text-base text-white tracking-wide truncate">
              {post.title}
            </h4>
            <button
              type="button"
              onClick={() => {
                if (!isLiked) {
                  spawnFloatingBurst('❤️');
                }
                onToggleLike(post.id);
              }}
              className={`h-9 px-3.5 rounded-full font-extrabold text-xs flex items-center gap-1.5 border shrink-0 transition active:scale-95 ${
                isLiked
                  ? 'bg-pink-500 text-white border-pink-400 shadow-[0_0_12px_rgba(236,72,153,0.5)]'
                  : 'bg-zinc-800 text-zinc-200 border-white/15 hover:bg-zinc-700'
              }`}
            >
              <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
              <span>{post.likes.length} Likes</span>
            </button>
          </div>

          {/* Emoji Reaction Bar & Engagement Metadata */}
          <div className="bg-zinc-900/95 border border-white/15 rounded-2xl p-2.5 space-y-2">
            <div className="flex items-center justify-between gap-2 flex-wrap px-1">
              <span className="text-[11px] font-extrabold text-amber-300 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                React with Emoji ({totalReactionsCount}{' '}
                {totalReactionsCount === 1 ? 'Reaction' : 'Reactions'})
              </span>
              {latestReactionEvent && (
                <span className="text-[11px] font-bold text-pink-300 truncate max-w-[180px]">
                  {latestReactionEvent.emoji} @{latestReactionEvent.username} reacted
                </span>
              )}
            </div>

            <div className="grid grid-cols-6 gap-1.5">
              {POST_QUICK_REACTIONS.map((emoji) => {
                const count = reactionsMap[emoji] || 0;
                const isJustClicked = lastClickedEmoji === emoji;
                return (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => handleQuickReaction(emoji)}
                    className={`h-10 rounded-xl flex items-center justify-center gap-1 border transition active:scale-125 ${
                      count > 0
                        ? 'bg-gradient-to-b from-pink-500/25 to-amber-500/15 border-pink-400/60 text-white shadow-sm'
                        : 'bg-zinc-800/80 border-white/10 text-zinc-200 hover:bg-zinc-700'
                    } ${isJustClicked ? 'ring-2 ring-amber-300' : ''}`}
                    title={`React with ${emoji}`}
                  >
                    <span className="text-base sm:text-lg leading-none select-none">
                      {emoji}
                    </span>
                    {count > 0 && (
                      <span className="text-[11px] font-extrabold text-amber-300 tabular-nums">
                        {count}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Comments List */}
          <div className="space-y-2 max-h-28 overflow-y-auto pr-1">
            {post.comments.length === 0 ? (
              <p className="text-xs text-zinc-500">
                No comments yet. Drop the first vibe below!
              </p>
            ) : (
              post.comments.map((c) => (
                <div
                  key={c.id}
                  className="bg-zinc-900/90 rounded-xl px-3 py-2 text-xs flex items-start gap-2"
                >
                  <span className="font-extrabold text-cyan-400 shrink-0">
                    {c.authorName}:
                  </span>
                  <span className="text-zinc-200">{c.text}</span>
                </div>
              ))
            )}
          </div>

          {/* Add Comment Input */}
          <form onSubmit={handleCommentSubmit} className="flex gap-2 pt-1">
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="Write a comment..."
              className="flex-1 h-10 px-3.5 rounded-xl bg-zinc-900 border border-white/15 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-pink-500"
            />
            <button
              type="submit"
              className="h-10 px-4 rounded-xl bg-gradient-to-r from-pink-500 to-amber-400 text-black font-extrabold text-xs flex items-center gap-1"
            >
              <Send className="w-3.5 h-3.5" />
              Post
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
