import React, { useEffect, useRef, useState } from 'react';
import { ChatMessage, FeedPost, StoryReel, UserAccount } from './types';
import {
  generateAIArtworkDataUrl,
  getInitialSeedData,
  getRainbowLVWallpaperSvg,
  playAutoChime,
} from './utils/mediaEngine';
import {
  flushAllToPhoneStorage,
  getInstantPhoneStorage,
  loadRawPhoneStorage,
  saveToPhoneStorage,
} from './utils/phoneStorage';
import { AuthScreen } from './components/AuthScreen';
import { StoryReelViewer } from './components/StoryReelViewer';
import { PostLightboxModal } from './components/PostLightboxModal';
import { ActiveModalType, CreatorModals } from './components/CreatorModals';
import { ProfileSettingsView } from './components/ProfileSettingsView';
import { AvatarCustomizerModal } from './components/AvatarCustomizerModal';
import {
  CloudUpload,
  Paintbrush,
  Pencil,
  Wand2,
  Music,
  Bot,
  Youtube,
  Smile,
  Sticker,
  Globe,
  MessageCircle,
  Plus,
  Heart,
  Trash2,
  Play,
  Home,
  User,
  X,
  Users,
  Sparkles,
  Volume2,
  VolumeX,
  Pause,
} from 'lucide-react';

function mergeAccountPair(prev: UserAccount | undefined, incoming: UserAccount): UserAccount {
  if (!prev) return incoming;
  const prevTime = Number(prev.updatedAt || 0);
  const nextTime = Number(incoming.updatedAt || 0);
  if ((incoming.isSeed && nextTime === 0 && prevTime > 0) || prevTime > nextTime) {
    return {
      ...incoming,
      ...prev,
      profileSongUrl: prev.profileSongUrl || incoming.profileSongUrl,
      customWallpaperUrl: prev.customWallpaperUrl || incoming.customWallpaperUrl,
    };
  }
  return {
    ...prev,
    ...incoming,
    profileSongUrl: incoming.profileSongUrl || prev.profileSongUrl,
    customWallpaperUrl: incoming.customWallpaperUrl || prev.customWallpaperUrl,
  };
}

function mergePostPair(prev: FeedPost | undefined, incoming: FeedPost): FeedPost {
  if (!prev) return incoming;
  const prevTime = Number(prev.updatedAt || 0);
  const nextTime = Number(incoming.updatedAt || 0);

  const mergedReactions: Record<string, number> = { ...(prev.reactions || {}) };
  Object.entries(incoming.reactions || {}).forEach(([emoji, count]) => {
    mergedReactions[emoji] = Math.max(
      Number(mergedReactions[emoji] || 0),
      Number(count || 0)
    );
  });

  const commentMap = new Map<string, any>();
  (Array.isArray(prev.comments) ? prev.comments : []).forEach((c) => {
    if (c && c.id) commentMap.set(c.id, c);
  });
  (Array.isArray(incoming.comments) ? incoming.comments : []).forEach((c) => {
    if (c && c.id) commentMap.set(c.id, c);
  });

  const base = nextTime >= prevTime ? { ...prev, ...incoming } : { ...incoming, ...prev };
  return {
    ...base,
    updatedAt: Math.max(prevTime, nextTime),
    mediaUrl: incoming.mediaUrl || prev.mediaUrl || '',
    audioUrl: incoming.audioUrl || prev.audioUrl,
    reactions: mergedReactions,
    comments: Array.from(commentMap.values()),
    likes:
      nextTime > prevTime
        ? incoming.likes || []
        : prevTime > nextTime
        ? prev.likes || []
        : Array.from(new Set([...(prev.likes || []), ...(incoming.likes || [])])),
  };
}

function mergeStoryPair(prev: StoryReel | undefined, incoming: StoryReel): StoryReel {
  if (!prev) return incoming;
  const prevTime = Number(prev.updatedAt || 0);
  const nextTime = Number(incoming.updatedAt || 0);

  const mergedReactions: Record<string, number> = { ...(prev.reactions || {}) };
  Object.entries(incoming.reactions || {}).forEach(([emoji, count]) => {
    mergedReactions[emoji] = Math.max(
      Number(mergedReactions[emoji] || 0),
      Number(count || 0)
    );
  });

  const base = nextTime >= prevTime ? { ...prev, ...incoming } : { ...incoming, ...prev };
  return {
    ...base,
    updatedAt: Math.max(prevTime, nextTime),
    mediaUrl: incoming.mediaUrl || prev.mediaUrl || '',
    audioUrl: incoming.audioUrl || prev.audioUrl,
    reactions: mergedReactions,
    likes:
      nextTime > prevTime
        ? incoming.likes || []
        : prevTime > nextTime
        ? prev.likes || []
        : Array.from(new Set([...(prev.likes || []), ...(incoming.likes || [])])),
  };
}

export default function App() {
  const seed = getInitialSeedData();

  const initialDeletedIds = getInstantPhoneStorage<string[]>('deletedIds', []);
  const initialAccounts = getInstantPhoneStorage<UserAccount[]>(
    'accounts',
    seed.accounts
  );
  const initialExplicitLogout = getInstantPhoneStorage<boolean>(
    'explicitlyLoggedOut',
    false
  );
  const initialSavedUserId = getInstantPhoneStorage<string | null>(
    'currentUserId',
    null
  );

  // Pick custom user account first if one exists, rather than defaulting to seed @ColorverseQueen
  const initialCustomAccounts = initialAccounts
    .filter((a) => a && (!a.isSeed || (a.updatedAt && a.updatedAt > 0)))
    .sort(
      (a, b) =>
        (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0)
    );

  const initialUser = initialExplicitLogout
    ? null
    : initialSavedUserId
    ? initialAccounts.find((a) => a.id === initialSavedUserId) ||
      initialCustomAccounts[0] ||
      initialAccounts[0] ||
      null
    : initialCustomAccounts[0] || initialAccounts[0] || null;

  const [accounts, setAccounts] = useState<UserAccount[]>(initialAccounts);
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(
    initialUser
  );
  const [showAuthScreen, setShowAuthScreen] = useState<boolean>(!initialUser);
  const [showHomeAvatarModal, setShowHomeAvatarModal] = useState(false);

  // Feed filter: 'my' (current user's own feed), 'all' (everyone's shared feed), or a specific userId
  const [feedFilter, setFeedFilter] = useState<string>(
    getInstantPhoneStorage<string>('feedFilter', 'my')
  );

  const [deletedIds, setDeletedIds] = useState<string[]>(initialDeletedIds);
  const [posts, setPosts] = useState<FeedPost[]>(() =>
    getInstantPhoneStorage<FeedPost[]>('posts', seed.posts).filter(
      (p) => p && !initialDeletedIds.includes(p.id)
    )
  );
  const [stories, setStories] = useState<StoryReel[]>(() =>
    getInstantPhoneStorage<StoryReel[]>('stories', seed.stories).filter(
      (s) => s && !initialDeletedIds.includes(s.id)
    )
  );
  const [messages, setMessages] = useState<ChatMessage[]>(() =>
    getInstantPhoneStorage<ChatMessage[]>('messages', [
      {
        id: 'm-1',
        userId: 'user-skater',
        username: 'Guest',
        avatar: seed.accounts[1].avatar,
        text: 'Welcome to Tomboy Colorverse! Upload your reels, MP3 beats & rainbow quotes 🔥🌈',
        createdAt: Date.now() - 3600000,
      },
    ])
  );

  const [activeTab, setActiveTab] = useState<'home' | 'profile'>('home');
  const [activeModal, setActiveModal] = useState<ActiveModalType>(null);
  const [viewingStoryIndex, setViewingStoryIndex] = useState<number | null>(
    null
  );
  const [selectedPost, setSelectedPost] = useState<FeedPost | null>(null);
  const [postBursts, setPostBursts] = useState<
    Record<
      string,
      Array<{
        id: string;
        emoji: string;
        leftPct: number;
        driftPx: number;
        scale: number;
        delayMs: number;
      }>
    >
  >({});
  const [storageReady, setStorageReady] = useState(false);
  const storageReadyRef = useRef(false);
  const bgSongAudioRef = useRef<HTMLAudioElement | null>(null);

  // Load saved state from Phone Storage (IndexedDB + Cache Storage + localStorage) + Workspace Server DB
  useEffect(() => {
    let mounted = true;
    async function initStorage() {
      const [
        rawDeletedIds,
        rawAccounts,
        rawUserId,
        rawExplicitLogout,
        rawFeedFilter,
        rawPosts,
        rawStories,
        rawMessages,
      ] = await Promise.all([
        loadRawPhoneStorage<string[]>('deletedIds'),
        loadRawPhoneStorage<UserAccount[]>('accounts'),
        loadRawPhoneStorage<string | null>('currentUserId'),
        loadRawPhoneStorage<boolean>('explicitlyLoggedOut'),
        loadRawPhoneStorage<string>('feedFilter'),
        loadRawPhoneStorage<FeedPost[]>('posts'),
        loadRawPhoneStorage<StoryReel[]>('stories'),
        loadRawPhoneStorage<ChatMessage[]>('messages'),
      ]);

      let serverData: any = null;
      try {
        const res = await fetch('/api/community');
        if (res.ok) {
          serverData = await res.json();
        }
      } catch {
        // Offline mode uses local phone storage layers
      }

      const allDeletedSet = new Set<string>([
        ...(Array.isArray(rawDeletedIds) ? rawDeletedIds : []),
        ...(Array.isArray(serverData?.deletedIds) ? serverData.deletedIds : []),
      ]);
      const finalDeletedIds = Array.from(allDeletedSet);

      // 1. Merge Accounts: Seed (lowest priority) -> Server DB -> Local Phone Storage
      const accMap = new Map<string, UserAccount>();
      seed.accounts.forEach((a) => {
        if (a && a.id && !allDeletedSet.has(a.id)) {
          accMap.set(a.id, a);
        }
      });
      if (Array.isArray(serverData?.accounts)) {
        serverData.accounts.forEach((a: UserAccount) => {
          if (a && a.id && !allDeletedSet.has(a.id)) {
            accMap.set(a.id, mergeAccountPair(accMap.get(a.id), a));
          }
        });
      }
      if (Array.isArray(rawAccounts)) {
        rawAccounts.forEach((a: UserAccount) => {
          if (a && a.id && !allDeletedSet.has(a.id)) {
            accMap.set(a.id, mergeAccountPair(accMap.get(a.id), a));
          }
        });
      }
      const finalAccounts = Array.from(accMap.values());

      // 2. Merge Posts: Seed -> Server DB -> Local Phone Storage
      const postMap = new Map<string, FeedPost>();
      seed.posts.forEach((p) => {
        if (p && p.id && !allDeletedSet.has(p.id)) {
          postMap.set(p.id, p);
        }
      });
      if (Array.isArray(serverData?.posts)) {
        serverData.posts.forEach((p: FeedPost) => {
          if (p && p.id && !allDeletedSet.has(p.id)) {
            postMap.set(p.id, mergePostPair(postMap.get(p.id), p));
          }
        });
      }
      if (Array.isArray(rawPosts)) {
        rawPosts.forEach((p: FeedPost) => {
          if (p && p.id && !allDeletedSet.has(p.id)) {
            postMap.set(p.id, mergePostPair(postMap.get(p.id), p));
          }
        });
      }
      // Keep authorName & authorAvatar synced with customized accounts
      const finalPosts = Array.from(postMap.values())
        .map((p) => {
          const authorAcc = accMap.get(p.authorId);
          return authorAcc
            ? {
                ...p,
                authorName: authorAcc.username,
                authorAvatar: authorAcc.avatar,
              }
            : p;
        })
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

      // 3. Merge Stories: Seed -> Server DB -> Local Phone Storage
      const storyMap = new Map<string, StoryReel>();
      seed.stories.forEach((s) => {
        if (s && s.id && !allDeletedSet.has(s.id)) {
          storyMap.set(s.id, s);
        }
      });
      if (Array.isArray(serverData?.stories)) {
        serverData.stories.forEach((s: StoryReel) => {
          if (s && s.id && !allDeletedSet.has(s.id)) {
            storyMap.set(s.id, mergeStoryPair(storyMap.get(s.id), s));
          }
        });
      }
      if (Array.isArray(rawStories)) {
        rawStories.forEach((s: StoryReel) => {
          if (s && s.id && !allDeletedSet.has(s.id)) {
            storyMap.set(s.id, mergeStoryPair(storyMap.get(s.id), s));
          }
        });
      }
      const finalStories = Array.from(storyMap.values())
        .map((s) => {
          const authorAcc = accMap.get(s.authorId);
          return authorAcc
            ? {
                ...s,
                authorName: authorAcc.username,
                authorAvatar: authorAcc.avatar,
              }
            : s;
        })
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

      // 4. Merge Messages
      const msgMap = new Map<string, ChatMessage>();
      (Array.isArray(serverData?.messages) ? serverData.messages : []).forEach(
        (m: ChatMessage) => {
          if (m && m.id) msgMap.set(m.id, m);
        }
      );
      (Array.isArray(rawMessages) ? rawMessages : messages).forEach(
        (m: ChatMessage) => {
          if (m && m.id) msgMap.set(m.id, m);
        }
      );
      const finalMessages = Array.from(msgMap.values()).sort(
        (a, b) => (a.createdAt || 0) - (b.createdAt || 0)
      );

      // 5. Resolve Active Account (Never reset to unedited seed @ColorverseQueen when a user account exists!)
      const customAccounts = finalAccounts
        .filter((a) => !a.isSeed || (a.updatedAt && a.updatedAt > 0))
        .sort(
          (a, b) =>
            (b.updatedAt || b.createdAt || 0) -
            (a.updatedAt || a.createdAt || 0)
        );

      const isExplicitlyLoggedOut =
        rawExplicitLogout === true ||
        (rawExplicitLogout === undefined &&
          rawUserId === undefined &&
          serverData?.explicitlyLoggedOut === true);

      const resolvedFeedFilter =
        rawFeedFilter || serverData?.feedFilter || 'my';

      let resolvedUser: UserAccount | null = null;
      if (!isExplicitlyLoggedOut) {
        let candidateId: string | null = null;
        if (
          typeof rawUserId === 'string' &&
          rawUserId.length > 0 &&
          (rawUserId !== 'user-guest' || customAccounts.length === 0)
        ) {
          candidateId = rawUserId;
        } else if (
          typeof serverData?.currentUserId === 'string' &&
          serverData.currentUserId.length > 0 &&
          (serverData.currentUserId !== 'user-guest' ||
            customAccounts.length === 0)
        ) {
          candidateId = serverData.currentUserId;
        } else if (customAccounts.length > 0) {
          candidateId = customAccounts[0].id;
        } else {
          candidateId = finalAccounts[0]?.id || null;
        }

        resolvedUser =
          finalAccounts.find((a) => a.id === candidateId) ||
          customAccounts[0] ||
          finalAccounts[0] ||
          null;
      }

      if (!mounted) return;
      setDeletedIds(finalDeletedIds);
      setAccounts(finalAccounts);
      setFeedFilter(resolvedFeedFilter);
      setPosts(finalPosts);
      setStories(finalStories);
      setMessages(finalMessages);
      setCurrentUser(resolvedUser);
      setShowAuthScreen(!resolvedUser);

      storageReadyRef.current = true;
      setStorageReady(true);

      // Save the merged state back into all Phone Storage layers + Server DB
      await flushAllToPhoneStorage({
        accounts: finalAccounts,
        currentUserId: resolvedUser?.id || null,
        explicitlyLoggedOut: !resolvedUser,
        feedFilter: resolvedFeedFilter,
        posts: finalPosts,
        stories: finalStories,
        messages: finalMessages,
        deletedIds: finalDeletedIds,
      });
    }
    initStorage();
    return () => {
      mounted = false;
    };
  }, []);

  // Keep a live ref of all app state so pagehide / visibilitychange / Log Out can flush synchronously
  const latestStateRef = useRef({
    accounts,
    currentUserId: currentUser?.id || null,
    explicitlyLoggedOut: !currentUser || showAuthScreen,
    feedFilter,
    posts,
    stories,
    messages,
    deletedIds,
  });

  useEffect(() => {
    latestStateRef.current = {
      accounts,
      currentUserId: currentUser?.id || null,
      explicitlyLoggedOut: !currentUser || showAuthScreen,
      feedFilter,
      posts,
      stories,
      messages,
      deletedIds,
    };
  }, [
    accounts,
    currentUser,
    showAuthScreen,
    feedFilter,
    posts,
    stories,
    messages,
    deletedIds,
  ]);

  // Save everything to Phone Storage whenever state changes
  useEffect(() => {
    if (!storageReady) return;
    flushAllToPhoneStorage({
      accounts,
      currentUserId: currentUser?.id || null,
      explicitlyLoggedOut: !currentUser || showAuthScreen,
      feedFilter,
      posts,
      stories,
      messages,
      deletedIds,
    });
  }, [
    accounts,
    currentUser,
    showAuthScreen,
    feedFilter,
    posts,
    stories,
    messages,
    deletedIds,
    storageReady,
  ]);

  // Flush everything to Phone Storage when leaving the app, switching mobile apps, or closing/refreshing tab
  useEffect(() => {
    const handleVisibilityOrUnload = () => {
      if (!storageReadyRef.current) return;
      flushAllToPhoneStorage(latestStateRef.current, true);
    };
    const handleVisibilityChange = () => {
      if (!storageReadyRef.current) return;
      if (document.visibilityState === 'hidden') {
        flushAllToPhoneStorage(latestStateRef.current, true);
      }
    };

    window.addEventListener('pagehide', handleVisibilityOrUnload);
    window.addEventListener('beforeunload', handleVisibilityOrUnload);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      window.removeEventListener('pagehide', handleVisibilityOrUnload);
      window.removeEventListener('beforeunload', handleVisibilityOrUnload);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  // Filter posts so every user has their own feed ('my' or specific userId) OR can view 'all'
  const activeFeedOwner = !currentUser
    ? null
    : feedFilter === 'my'
    ? currentUser
    : feedFilter === 'all'
    ? null
    : accounts.find((a) => a.id === feedFilter) || currentUser;

  // Resolve the active song to play on Profile or Feeds (from profileSongUrl OR latest uploaded music post)
  const songOwnerAccount =
    activeTab === 'profile'
      ? currentUser
      : activeFeedOwner || currentUser;

  const latestOwnerMusicPost = songOwnerAccount
    ? posts.find(
        (p) =>
          p &&
          p.authorId === songOwnerAccount.id &&
          p.type === 'music' &&
          Boolean(p.audioUrl)
      )
    : undefined;

  const latestAnyMusicPost = posts.find(
    (p) => p && p.type === 'music' && Boolean(p.audioUrl)
  );

  const activeSongUrl =
    songOwnerAccount?.profileSongUrl ||
    latestOwnerMusicPost?.audioUrl ||
    currentUser?.profileSongUrl ||
    latestAnyMusicPost?.audioUrl;

  const activeSongTitle =
    songOwnerAccount?.profileSongTitle ||
    latestOwnerMusicPost?.title ||
    currentUser?.profileSongTitle ||
    latestAnyMusicPost?.title ||
    'Uploaded Song';

  const isSongPlaying =
    Boolean(currentUser) &&
    !showAuthScreen &&
    Boolean(activeSongUrl) &&
    currentUser?.profileSongEnabled !== false;

  // Automatically play or pause the uploaded song on Profile & Feeds (MUST be above early return!)
  useEffect(() => {
    const audioEl = bgSongAudioRef.current;
    if (!audioEl) return;

    const modalWithOwnAudioOpen =
      viewingStoryIndex !== null || selectedPost !== null;

    if (
      !currentUser ||
      showAuthScreen ||
      !activeSongUrl ||
      !isSongPlaying ||
      modalWithOwnAudioOpen
    ) {
      audioEl.pause();
      return;
    }

    audioEl.volume = 0.85;
    audioEl.play().catch(() => {
      // If mobile browser waits for first tap, resume automatically on first interaction
    });

    const unlockOnFirstTap = () => {
      if (
        bgSongAudioRef.current &&
        currentUser &&
        !showAuthScreen &&
        activeSongUrl &&
        currentUser.profileSongEnabled !== false &&
        viewingStoryIndex === null &&
        selectedPost === null &&
        bgSongAudioRef.current.paused
      ) {
        bgSongAudioRef.current.play().catch(() => {});
      }
    };

    window.addEventListener('pointerdown', unlockOnFirstTap, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlockOnFirstTap);
    };
  }, [
    currentUser,
    showAuthScreen,
    activeSongUrl,
    isSongPlaying,
    viewingStoryIndex,
    selectedPost,
    activeTab,
    feedFilter,
  ]);

  const handleLogout = () => {
    playAutoChime(440);
    if (bgSongAudioRef.current) {
      bgSongAudioRef.current.pause();
    }
    // Explicitly save all current accounts, posts, stories, reactions, and messages to Phone Storage before logging off
    flushAllToPhoneStorage({
      accounts,
      currentUserId: null,
      explicitlyLoggedOut: true,
      feedFilter,
      posts,
      stories,
      messages,
      deletedIds,
    });
    setCurrentUser(null);
    setShowAuthScreen(true);
  };

  const handleDeleteAccount = (accountId: string) => {
    playAutoChime(330);
    const nextDeleted = deletedIds.includes(accountId)
      ? deletedIds
      : [...deletedIds, accountId];
    const nextAccounts = accounts.filter((a) => a.id !== accountId);
    setDeletedIds(nextDeleted);
    setAccounts(nextAccounts);
    flushAllToPhoneStorage({
      accounts: nextAccounts,
      currentUserId: currentUser?.id === accountId ? null : currentUser?.id || null,
      explicitlyLoggedOut: !currentUser || showAuthScreen,
      feedFilter,
      posts,
      stories,
      messages,
      deletedIds: nextDeleted,
    });
  };

  // If user is logged out or on the separate Login & Sign Up screen, render AuthScreen full-page like Facebook
  if (!currentUser || showAuthScreen) {
    return (
      <AuthScreen
        accounts={accounts}
        onLogin={(acc) => {
          const matchedAcc =
            accounts.find(
              (a) =>
                a.id === acc.id ||
                a.username.toLowerCase() === acc.username.toLowerCase()
            ) || acc;
          const freshAcc: UserAccount = {
            ...matchedAcc,
            updatedAt: Date.now(),
            isSeed: false,
          };
          const nextAccounts = accounts.some((a) => a.id === freshAcc.id)
            ? accounts.map((a) => (a.id === freshAcc.id ? freshAcc : a))
            : [freshAcc, ...accounts];
          setAccounts(nextAccounts);
          setCurrentUser(freshAcc);
          setFeedFilter('my');
          setActiveTab('home');
          setShowAuthScreen(false);
          flushAllToPhoneStorage({
            accounts: nextAccounts,
            currentUserId: freshAcc.id,
            explicitlyLoggedOut: false,
            explicitAccountSwitch: true,
            feedFilter: 'my',
            posts,
            stories,
            messages,
            deletedIds,
          });
        }}
        onCreateAccount={(newAcc) => {
          const existingAcc = accounts.find(
            (a) => a.username.toLowerCase() === newAcc.username.toLowerCase()
          );
          if (existingAcc) {
            const stampedExisting: UserAccount = {
              ...existingAcc,
              updatedAt: Date.now(),
              isSeed: false,
            };
            const nextAccounts = accounts.map((a) =>
              a.id === stampedExisting.id ? stampedExisting : a
            );
            setAccounts(nextAccounts);
            setCurrentUser(stampedExisting);
            setFeedFilter('my');
            setActiveTab('home');
            setShowAuthScreen(false);
            flushAllToPhoneStorage({
              accounts: nextAccounts,
              currentUserId: stampedExisting.id,
              explicitlyLoggedOut: false,
              explicitAccountSwitch: true,
              feedFilter: 'my',
              posts,
              stories,
              messages,
              deletedIds,
            });
            return;
          }

          const now = Date.now();
          const stampedNewAcc: UserAccount = {
            ...newAcc,
            createdAt: now,
            updatedAt: now,
            isSeed: false,
          };

          const welcomeCardUrl = generateAIArtworkDataUrl(
            `WELCOME @${stampedNewAcc.username.toUpperCase()} COLORVERSE`,
            '3:4',
            stampedNewAcc.username.length * 17
          );
          const starterPost: FeedPost = {
            id: `post-welcome-${stampedNewAcc.id}`,
            authorId: stampedNewAcc.id,
            authorName: stampedNewAcc.username,
            authorAvatar: stampedNewAcc.avatar,
            title: `${stampedNewAcc.username.toUpperCase()} VIBE`,
            quoteText: `Welcome to @${stampedNewAcc.username}'s personal Colorverse feed! 🌈🔥`,
            type: 'quote',
            mediaUrl: welcomeCardUrl,
            beatFreq: 132,
            likes: [stampedNewAcc.id],
            comments: [],
            createdAt: now,
            updatedAt: now,
            isSeed: false,
          };
          const starterStory: StoryReel = {
            id: `story-welcome-${stampedNewAcc.id}`,
            authorId: stampedNewAcc.id,
            authorName: stampedNewAcc.username,
            authorAvatar: stampedNewAcc.avatar,
            mediaType: 'image',
            mediaUrl: welcomeCardUrl,
            caption: `@${stampedNewAcc.username} joined Tomboy Colorverse! 🌈`,
            beatFreq: 132,
            likes: [stampedNewAcc.id],
            createdAt: now,
            updatedAt: now,
            isSeed: false,
          };

          const updatedAccounts = [stampedNewAcc, ...accounts];
          const updatedPosts = [starterPost, ...posts];
          const updatedStories = [starterStory, ...stories];

          setAccounts(updatedAccounts);
          setPosts(updatedPosts);
          setStories(updatedStories);
          setCurrentUser(stampedNewAcc);
          setFeedFilter('my');
          setActiveTab('home');
          setShowAuthScreen(false);

          flushAllToPhoneStorage({
            accounts: updatedAccounts,
            currentUserId: stampedNewAcc.id,
            explicitlyLoggedOut: false,
            explicitAccountSwitch: true,
            feedFilter: 'my',
            posts: updatedPosts,
            stories: updatedStories,
            messages,
            deletedIds,
          });
        }}
        onDeleteAccount={handleDeleteAccount}
      />
    );
  }

  // Determine wallpaper style from current user's profile settings
  const getWallpaperStyle = (): React.CSSProperties => {
    if (
      currentUser.wallpaperMode === 'custom' &&
      currentUser.customWallpaperUrl
    ) {
      return {
        backgroundImage: `url("${currentUser.customWallpaperUrl}")`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
      };
    }
    if (currentUser.wallpaperMode === 'midnight') {
      return {
        backgroundColor: '#09090c',
      };
    }
    const mode = currentUser.wallpaperMode === 'lv-dark' ? 'dark' : 'light';
    return {
      backgroundImage: `url("${getRainbowLVWallpaperSvg(mode)}")`,
      backgroundSize: '310px 310px',
      backgroundRepeat: 'repeat',
      backgroundAttachment: 'fixed',
    };
  };

  const handleAddPost = (newPost: FeedPost) => {
    const now = Date.now();
    const stampedPost: FeedPost = {
      ...newPost,
      createdAt: newPost.createdAt || now,
      updatedAt: now,
      isSeed: false,
    };
    const nextPosts = [stampedPost, ...posts];
    setPosts(nextPosts);

    let nextUser: UserAccount = {
      ...currentUser,
      updatedAt: now,
      isSeed: false,
    };

    // If the user uploaded a song/music post, automatically set it as their active auto-playing song on their profile & feed!
    if (stampedPost.type === 'music' && stampedPost.audioUrl) {
      nextUser = {
        ...nextUser,
        profileSongUrl: stampedPost.audioUrl,
        profileSongTitle: stampedPost.title,
        profileSongEnabled: true,
      };
    }

    const nextAccounts = accounts.map((a) =>
      a.id === nextUser.id ? nextUser : a
    );
    setCurrentUser(nextUser);
    setAccounts(nextAccounts);

    const nextFilter = feedFilter !== 'all' ? 'my' : feedFilter;
    if (feedFilter !== 'all') {
      setFeedFilter('my');
    }

    flushAllToPhoneStorage({
      accounts: nextAccounts,
      currentUserId: nextUser.id,
      explicitlyLoggedOut: false,
      feedFilter: nextFilter,
      posts: nextPosts,
      stories,
      messages,
      deletedIds,
    });
  };

  const handleAddStory = (newStory: StoryReel) => {
    const now = Date.now();
    const stampedStory: StoryReel = {
      ...newStory,
      createdAt: newStory.createdAt || now,
      updatedAt: now,
      isSeed: false,
    };
    const nextStories = [stampedStory, ...stories];
    setStories(nextStories);
    flushAllToPhoneStorage({
      accounts,
      currentUserId: currentUser.id,
      explicitlyLoggedOut: false,
      feedFilter,
      posts,
      stories: nextStories,
      messages,
      deletedIds,
    });
  };

  const spawnPostCardBurst = (postId: string, emoji: string) => {
    const now = Date.now();
    const particles = Array.from({ length: 5 }).map((_, idx) => ({
      id: `pcard-${postId}-${now}-${idx}-${Math.random().toString(36).slice(2, 6)}`,
      emoji,
      leftPct: 15 + Math.random() * 70,
      driftPx: Math.round((Math.random() - 0.5) * 80),
      scale: Number((0.9 + Math.random() * 0.5).toFixed(2)),
      delayMs: idx * 45,
    }));

    setPostBursts((prev) => ({
      ...prev,
      [postId]: [...(prev[postId] || []).slice(-15), ...particles],
    }));

    window.setTimeout(() => {
      const removeIds = new Set(particles.map((p) => p.id));
      setPostBursts((prev) => ({
        ...prev,
        [postId]: (prev[postId] || []).filter((p) => !removeIds.has(p.id)),
      }));
    }, 1650);
  };

  const handleToggleLikePost = (postId: string) => {
    playAutoChime(587.33);
    const now = Date.now();
    const nextPosts = posts.map((p) => {
      if (p.id !== postId) return p;
      const safeLikes = Array.isArray(p.likes) ? p.likes : [];
      const exists = safeLikes.includes(currentUser.id);
      if (!exists) {
        spawnPostCardBurst(postId, '❤️');
      }
      const updatedLikes = exists
        ? safeLikes.filter((id) => id !== currentUser.id)
        : [...safeLikes, currentUser.id];
      const updated: FeedPost = {
        ...p,
        likes: updatedLikes,
        updatedAt: now,
        isSeed: false,
      };
      if (selectedPost?.id === postId) {
        setSelectedPost(updated);
      }
      return updated;
    });
    setPosts(nextPosts);
    flushAllToPhoneStorage({
      accounts,
      currentUserId: currentUser.id,
      explicitlyLoggedOut: false,
      feedFilter,
      posts: nextPosts,
      stories,
      messages,
      deletedIds,
    });
  };

  const handleReactPost = (postId: string, emoji: string) => {
    spawnPostCardBurst(postId, emoji);
    const now = Date.now();
    const nextPosts = posts.map((p) => {
      if (p.id !== postId) return p;
      const safeLikes = Array.isArray(p.likes) ? p.likes : [];
      const prevReactions = p.reactions || {};
      const nextCount = (prevReactions[emoji] || 0) + 1;
      const nextEvent = {
        id: `pr-${now}-${Math.random().toString(36).slice(2, 6)}`,
        userId: currentUser.id,
        username: currentUser.username,
        emoji,
        createdAt: now,
      };
      const prevEvents = p.reactionEvents || [];
      const updatedLikes =
        emoji === '❤️' && !safeLikes.includes(currentUser.id)
          ? [...safeLikes, currentUser.id]
          : safeLikes;

      const updated: FeedPost = {
        ...p,
        likes: updatedLikes,
        reactions: {
          ...prevReactions,
          [emoji]: nextCount,
        },
        reactionEvents: [...prevEvents.slice(-29), nextEvent],
        updatedAt: now,
        isSeed: false,
      };

      if (selectedPost?.id === postId) {
        setSelectedPost(updated);
      }
      return updated;
    });
    setPosts(nextPosts);
    flushAllToPhoneStorage({
      accounts,
      currentUserId: currentUser.id,
      explicitlyLoggedOut: false,
      feedFilter,
      posts: nextPosts,
      stories,
      messages,
      deletedIds,
    });
  };

  // Delete ANY post (Guest post, seed post, or own post) permanently
  const handleDeletePost = (postId: string) => {
    playAutoChime(330);
    const nextDeleted = deletedIds.includes(postId)
      ? deletedIds
      : [...deletedIds, postId];
    const nextPosts = posts.filter((p) => p.id !== postId);
    setDeletedIds(nextDeleted);
    setPosts(nextPosts);
    if (selectedPost?.id === postId) {
      setSelectedPost(null);
    }
    flushAllToPhoneStorage({
      accounts,
      currentUserId: currentUser.id,
      explicitlyLoggedOut: false,
      feedFilter,
      posts: nextPosts,
      stories,
      messages,
      deletedIds: nextDeleted,
    });
  };

  const handleAddComment = (postId: string, text: string) => {
    playAutoChime(659.25);
    const now = Date.now();
    const comment = {
      id: `c-${now}`,
      authorId: currentUser.id,
      authorName: currentUser.username,
      authorAvatar: currentUser.avatar,
      text,
      createdAt: now,
    };
    const nextPosts = posts.map((p) => {
      if (p.id !== postId) return p;
      const safeComments = Array.isArray(p.comments) ? p.comments : [];
      const updated: FeedPost = {
        ...p,
        comments: [...safeComments, comment],
        updatedAt: now,
        isSeed: false,
      };
      if (selectedPost?.id === postId) {
        setSelectedPost(updated);
      }
      return updated;
    });
    setPosts(nextPosts);
    flushAllToPhoneStorage({
      accounts,
      currentUserId: currentUser.id,
      explicitlyLoggedOut: false,
      feedFilter,
      posts: nextPosts,
      stories,
      messages,
      deletedIds,
    });
  };

  const handleToggleLikeStory = (storyId: string) => {
    playAutoChime(587.33);
    const now = Date.now();
    const nextStories = stories.map((s) => {
      if (s.id !== storyId) return s;
      const safeLikes = Array.isArray(s.likes) ? s.likes : [];
      const exists = safeLikes.includes(currentUser.id);
      return {
        ...s,
        likes: exists
          ? safeLikes.filter((id) => id !== currentUser.id)
          : [...safeLikes, currentUser.id],
        updatedAt: now,
        isSeed: false,
      };
    });
    setStories(nextStories);
    flushAllToPhoneStorage({
      accounts,
      currentUserId: currentUser.id,
      explicitlyLoggedOut: false,
      feedFilter,
      posts,
      stories: nextStories,
      messages,
      deletedIds,
    });
  };

  const handleReactStory = (storyId: string, emoji: string) => {
    const now = Date.now();
    const nextStories = stories.map((s) => {
      if (s.id !== storyId) return s;
      const safeLikes = Array.isArray(s.likes) ? s.likes : [];
      const prevReactions = s.reactions || {};
      const nextCount = (prevReactions[emoji] || 0) + 1;
      const nextEvent = {
        id: `sr-${now}-${Math.random().toString(36).slice(2, 6)}`,
        userId: currentUser.id,
        username: currentUser.username,
        emoji,
        createdAt: now,
      };
      const prevEvents = s.reactionEvents || [];
      const updatedLikes =
        emoji === '❤️' && !safeLikes.includes(currentUser.id)
          ? [...safeLikes, currentUser.id]
          : safeLikes;

      return {
        ...s,
        likes: updatedLikes,
        reactions: {
          ...prevReactions,
          [emoji]: nextCount,
        },
        reactionEvents: [...prevEvents.slice(-29), nextEvent],
        updatedAt: now,
        isSeed: false,
      };
    });
    setStories(nextStories);
    flushAllToPhoneStorage({
      accounts,
      currentUserId: currentUser.id,
      explicitlyLoggedOut: false,
      feedFilter,
      posts,
      stories: nextStories,
      messages,
      deletedIds,
    });
  };

  // Delete ANY story (including Guest stories) permanently
  const handleDeleteStory = (storyId: string) => {
    playAutoChime(330);
    const nextDeleted = deletedIds.includes(storyId)
      ? deletedIds
      : [...deletedIds, storyId];
    const nextStories = stories.filter((s) => s.id !== storyId);
    setDeletedIds(nextDeleted);
    setStories(nextStories);
    flushAllToPhoneStorage({
      accounts,
      currentUserId: currentUser.id,
      explicitlyLoggedOut: false,
      feedFilter,
      posts,
      stories: nextStories,
      messages,
      deletedIds: nextDeleted,
    });
  };

  const handleUpdateUser = (updated: UserAccount) => {
    const now = Date.now();
    const stampedUser: UserAccount = {
      ...updated,
      updatedAt: now,
      isSeed: false,
    };
    const nextAccounts = accounts.some((a) => a.id === stampedUser.id)
      ? accounts.map((a) => (a.id === stampedUser.id ? stampedUser : a))
      : [stampedUser, ...accounts];

    const nextPosts = posts.map((p) =>
      p.authorId === stampedUser.id
        ? {
            ...p,
            authorName: stampedUser.username,
            authorAvatar: stampedUser.avatar,
            updatedAt: now,
          }
        : p
    );
    const nextStories = stories.map((s) =>
      s.authorId === stampedUser.id
        ? {
            ...s,
            authorName: stampedUser.username,
            authorAvatar: stampedUser.avatar,
            updatedAt: now,
          }
        : s
    );

    setCurrentUser(stampedUser);
    setAccounts(nextAccounts);
    setPosts(nextPosts);
    setStories(nextStories);

    flushAllToPhoneStorage({
      accounts: nextAccounts,
      currentUserId: stampedUser.id,
      explicitlyLoggedOut: false,
      explicitAccountSwitch: true,
      feedFilter,
      posts: nextPosts,
      stories: nextStories,
      messages,
      deletedIds,
    });
  };

  const isLightWallpaper = currentUser.wallpaperMode === 'lv-light';

  const displayedPosts =
    feedFilter === 'all'
      ? posts
      : posts.filter(
          (p) => p && p.authorId === (activeFeedOwner?.id || currentUser.id)
        );

  const currentUserOwnPosts = posts.filter(
    (p) => p && p.authorId === currentUser.id
  );

  // Order stories so the active user's stories appear first in the looping rainbow circle bar
  const orderedStories = [...stories]
    .filter(Boolean)
    .sort((a, b) => {
      const aIsMine = a.authorId === currentUser.id ? 1 : 0;
      const bIsMine = b.authorId === currentUser.id ? 1 : 0;
      if (aIsMine !== bIsMine) return bIsMine - aIsMine;
      return (b.createdAt || 0) - (a.createdAt || 0);
    });

  const handleToggleSongPlaying = () => {
    const nextEnabled = currentUser.profileSongEnabled === false ? true : false;
    const updatedUser: UserAccount = {
      ...currentUser,
      profileSongEnabled: nextEnabled,
    };
    handleUpdateUser(updatedUser);
    if (bgSongAudioRef.current) {
      if (nextEnabled) {
        bgSongAudioRef.current.play().catch(() => {});
      } else {
        bgSongAudioRef.current.pause();
      }
    }
  };

  const handlePlaySpecificSong = (songUrl: string, title: string) => {
    const isSameSong = activeSongUrl === songUrl;
    if (isSameSong && isSongPlaying) {
      handleToggleSongPlaying();
      return;
    }
    const updatedUser: UserAccount = {
      ...currentUser,
      profileSongUrl: songUrl,
      profileSongTitle: title,
      profileSongEnabled: true,
    };
    handleUpdateUser(updatedUser);
  };

  return (
    <div
      className="min-h-screen w-full flex flex-col justify-between transition-all duration-300"
      style={getWallpaperStyle()}
    >
      {/* Persistent Auto-Playing Song Audio Element */}
      {activeSongUrl && (
        <audio
          ref={bgSongAudioRef}
          src={activeSongUrl}
          loop
          preload="auto"
          className="hidden"
        />
      )}

      {/* Top Bar */}
      <header className="sticky top-0 z-30 h-14 bg-[#0d0d10]/95 backdrop-blur-md border-b border-white/10 px-4 flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 text-left min-w-0"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-pink-500 via-orange-400 to-amber-300 flex items-center justify-center shrink-0 shadow-md">
            <span className="font-lv font-black text-sm text-black tracking-tighter">
              LV
            </span>
          </div>
          <span className="font-lv font-black text-base sm:text-xl tracking-wider rainbow-lv-text truncate">
            TOMBOY COLORVERSE
          </span>
        </button>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveModal('upload')}
            className="h-9 px-3 rounded-full bg-gradient-to-r from-pink-500 via-amber-400 to-cyan-400 text-black font-extrabold text-xs flex items-center gap-1 shadow transition active:scale-95"
            title="Add Post or Story"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Add</span>
          </button>

          {activeSongUrl && (
            <button
              type="button"
              onClick={handleToggleSongPlaying}
              className={`h-9 px-3 rounded-full text-xs font-extrabold flex items-center gap-1.5 border transition ${
                isSongPlaying
                  ? 'bg-emerald-400 text-black border-white shadow-[0_0_10px_rgba(16,185,129,0.5)]'
                  : 'bg-zinc-900 text-zinc-300 border-white/20 hover:text-white'
              }`}
              title={isSongPlaying ? 'Turn Song OFF' : 'Turn Song ON'}
            >
              {isSongPlaying ? (
                <>
                  <Volume2 className="w-3.5 h-3.5 animate-pulse" />
                  <span>Song: ON</span>
                </>
              ) : (
                <>
                  <VolumeX className="w-3.5 h-3.5 text-red-400" />
                  <span>Song: OFF</span>
                </>
              )}
            </button>
          )}

          <button
            type="button"
            onClick={() => setActiveTab('profile')}
            className="hidden sm:flex items-center gap-1.5 h-9 pl-1.5 pr-3 rounded-full bg-zinc-900 border border-white/15 text-xs font-extrabold text-white hover:border-pink-400 transition"
          >
            <img
              src={currentUser.avatar}
              alt={currentUser.username}
              referrerPolicy="no-referrer"
              className="w-6 h-6 rounded-full object-cover"
            />
            <span className="truncate max-w-[100px]">
              @{currentUser.username}
            </span>
          </button>

          <button
            type="button"
            onClick={handleLogout}
            className="h-9 px-4 rounded-full bg-white hover:bg-zinc-100 text-black font-extrabold text-xs sm:text-sm shadow transition whitespace-nowrap shrink-0"
          >
            Log Out
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      {activeTab === 'profile' ? (
        <main className="flex-1 w-full">
          <ProfileSettingsView
            currentUser={currentUser}
            userPosts={currentUserOwnPosts}
            isSongPlaying={isSongPlaying}
            activeSongUrl={activeSongUrl}
            activeSongTitle={activeSongTitle}
            onToggleSongPlaying={handleToggleSongPlaying}
            onUpdateUser={handleUpdateUser}
            onSelectPost={(post) => {
              playAutoChime(523.25);
              setSelectedPost(post);
            }}
            onToggleLike={handleToggleLikePost}
            onReactPost={handleReactPost}
            onDeletePost={handleDeletePost}
            onLogout={handleLogout}
          />
        </main>
      ) : (
        <main className="flex-1 w-full max-w-5xl mx-auto px-3.5 sm:px-6 pt-4 pb-28 space-y-6">
          {/* CREATE & CONNECT HUB */}
          <section className="max-w-lg mx-auto bg-[#111113]/95 border border-white/15 rounded-[28px] p-4 sm:p-5 shadow-2xl">
            <h2 className="text-center font-display font-extrabold text-lg sm:text-xl text-white mb-4">
              Create &amp; Connect
            </h2>

            <div className="space-y-2.5">
              {/* Row 1: UPLOAD & DRAW */}
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setActiveModal('upload')}
                  className="h-12 rounded-full bg-gradient-to-r from-fuchsia-500 via-purple-500 to-cyan-400 border-2 border-white text-black font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(236,72,153,0.5)] active:scale-95 transition whitespace-nowrap"
                >
                  <CloudUpload className="w-4 h-4 fill-current" />
                  UPLOAD
                </button>
                <button
                  type="button"
                  onClick={() => setActiveModal('draw')}
                  className="h-12 rounded-full bg-white border-2 border-white text-black font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(255,255,255,0.4)] active:scale-95 transition whitespace-nowrap"
                >
                  <Paintbrush className="w-4 h-4 fill-current" />
                  DRAW
                </button>
              </div>

              {/* Row 2: QUOTE, AI IMG, SONIC, EMERALD */}
              <div className="grid grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModal('quote')}
                  className="h-11 rounded-full bg-[#222226] border border-white/25 text-white font-extrabold text-[11px] sm:text-xs flex items-center justify-center gap-1 shadow active:scale-95 transition whitespace-nowrap"
                >
                  <Pencil className="w-3.5 h-3.5" />
                  QUOTE
                </button>
                <button
                  type="button"
                  onClick={() => setActiveModal('ai-img')}
                  className="h-11 rounded-full bg-[#f59e0b] border-2 border-white text-black font-extrabold text-[11px] sm:text-xs flex items-center justify-center gap-1 shadow-[0_0_12px_rgba(245,158,11,0.5)] active:scale-95 transition whitespace-nowrap"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  AI IMG
                </button>
                <button
                  type="button"
                  onClick={() => setActiveModal('sonic')}
                  className="h-11 rounded-full bg-[#ec4899] border-2 border-white text-white font-extrabold text-[11px] sm:text-xs flex items-center justify-center gap-1 shadow-[0_0_12px_rgba(236,72,153,0.5)] active:scale-95 transition whitespace-nowrap"
                >
                  <Music className="w-3.5 h-3.5" />
                  SONIC
                </button>
                <button
                  type="button"
                  onClick={() => setActiveModal('emerald')}
                  className="h-11 rounded-full bg-[#10b981] border-2 border-white text-black font-extrabold text-[11px] sm:text-xs flex items-center justify-center gap-1 shadow-[0_0_12px_rgba(16,185,129,0.5)] active:scale-95 transition whitespace-nowrap"
                >
                  <Bot className="w-3.5 h-3.5" />
                  EMERALD
                </button>
              </div>

              {/* Row 3: TUBE, GIF, STICKER, WEB */}
              <div className="grid grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModal('tube')}
                  className="h-11 rounded-full bg-[#ef4444] border-2 border-white text-white font-extrabold text-[11px] sm:text-xs flex items-center justify-center gap-1 shadow-[0_0_12px_rgba(239,68,68,0.5)] active:scale-95 transition whitespace-nowrap"
                >
                  <Youtube className="w-3.5 h-3.5" />
                  TUBE
                </button>
                <button
                  type="button"
                  onClick={() => setActiveModal('gif')}
                  className="h-11 rounded-full bg-[#9333ea] border-2 border-white text-white font-extrabold text-[11px] sm:text-xs flex items-center justify-center gap-1 shadow-[0_0_12px_rgba(147,51,234,0.5)] active:scale-95 transition whitespace-nowrap"
                >
                  <Smile className="w-3.5 h-3.5" />
                  GIF
                </button>
                <button
                  type="button"
                  onClick={() => setActiveModal('sticker')}
                  className="h-11 rounded-full bg-[#06b6d4] border-2 border-white text-black font-extrabold text-[11px] sm:text-xs flex items-center justify-center gap-1 shadow-[0_0_12px_rgba(6,182,212,0.5)] active:scale-95 transition whitespace-nowrap"
                >
                  <Sticker className="w-3.5 h-3.5" />
                  STICKER
                </button>
                <button
                  type="button"
                  onClick={() => setActiveModal('web')}
                  className="h-11 rounded-full bg-white border-2 border-white text-black font-extrabold text-[11px] sm:text-xs flex items-center justify-center gap-1 shadow active:scale-95 transition whitespace-nowrap"
                >
                  <Globe className="w-3.5 h-3.5" />
                  WEB
                </button>
              </div>

              {/* Row 4: Full-Width CHAT Button */}
              <div>
                <button
                  type="button"
                  onClick={() => setActiveModal('chat')}
                  className="w-full h-11 rounded-full bg-[#3b82f6] border-2 border-white text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-[0_0_12px_rgba(59,130,246,0.5)] active:scale-95 transition whitespace-nowrap"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  CHAT
                </button>
              </div>
            </div>
          </section>

          {/* STORIES (24H) BAR WITH ANIMATED LOOPING RAINBOW CIRCLES */}
          <section className="max-w-lg mx-auto space-y-2">
            <div className="flex items-center justify-between px-1">
              <h3
                className={`text-xs font-extrabold tracking-wider ${
                  isLightWallpaper
                    ? 'text-zinc-800 bg-white/85 inline-block rounded-lg px-2.5 py-0.5 shadow-sm'
                    : 'text-zinc-200'
                }`}
              >
                STORIES (24H) • RAINBOW LOOP
              </h3>
            </div>

            <div className="flex items-center gap-4 overflow-x-auto no-scrollbar py-1.5 px-1">
              {/* + Add Story Reel Rainbow Circle */}
              <button
                type="button"
                onClick={() => setActiveModal('story-upload')}
                className="flex flex-col items-center gap-1.5 shrink-0 group"
              >
                <div className="story-rainbow-circle w-20 h-20 group-hover:scale-105 transition">
                  <div className="story-rainbow-inner flex items-center justify-center bg-[#232329] text-white">
                    <Plus className="w-8 h-8 stroke-[2.5]" />
                  </div>
                </div>
                <span
                  className={`text-xs font-extrabold ${
                    isLightWallpaper
                      ? 'text-zinc-900 bg-white/85 px-2 rounded-full shadow-sm'
                      : 'text-zinc-200'
                  }`}
                >
                  Add Story
                </span>
              </button>

              {/* Story Reel Circles with Continuous Looping Rainbow Circle Ring */}
              {orderedStories.map((story, idx) => {
                const safeStoryLikes = Array.isArray(story.likes)
                  ? story.likes
                  : [];
                const safeStoryMedia = story.mediaUrl || '';
                const reactionSum = Object.values(story.reactions || {}).reduce(
                  (acc, count) => acc + (Number(count) || 0),
                  0
                );
                const totalEngagement = reactionSum + safeStoryLikes.length;
                return (
                  <div
                    key={story.id}
                    className="relative flex flex-col items-center gap-1.5 shrink-0 group"
                  >
                    <button
                      type="button"
                      onClick={() => {
                        playAutoChime(523.25);
                        setViewingStoryIndex(idx);
                      }}
                      className="story-rainbow-circle w-20 h-20 group-hover:scale-105 transition"
                    >
                      <div className="story-rainbow-inner relative">
                        {safeStoryMedia.startsWith('data:video') ? (
                          <video
                            src={safeStoryMedia}
                            muted
                            loop
                            autoPlay
                            playsInline
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <img
                            src={safeStoryMedia}
                            alt={story.authorName}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        )}
                      </div>
                    </button>

                    {/* Story Engagement Badge */}
                    {totalEngagement > 0 && (
                      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 px-2 py-0.5 rounded-full bg-black/85 border border-pink-400/60 text-[10px] font-extrabold text-amber-300 flex items-center gap-0.5 shadow">
                        <span>🔥</span>
                        <span>{totalEngagement}</span>
                      </div>
                    )}

                    {/* 1-Tap Delete Story Button */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteStory(story.id);
                      }}
                      title="Delete Story"
                      className="absolute -top-1 -right-1 z-10 w-6 h-6 rounded-full bg-zinc-900/95 hover:bg-red-600 border border-white/30 text-white flex items-center justify-center shadow-md transition"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>

                    <span
                      className={`text-xs font-extrabold truncate max-w-[80px] ${
                        isLightWallpaper
                          ? 'text-zinc-900 bg-white/85 px-2 rounded-full shadow-sm'
                          : 'text-zinc-200'
                      }`}
                    >
                      {story.authorName}
                    </span>
                  </div>
                );
              })}
            </div>
          </section>

          {/* PERSONAL & COMMUNITY FEEDS SECTION */}
          <section className="space-y-4">
            {/* Feed Header + Switcher so Every Account Has Their Own Feed */}
            <div className="bg-[#111115]/95 border border-white/15 rounded-3xl p-4 shadow-xl space-y-3">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2.5 min-w-0">
                  {activeFeedOwner ? (
                    <div className="story-rainbow-circle w-10 h-10 shrink-0">
                      <div className="story-rainbow-inner">
                        <img
                          src={activeFeedOwner.avatar}
                          alt={activeFeedOwner.username}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-pink-500 via-amber-400 to-cyan-400 flex items-center justify-center text-black shrink-0">
                      <Users className="w-5 h-5" />
                    </div>
                  )}
                  <div className="min-w-0">
                    <h2 className="font-display font-extrabold text-lg sm:text-xl text-white truncate">
                      {feedFilter === 'all'
                        ? 'Everyone’s Community Feed'
                        : activeFeedOwner?.id === currentUser.id
                        ? `Your Feed (@${currentUser.username})`
                        : `@${activeFeedOwner?.username}'s Feed`}
                    </h2>
                    <p className="text-xs text-zinc-400 truncate">
                      {feedFilter === 'all'
                        ? 'Viewing posts from all accounts on Tomboy Colorverse'
                        : activeFeedOwner?.bio ||
                          'Personal feed saved to phone storage'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={() => setShowHomeAvatarModal(true)}
                    className="h-8 px-3 rounded-full bg-gradient-to-r from-pink-500 via-amber-400 to-cyan-400 text-black font-extrabold text-xs flex items-center gap-1 shadow"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    Customize Avatar
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('profile')}
                    className="h-8 px-3 rounded-full bg-zinc-900 border border-pink-500/40 text-pink-300 hover:text-white font-extrabold text-xs flex items-center gap-1"
                  >
                    <Music className="w-3.5 h-3.5" />
                    Profile Song
                  </button>
                </div>
              </div>

              {/* Active Feed Song Auto-Player & Turn ON/OFF Bar */}
              <div className="bg-zinc-900/95 border border-pink-500/35 rounded-2xl px-3.5 py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-8 h-8 rounded-full bg-pink-500 text-black flex items-center justify-center shrink-0 ${
                      isSongPlaying ? 'animate-spin' : ''
                    }`}
                  >
                    <Music className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[10px] font-extrabold text-pink-400 uppercase tracking-wider">
                      {isSongPlaying
                        ? `Now Auto-Playing on @${songOwnerAccount?.username || currentUser.username}'s Feed`
                        : 'Feed Song Paused'}
                    </p>
                    <p className="text-xs font-extrabold text-white truncate">
                      {activeSongTitle}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {activeSongUrl && (
                    <button
                      type="button"
                      onClick={handleToggleSongPlaying}
                      className={`h-9 px-3.5 rounded-full font-extrabold text-xs flex items-center gap-1.5 border transition shadow ${
                        isSongPlaying
                          ? 'bg-emerald-400 text-black border-white shadow-[0_0_12px_rgba(16,185,129,0.5)]'
                          : 'bg-zinc-800 text-zinc-200 border-white/20 hover:bg-zinc-700'
                      }`}
                    >
                      {isSongPlaying ? (
                        <>
                          <Volume2 className="w-3.5 h-3.5 animate-pulse" />
                          <span>Turn Song OFF</span>
                        </>
                      ) : (
                        <>
                          <VolumeX className="w-3.5 h-3.5 text-red-400" />
                          <span>Turn Song ON</span>
                        </>
                      )}
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setActiveModal('sonic')}
                    className="h-9 px-3 rounded-full bg-pink-500/20 hover:bg-pink-500/35 border border-pink-400/50 text-pink-200 font-extrabold text-xs flex items-center gap-1"
                  >
                    <Music className="w-3.5 h-3.5" />
                    Upload Song
                  </button>
                </div>
              </div>

              {/* Feed Switcher Pills: My Feed | Everyone | Each Account's Own Feed */}
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
                <button
                  type="button"
                  onClick={() => setFeedFilter('my')}
                  className={`h-9 px-3.5 rounded-full text-xs font-extrabold flex items-center gap-1.5 shrink-0 border transition ${
                    feedFilter === 'my' || feedFilter === currentUser.id
                      ? 'bg-gradient-to-r from-pink-500 via-amber-400 to-cyan-400 text-black border-white shadow-md'
                      : 'bg-zinc-900 text-zinc-300 border-white/10 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  My Feed (@{currentUser.username}) (
                  {
                    posts.filter((p) => p && p.authorId === currentUser.id)
                      .length
                  }
                  )
                </button>

                <button
                  type="button"
                  onClick={() => setFeedFilter('all')}
                  className={`h-9 px-3.5 rounded-full text-xs font-extrabold flex items-center gap-1.5 shrink-0 border transition ${
                    feedFilter === 'all'
                      ? 'bg-gradient-to-r from-fuchsia-500 via-purple-500 to-cyan-400 text-black border-white shadow-md'
                      : 'bg-zinc-900 text-zinc-300 border-white/10 hover:text-white'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  All Feeds ({posts.length})
                </button>

                {accounts
                  .filter((acc) => acc && acc.id !== currentUser.id)
                  .map((acc) => {
                    const count = posts.filter(
                      (p) => p && p.authorId === acc.id
                    ).length;
                    const isSelected = feedFilter === acc.id;
                    return (
                      <button
                        key={acc.id}
                        type="button"
                        onClick={() => setFeedFilter(acc.id)}
                        className={`h-9 pl-1.5 pr-3 rounded-full text-xs font-extrabold flex items-center gap-1.5 shrink-0 border transition ${
                          isSelected
                            ? 'bg-cyan-400 text-black border-white shadow-md'
                            : 'bg-zinc-900 text-zinc-300 border-white/10 hover:text-white'
                        }`}
                      >
                        <img
                          src={acc.avatar}
                          alt={acc.username}
                          referrerPolicy="no-referrer"
                          className="w-6 h-6 rounded-full object-cover"
                        />
                        <span>
                          @{acc.username}&apos;s Feed ({count})
                        </span>
                      </button>
                    );
                  })}
              </div>
            </div>

            {/* Empty Feed Prompt if Selected Feed Has No Posts Yet */}
            {displayedPosts.length === 0 ? (
              <div className="bg-[#121216]/95 border border-white/15 rounded-3xl p-8 text-center space-y-4 shadow-2xl">
                <p className="text-base font-extrabold text-white">
                  {activeFeedOwner?.id === currentUser.id
                    ? `Your personal feed (@${currentUser.username}) is ready for your first post!`
                    : `No posts in @${activeFeedOwner?.username}'s feed yet.`}
                </p>
                <div className="flex items-center justify-center gap-2.5 flex-wrap">
                  <button
                    type="button"
                    onClick={() => setActiveModal('upload')}
                    className="h-11 px-5 rounded-full bg-gradient-to-r from-fuchsia-500 via-purple-500 to-cyan-400 text-black font-extrabold text-xs shadow-lg"
                  >
                    + Upload Photo, Video or MP3
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveModal('quote')}
                    className="h-11 px-5 rounded-full bg-zinc-800 border border-white/20 text-white font-extrabold text-xs"
                  >
                    + Make Rainbow Quote
                  </button>
                  {feedFilter !== 'all' && (
                    <button
                      type="button"
                      onClick={() => setFeedFilter('all')}
                      className="h-11 px-5 rounded-full bg-emerald-500 text-black font-extrabold text-xs"
                    >
                      View Everyone&apos;s Feed
                    </button>
                  )}
                </div>
              </div>
            ) : (
              /* 2-Column Mobile / Multi-Column Desktop Feed Grid */
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5 items-start">
                {displayedPosts.map((post) => {
                  const safePostLikes = Array.isArray(post.likes)
                    ? post.likes
                    : [];
                  const safePostMedia = post.mediaUrl || '';
                  const isLiked = safePostLikes.includes(currentUser.id);
                  const isYouTube = Boolean(
                    post.youtubeId || post.type === 'youtube'
                  );
                  const isVideoOrMusic =
                    post.type === 'video' || post.type === 'music' || isYouTube;

                  return (
                    <article
                      key={post.id}
                      className="bg-[#121215] rounded-2xl overflow-hidden border border-white/15 shadow-2xl flex flex-col transition hover:border-white/30"
                    >
                      {/* Author Header — tap author to open that user's own feed */}
                      <div className="px-3 py-2 flex items-center justify-between gap-2 bg-[#141418]/90 border-b border-white/5">
                        <button
                          type="button"
                          onClick={() =>
                            setFeedFilter(
                              post.authorId === currentUser.id
                                ? 'my'
                                : post.authorId
                            )
                          }
                          className="flex items-center gap-2 min-w-0 text-left hover:opacity-80 transition"
                        >
                          <img
                            src={post.authorAvatar}
                            alt={post.authorName}
                            referrerPolicy="no-referrer"
                            className="w-6 h-6 rounded-full object-cover border border-pink-400 shrink-0"
                          />
                          <span className="text-xs font-bold text-zinc-200 truncate">
                            @{post.authorName}
                          </span>
                        </button>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {isYouTube && (
                            <Youtube className="w-4 h-4 text-red-500" />
                          )}
                          {post.type === 'music' && (
                            <Music className="w-3.5 h-3.5 text-pink-400" />
                          )}
                        </div>
                      </div>

                      {/* Clickable Media Area (Plays YouTube Inline or Opens Lightbox) */}
                      <div
                        onClick={() => {
                          setSelectedPost(post);
                        }}
                        className="relative aspect-[4/5] w-full bg-[#0a0a0d] cursor-pointer overflow-hidden flex items-center justify-center group"
                      >
                        {isYouTube && post.youtubeId ? (
                          <div className="w-full h-full flex flex-col bg-black">
                            <iframe
                              src={`https://www.youtube.com/embed/${post.youtubeId}?playsinline=1&rel=0`}
                              title={post.title}
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                              allowFullScreen
                              className="w-full flex-1 border-0"
                            />
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedPost(post);
                              }}
                              className="w-full py-1.5 bg-red-600/90 hover:bg-red-500 text-white text-[10px] font-extrabold uppercase tracking-wider text-center"
                            >
                              Tap for Full Screen &amp; Comments
                            </button>
                          </div>
                        ) : safePostMedia.startsWith('data:video') ? (
                          <video
                            src={safePostMedia}
                            muted
                            loop
                            playsInline
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <img
                            src={safePostMedia}
                            alt={post.title}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                          />
                        )}

                        {isVideoOrMusic && !isYouTube && (
                          <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                            <div className="w-14 h-14 rounded-full bg-zinc-800/90 border border-white/20 flex items-center justify-center text-white shadow-2xl group-hover:scale-110 transition">
                              <Play className="w-7 h-7 fill-current ml-0.5" />
                            </div>
                          </div>
                        )}

                        {/* Floating Emoji Burst Overlay on Post Card */}
                        {postBursts[post.id] && postBursts[post.id].length > 0 && (
                          <div className="pointer-events-none absolute inset-0 z-30 overflow-hidden">
                            {postBursts[post.id].map((item) => (
                              <span
                                key={item.id}
                                className="story-floating-reaction text-2xl sm:text-3xl"
                                style={
                                  {
                                    left: `${item.leftPct}%`,
                                    bottom: '16px',
                                    animationDelay: `${item.delayMs}ms`,
                                    '--drift-x': `${item.driftPx}px`,
                                    '--reaction-scale': item.scale,
                                  } as React.CSSProperties
                                }
                              >
                                {item.emoji}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Inline MP3 Player & Turn ON/OFF Bar on Music Posts */}
                      {post.type === 'music' && post.audioUrl && (
                        <div
                          onClick={(e) => e.stopPropagation()}
                          className="px-2.5 py-2 bg-zinc-900 border-t border-white/10 flex items-center justify-between gap-2"
                        >
                          <button
                            type="button"
                            onClick={() =>
                              handlePlaySpecificSong(post.audioUrl!, post.title)
                            }
                            className={`w-full h-8 px-3 rounded-xl font-extrabold text-[11px] flex items-center justify-center gap-1.5 border transition ${
                              activeSongUrl === post.audioUrl && isSongPlaying
                                ? 'bg-emerald-400 text-black border-white shadow'
                                : 'bg-pink-500/20 text-pink-200 border-pink-400/50 hover:bg-pink-500/30'
                            }`}
                          >
                            {activeSongUrl === post.audioUrl && isSongPlaying ? (
                              <>
                                <Pause className="w-3.5 h-3.5 fill-current" />
                                <span>Song Playing • Tap to Turn OFF</span>
                              </>
                            ) : (
                              <>
                                <Play className="w-3.5 h-3.5 fill-current" />
                                <span>Tap to Turn Song ON</span>
                              </>
                            )}
                          </button>
                        </div>
                      )}

                      {/* Quick Emoji Reaction Bar on Feed Post Card */}
                      <div className="px-2 py-1.5 bg-[#101014] border-t border-white/10 flex items-center justify-between gap-1">
                        {['❤️', '🔥', '😂', '🌈', '👑', '💯'].map((emoji) => {
                          const count = post.reactions?.[emoji] || 0;
                          return (
                            <button
                              key={emoji}
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleReactPost(post.id, emoji);
                              }}
                              className={`flex-1 h-7 rounded-lg flex items-center justify-center gap-0.5 text-xs border transition active:scale-125 ${
                                count > 0
                                  ? 'bg-pink-500/20 border-pink-400/50 text-white shadow-sm'
                                  : 'bg-zinc-900/90 border-white/5 text-zinc-300 hover:bg-zinc-800'
                              }`}
                              title={`React with ${emoji}`}
                            >
                              <span className="text-xs sm:text-sm leading-none select-none">
                                {emoji}
                              </span>
                              {count > 0 && (
                                <span className="text-[10px] font-extrabold text-amber-300 tabular-nums">
                                  {count}
                                </span>
                              )}
                            </button>
                          );
                        })}
                      </div>

                      {/* Card Footer: Title, Heart Like Button, and Trash Delete Button */}
                      <div className="px-3 py-2.5 bg-[#141418] border-t border-white/10 flex items-center justify-between gap-2">
                        <span
                          onClick={() => setSelectedPost(post)}
                          className="text-[11px] sm:text-xs font-extrabold text-zinc-300 uppercase tracking-wide truncate cursor-pointer"
                        >
                          {post.title}
                        </span>

                        <div className="flex items-center gap-2.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleToggleLikePost(post.id)}
                            aria-label="Like Post"
                            className="flex items-center gap-1 text-white hover:text-pink-400 transition"
                          >
                            <Heart
                              className={`w-4 h-4 ${
                                isLiked
                                  ? 'fill-pink-500 text-pink-500'
                                  : 'text-white'
                              }`}
                            />
                            {safePostLikes.length > 0 && (
                              <span className="text-[11px] font-bold text-zinc-300 tabular-nums">
                                {safePostLikes.length}
                              </span>
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeletePost(post.id)}
                            aria-label="Delete Post"
                            className="text-zinc-400 hover:text-red-400 transition"
                            title="Delete post"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </section>
        </main>
      )}

      {/* Fixed Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 h-16 bg-[#0a0a0d]/95 backdrop-blur-md border-t border-white/10 px-8 flex items-center justify-between max-w-full">
        <button
          type="button"
          onClick={() => setActiveTab('home')}
          aria-label="Home Feed"
          className={`min-w-[48px] min-h-[48px] flex items-center justify-center rounded-xl transition ${
            activeTab === 'home'
              ? 'text-white'
              : 'text-zinc-500 hover:text-zinc-300'
          }`}
        >
          <Home className="w-6 h-6" />
        </button>

        {/* Center Floating Rainbow Gradient + Button */}
        <button
          type="button"
          onClick={() => setActiveModal('upload')}
          aria-label="Create Post or Story"
          className="w-14 h-14 -mt-7 rounded-full bg-gradient-to-tr from-pink-500 via-orange-400 to-amber-300 text-black shadow-[0_4px_20px_rgba(244,114,182,0.6)] flex items-center justify-center active:scale-95 transition"
        >
          <Plus className="w-7 h-7 stroke-[2.5]" />
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('profile')}
          aria-label="Profile and Settings"
          className={`min-w-[48px] min-h-[48px] flex items-center justify-center rounded-xl transition ${
            activeTab === 'profile'
              ? 'text-pink-400'
              : 'text-zinc-500 hover:text-zinc-300'
          }`}
        >
          <User className="w-6 h-6" />
        </button>
      </nav>

      {/* Modals */}
      <CreatorModals
        activeModal={activeModal}
        currentUser={currentUser}
        messages={messages}
        onClose={() => setActiveModal(null)}
        onAddPost={handleAddPost}
        onAddStory={handleAddStory}
        onSendMessage={(text) => {
          playAutoChime(587.33);
          setMessages((prev) => [
            ...prev,
            {
              id: `m-${Date.now()}`,
              userId: currentUser.id,
              username: currentUser.username,
              avatar: currentUser.avatar,
              text,
              createdAt: Date.now(),
            },
          ]);
        }}
        onSetWallpaper={(url) => {
          handleUpdateUser({
            ...currentUser,
            wallpaperMode: 'custom',
            customWallpaperUrl: url,
          });
        }}
      />

      {/* Full-Screen Story & Video Reel Player */}
      {viewingStoryIndex !== null && orderedStories.length > 0 && (
        <StoryReelViewer
          stories={orderedStories}
          initialIndex={viewingStoryIndex}
          currentUser={currentUser}
          onClose={() => setViewingStoryIndex(null)}
          onToggleLikeStory={handleToggleLikeStory}
          onReactStory={handleReactStory}
          onDeleteStory={handleDeleteStory}
        />
      )}

      {/* Full-Screen Content Lightbox Modal */}
      {selectedPost && (
        <PostLightboxModal
          post={selectedPost}
          currentUser={currentUser}
          onClose={() => setSelectedPost(null)}
          onToggleLike={handleToggleLikePost}
          onReactPost={handleReactPost}
          onDeletePost={handleDeletePost}
          onAddComment={handleAddComment}
        />
      )}

      {/* Custom Avatar Builder Modal from Home Feed */}
      {showHomeAvatarModal && (
        <AvatarCustomizerModal
          initialConfig={currentUser.avatarConfig}
          onSave={(newAvatarUrl, newConfig) => {
            handleUpdateUser({
              ...currentUser,
              avatar: newAvatarUrl,
              avatarConfig: newConfig,
            });
            setShowHomeAvatarModal(false);
          }}
          onClose={() => setShowHomeAvatarModal(false)}
        />
      )}
    </div>
  );
}
