import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

class RootErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#09090c] text-white flex flex-col items-center justify-center p-6 text-center gap-4">
          <h1 className="text-2xl font-extrabold rainbow-lv-text">
            TOMBOY COLORVERSE
          </h1>
          <p className="text-sm text-zinc-300 max-w-sm">
            Reloading your saved feed from phone storage...
          </p>
          <button
            type="button"
            onClick={() => {
              this.setState({ hasError: false });
              window.location.reload();
            }}
            className="h-11 px-6 rounded-full bg-gradient-to-r from-pink-500 via-amber-400 to-cyan-400 text-black font-extrabold text-sm shadow-lg"
          >
            Open App Now
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(
  <RootErrorBoundary>
    <App />
  </RootErrorBoundary>
);
