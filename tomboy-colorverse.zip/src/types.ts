export type PostType =
  | 'image'
  | 'video'
  | 'youtube'
  | 'music'
  | 'quote'
  | 'drawing'
  | 'gif'
  | 'sticker';

export interface PostComment {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  text: string;
  createdAt: number;
}

export interface StoryReactionEvent {
  id: string;
  userId: string;
  username: string;
  emoji: string;
  createdAt: number;
}

export interface FeedPost {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  type: PostType;
  title: string;
  mediaUrl: string;
  youtubeId?: string;
  audioUrl?: string;
  quoteText?: string;
  quoteFont?: 'rainbow-lv' | 'neon' | 'chrome' | 'street';
  quoteBg?: string;
  likes: string[]; // array of userIds
  reactions?: Record<string, number>;
  reactionEvents?: StoryReactionEvent[];
  comments: PostComment[];
  createdAt: number;
  updatedAt?: number;
  isSeed?: boolean;
  beatFreq?: number;
}

export interface StoryReel {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  mediaType: 'image' | 'video' | 'youtube';
  mediaUrl: string;
  youtubeId?: string;
  audioUrl?: string;
  caption: string;
  likes: string[];
  reactions?: Record<string, number>;
  reactionEvents?: StoryReactionEvent[];
  createdAt: number;
  updatedAt?: number;
  isSeed?: boolean;
  beatFreq?: number;
}

export interface AvatarCustomizationConfig {
  gender: 'female' | 'male';
  skinTone: string;
  hairStyle:
    | 'snapback'
    | 'beanie'
    | 'locs'
    | 'spiky'
    | 'bucket'
    | 'afro'
    | 'waves'
    | 'long-waves'
    | 'space-buns'
    | 'ponytail';
  hairColor: string;
  hatColor: string;
  eyewear: 'none' | 'lv-shades' | 'cyber-visor' | 'star-glasses' | 'round-gold';
  outfit: 'lv-hoodie' | 'bomber' | 'street-tee' | 'track-jacket' | 'gold-chain';
  outfitColor: string;
  expression: 'smirk' | 'smile' | 'wink' | 'chill' | 'bubblegum';
  bgStyle: 'rainbow' | 'cyber-cyan' | 'sunset-pink' | 'midnight-gold' | 'emerald';
}

export interface UserAccount {
  id: string;
  username: string;
  password?: string;
  avatar: string;
  avatarConfig?: AvatarCustomizationConfig;
  bio: string;
  wallpaperMode: 'lv-light' | 'lv-dark' | 'midnight' | 'custom';
  customWallpaperUrl?: string;
  profileSongUrl?: string;
  profileSongTitle?: string;
  profileSongEnabled?: boolean;
  createdAt: number;
  updatedAt?: number;
  isSeed?: boolean;
}

export interface ChatMessage {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  text: string;
  createdAt: number;
}
