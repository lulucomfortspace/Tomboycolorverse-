// Rich AI Sticker & Custom Animated GIF generators so users can ask for or create ANYTHING
export interface GifItem {
  id: string;
  title: string;
  url: string;
}

export interface StickerDesignSpec {
  emoji?: string;
  headline?: string;
  subtext?: string;
  primaryColor?: string;
  secondaryColor?: string;
  accentColor?: string;
}

// Automatically pick matching iconography/emojis for any prompt keyword
export function inferEmojiForPrompt(prompt: string): string {
  const p = prompt.toLowerCase();
  if (p.includes('cat') || p.includes('kitty')) return '🐱✨';
  if (p.includes('dog') || p.includes('pup')) return '🐶🔥';
  if (p.includes('skate') || p.includes('board')) return '🛹⚡';
  if (p.includes('shoe') || p.includes('sneaker') || p.includes('kick')) return '👟💎';
  if (p.includes('music') || p.includes('beat') || p.includes('song') || p.includes('dj')) return '🎧🎵';
  if (p.includes('crown') || p.includes('queen') || p.includes('king') || p.includes('royal')) return '👑💎';
  if (p.includes('heart') || p.includes('love')) return '💖🌈';
  if (p.includes('car') || p.includes('van') || p.includes('ride')) return '🚐💨';
  if (p.includes('fire') || p.includes('lit') || p.includes('hot')) return '🔥💥';
  if (p.includes('star') || p.includes('glow') || p.includes('shine')) return '🌟✨';
  if (p.includes('money') || p.includes('cash') || p.includes('rich')) return '💸💎';
  if (p.includes('game') || p.includes('play')) return '🎮👾';
  if (p.includes('basketball') || p.includes('hoop') || p.includes('ball')) return '🏀🔥';
  if (p.includes('coffee') || p.includes('boba') || p.includes('drink')) return '🧋✨';
  if (p.includes('alien') || p.includes('space') || p.includes('ufo')) return '👽🛸';
  if (p.includes('dragon')) return '🐉🔥';
  if (p.includes('butterfly')) return '🦋🌈';
  if (p.includes('pizza') || p.includes('food')) return '🍕🔥';
  return '🌈👑';
}

// Generate an animated SVG GIF for any prompt or search query
export function generateAnimatedSvgGif(
  query: string,
  index: number,
  customSpec?: StickerDesignSpec | null
): GifItem {
  const cleanText = (
    customSpec?.headline ||
    query ||
    'COLORVERSE HYPE'
  )
    .toUpperCase()
    .slice(0, 24);

  const palettes = [
    ['#ff2a85', '#ff7b00', '#ffd500'],
    ['#06b6d4', '#3b82f6', '#a855f7'],
    ['#10b981', '#eab308', '#ec4899'],
    ['#f43f5e', '#8b5cf6', '#06b6d4'],
    ['#ffd500', '#ff2a85', '#10b981'],
    ['#a855f7', '#ec4899', '#38bdf8'],
  ];
  const defaultColors = palettes[index % palettes.length];
  const c1 = customSpec?.primaryColor || defaultColors[0];
  const c2 = customSpec?.secondaryColor || defaultColors[1];
  const c3 = customSpec?.accentColor || defaultColors[2];

  const emoji = customSpec?.emoji || inferEmojiForPrompt(query);
  const badges = [
    '🔥 LIVE GIF',
    '🌈 LV MOTION',
    '⚡ HYPER LOOP',
    '💎 CUSTOM AI GIF',
    '🎵 BASS PULSE',
    '👑 ICONIC VIBE',
  ];
  const subText = (customSpec?.subtext || badges[index % badges.length]).toUpperCase();

  const safeCleanText = cleanText.replace(/[<>&"']/g, '');
  const safeSubText = subText.replace(/[<>&"']/g, '');

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 420 420" width="420" height="420">
    <defs>
      <linearGradient id="bg${index}" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${c1}">
          <animate attributeName="stop-color" values="${c1};${c2};${c3};${c1}" dur="2.2s" repeatCount="indefinite"/>
        </stop>
        <stop offset="50%" stop-color="${c2}">
          <animate attributeName="stop-color" values="${c2};${c3};${c1};${c2}" dur="2.2s" repeatCount="indefinite"/>
        </stop>
        <stop offset="100%" stop-color="#09090b"/>
      </linearGradient>
    </defs>
    <rect width="420" height="420" fill="url(#bg${index})"/>

    <!-- Animated Orbiting Rings -->
    <circle cx="210" cy="210" r="150" fill="none" stroke="${c3}" stroke-width="5" stroke-dasharray="22 14" opacity="0.6">
      <animateTransform attributeName="transform" type="rotate" from="0 210 210" to="360 210 210" dur="4.5s" repeatCount="indefinite"/>
    </circle>
    <circle cx="210" cy="210" r="115" fill="none" stroke="#ffffff" stroke-width="3" stroke-dasharray="10 18" opacity="0.45">
      <animateTransform attributeName="transform" type="rotate" from="360 210 210" to="0 210 210" dur="3.5s" repeatCount="indefinite"/>
    </circle>

    <!-- Bouncing Center Emoji / Graphic -->
    <g>
      <animateTransform attributeName="transform" type="translate" values="0,-12; 0,8; 0,-12" dur="1.1s" repeatCount="indefinite"/>
      <text x="210" y="145" text-anchor="middle" font-size="68">${emoji}</text>
    </g>

    <!-- Pulsing Title Plate -->
    <g>
      <rect x="28" y="205" width="364" height="125" rx="28" fill="rgba(8,8,12,0.82)" stroke="#ffffff" stroke-width="3.5"/>
      <text x="210" y="258" text-anchor="middle" font-family="Outfit, Arial, sans-serif" font-weight="900" font-size="25" fill="#ffffff">${safeCleanText}</text>
      <text x="210" y="298" text-anchor="middle" font-family="Cinzel, Georgia, serif" font-weight="900" font-size="18" fill="${c3}">${safeSubText}</text>
    </g>
  </svg>`;

  return {
    id: `custom-gif-${Date.now()}-${index}`,
    title: safeCleanText,
    url: `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`,
  };
}

// Generate High-Res Die-Cut AI Sticker on Canvas for ANY user request
export function generateCustomAiStickerDataUrl(
  prompt: string,
  shape: 'shield' | 'circle' | 'star' | 'pill' = 'circle',
  spec?: StickerDesignSpec | null
): string {
  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 640;
  const ctx = canvas.getContext('2d')!;

  // Checkered / dark studio backdrop so die-cut white sticker border pops
  const bgGrad = ctx.createRadialGradient(320, 320, 40, 320, 320, 360);
  bgGrad.addColorStop(0, '#1e1b4b');
  bgGrad.addColorStop(1, '#09090d');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, 640, 640);

  const c1 = spec?.primaryColor || '#ff2a85';
  const c2 = spec?.secondaryColor || '#ff8800';
  const c3 = spec?.accentColor || '#06b6d4';
  const emoji = spec?.emoji || inferEmojiForPrompt(prompt);
  const headline = (spec?.headline || prompt || 'COLORVERSE').toUpperCase().slice(0, 22);
  const subtext = (spec?.subtext || 'LV EXCLUSIVE').toUpperCase().slice(0, 20);

  // Draw Thick Die-Cut White Sticker Border + Drop Shadow
  ctx.save();
  ctx.shadowColor = 'rgba(236, 72, 153, 0.55)';
  ctx.shadowBlur = 32;

  const stickerGrad = ctx.createLinearGradient(100, 100, 540, 540);
  stickerGrad.addColorStop(0, c1);
  stickerGrad.addColorStop(0.5, c2);
  stickerGrad.addColorStop(1, c3);

  ctx.fillStyle = stickerGrad;
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 22;
  ctx.lineJoin = 'round';

  ctx.beginPath();
  if (shape === 'circle') {
    ctx.arc(320, 320, 235, 0, Math.PI * 2);
  } else if (shape === 'pill') {
    ctx.roundRect(65, 130, 510, 380, 95);
  } else if (shape === 'shield') {
    ctx.moveTo(320, 75);
    ctx.lineTo(540, 155);
    ctx.quadraticCurveTo(540, 430, 320, 565);
    ctx.quadraticCurveTo(100, 430, 100, 155);
    ctx.closePath();
  } else {
    // 8-point starburst badge
    const outerR = 250;
    const innerR = 195;
    for (let i = 0; i < 16; i++) {
      const r = i % 2 === 0 ? outerR : innerR;
      const angle = (i * Math.PI) / 8;
      const x = 320 + Math.cos(angle) * r;
      const y = 320 + Math.sin(angle) * r;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
  }
  ctx.stroke();
  ctx.fill();
  ctx.restore();

  // Inner dark contrast plate
  ctx.fillStyle = 'rgba(10, 10, 14, 0.72)';
  ctx.beginPath();
  ctx.roundRect(115, 295, 410, 155, 36);
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.45)';
  ctx.lineWidth = 3;
  ctx.stroke();

  // Emoji Centerpiece
  ctx.font = '105px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(emoji, 320, 210);

  // Headline Text
  ctx.fillStyle = '#ffffff';
  ctx.font = '900 34px Outfit, sans-serif';
  ctx.fillText(headline, 320, 355);

  // Rainbow LV Subtext
  ctx.fillStyle = '#fde047';
  ctx.font = '900 22px Cinzel, Georgia, serif';
  ctx.fillText(`★ ${subtext} ★`, 320, 410);

  return canvas.toDataURL('image/png');
}

// Download a single-file standalone index.html ready to upload directly to GitHub
export function downloadStandaloneGithubHtml() {
  const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Tomboy Colorverse</title>
  <meta name="apple-mobile-web-app-capable" content="yes" />
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
  <meta name="apple-mobile-web-app-title" content="Tomboy Colorverse" />
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700;900&family=Outfit:wght@500;700;900&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Outfit', sans-serif; background: #0a0a0a; color: #fff; margin: 0; }
    .rainbow-lv {
      font-family: 'Cinzel', serif;
      background: linear-gradient(90deg, #ff2a85, #ff7b00, #ffd500, #10b981, #06b6d4, #a855f7, #ff2a85);
      background-size: 200% auto;
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      animation: shift 5s linear infinite;
    }
    @keyframes shift { to { background-position: 200% center; } }
  </style>
</head>
<body class="min-h-screen pb-24">
  <header class="sticky top-0 z-30 bg-black/90 backdrop-blur border-b border-white/10 px-4 py-3 flex items-center justify-between">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500 to-amber-400 flex items-center justify-center text-black font-black font-serif text-lg">LV</div>
      <span class="rainbow-lv font-black text-xl tracking-wider">TOMBOY COLORVERSE</span>
    </div>
    <button onclick="toggleAuth()" id="authBtn" class="bg-white text-black font-bold px-4 py-1.5 rounded-full text-sm">Log Out</button>
  </header>
  <main class="max-w-lg mx-auto p-4 space-y-6">
    <div class="bg-[#111]/95 border border-white/15 rounded-3xl p-5 shadow-2xl text-center">
      <h2 class="text-xl font-bold mb-4">Create & Connect</h2>
      <div class="grid grid-cols-2 gap-3 mb-3">
        <label class="cursor-pointer py-3 rounded-full bg-gradient-to-r from-fuchsia-500 to-cyan-400 border-2 border-white text-black font-extrabold text-sm flex items-center justify-center gap-2">
          ☁️ UPLOAD <input type="file" accept="image/*,video/*,audio/*,.mp3,.wav,.m4a" class="hidden" onchange="handleUpload(event)" />
        </label>
        <button onclick="createQuotePrompt()" class="py-3 rounded-full bg-white text-black font-extrabold text-sm">✏️ QUOTE</button>
      </div>
    </div>
    <section>
      <h3 class="text-xs font-extrabold tracking-wider text-white/70 mb-2">STORIES (24H)</h3>
      <div id="storiesRow" class="flex gap-3 overflow-x-auto pb-2"></div>
    </section>
    <section>
      <h3 class="text-xl font-extrabold mb-3">Your Feed</h3>
      <div id="feedGrid" class="grid grid-cols-2 gap-3.5"></div>
    </section>
  </main>
  <script>
    const state = JSON.parse(localStorage.getItem('tcv_github_state') || '{"posts":[],"stories":[]}');
    function save() { localStorage.setItem('tcv_github_state', JSON.stringify(state)); render(); }
    function handleUpload(e) {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        const title = prompt('Enter post title:', file.name.split('.')[0].toUpperCase()) || 'COLORVERSE POST';
        state.posts.unshift({ id: Date.now(), title, url: reader.result, type: file.type, likes: 0 });
        save();
      };
      reader.readAsDataURL(file);
    }
    function createQuotePrompt() {
      const q = prompt('Enter your Rainbow LV Quote:');
      if (!q) return;
      state.posts.unshift({ id: Date.now(), title: q.toUpperCase(), quote: q, likes: 0 });
      save();
    }
    function likePost(id) {
      const p = state.posts.find(x => x.id === id);
      if (p) { p.likes = (p.likes || 0) + 1; save(); }
    }
    function delPost(id) {
      state.posts = state.posts.filter(x => x.id !== id);
      save();
    }
    function render() {
      const grid = document.getElementById('feedGrid');
      grid.innerHTML = state.posts.map(p => \`
        <div class="bg-[#121212] rounded-2xl overflow-hidden border border-white/10 flex flex-col">
          <div class="aspect-[4/5] bg-black flex items-center justify-center p-3 overflow-hidden">
            \${p.quote ? \`<div class="rainbow-lv font-black text-xl text-center">\${p.quote}</div>\` :
              (p.type && p.type.startsWith('video') ? \`<video src="\${p.url}" controls autoplay loop class="w-full h-full object-cover"></video>\` :
              (p.type && p.type.startsWith('audio') ? \`<audio src="\${p.url}" controls autoplay class="w-full"></audio>\` :
              \`<img src="\${p.url}" class="w-full h-full object-cover"/>\`))}
          </div>
          <div class="p-3 flex items-center justify-between text-xs font-bold text-zinc-300">
            <span class="truncate">\${p.title}</span>
            <div class="flex items-center gap-2">
              <button onclick="likePost(\${p.id})">❤️ \${p.likes || 0}</button>
              <button onclick="delPost(\${p.id})">🗑️</button>
            </div>
          </div>
        </div>
      \`).join('');
    }
    render();
  </script>
</body>
</html>`;

  const blob = new Blob([htmlContent], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'index.html';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
