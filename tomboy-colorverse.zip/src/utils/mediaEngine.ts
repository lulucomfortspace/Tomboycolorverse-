import {
  AvatarCustomizationConfig,
  FeedPost,
  StoryReel,
  UserAccount,
} from '../types';
import { inferEmojiForPrompt } from './gifAndExport';

// Generate a real playable WAV audio data URL (synth beat / melody) so all videos, stories, and music tracks have real automatic sound
export function createSynthBeatWavUrl(seedFreq = 110, durationSec = 6): string {
  const sampleRate = 22050;
  const numSamples = sampleRate * durationSec;
  const buffer = new ArrayBuffer(44 + numSamples * 2);
  const view = new DataView(buffer);

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + numSamples * 2, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, 1, true); // Mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, numSamples * 2, true);

  const notes = [1, 1.25, 1.5, 1.875, 2, 1.5, 1.25, 1.125];
  const bpm = 124;
  const beatLen = 60 / bpm;

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    const beatIndex = Math.floor(t / (beatLen / 2));
    const beatTime = t % (beatLen / 2);
    const noteMult = notes[beatIndex % notes.length];
    const freq = seedFreq * noteMult;

    // Kick drum on every beat
    const kickTime = t % beatLen;
    const kickEnv = Math.exp(-kickTime * 18);
    const kickFreq = 130 * Math.exp(-kickTime * 35) + 45;
    const kick = Math.sin(2 * Math.PI * kickFreq * kickTime) * kickEnv * 0.55;

    // Hi-hat on off-beats
    const hatTime = (t + beatLen / 2) % beatLen;
    const hatEnv = Math.exp(-hatTime * 45);
    const hat = (Math.random() * 2 - 1) * hatEnv * 0.15;

    // Synth lead + bass
    const synthEnv = Math.exp(-beatTime * 6);
    const synth =
      (Math.sin(2 * Math.PI * freq * t) * 0.3 +
        Math.sin(2 * Math.PI * freq * 2 * t) * 0.15) *
      synthEnv;

    const sample = Math.max(-1, Math.min(1, kick + hat + synth));
    view.setInt16(44 + i * 2, sample * 32767, true);
  }

  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return `data:audio/wav;base64,${btoa(binary)}`;
}

// Click chime disabled so clicking buttons doesn't play artificial beep sounds
export function playAutoChime(_freq = 440) {
  // Intentionally silent per user preference — users have real profile songs & music tracks instead
}

// Create the Rainbow LV Monogram SVG pattern Data URL (matching Reference Image 1!)
export function getRainbowLVWallpaperSvg(mode: 'light' | 'dark'): string {
  const bg = mode === 'light' ? '#ffffff' : '#09090d';
  const lvColor = mode === 'light' ? '#1c1917' : '#ffffff';
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="320" height="320" viewBox="0 0 320 320">
    <rect width="320" height="320" fill="${bg}"/>
    <!-- LV Monogram Center -->
    <g transform="translate(115, 130)">
      <text x="0" y="45" font-family="Georgia, serif" font-weight="900" font-style="italic" font-size="68" fill="${lvColor}" opacity="${mode === 'light' ? '0.88' : '0.22'}">V</text>
      <text x="12" y="55" font-family="Georgia, serif" font-weight="900" font-size="62" fill="${lvColor}" opacity="${mode === 'light' ? '0.88' : '0.22'}">L</text>
    </g>
    <!-- Gold Four-Point Star Diamond -->
    <g transform="translate(245, 155) scale(0.95)">
      <path d="M0,-42 Q8,-8 42,0 Q8,8 0,42 Q-8,8 -42,0 Q-8,-8 0,-42 Z" fill="none" stroke="#eab308" stroke-width="6"/>
      <circle cx="0" cy="0" r="8" fill="#eab308"/>
    </g>
    <!-- Blue Four-Petal Star -->
    <g transform="translate(30, 150) scale(0.85)">
      <path d="M0,-38 Q10,-10 38,0 Q10,10 0,38 Q-10,10 -38,0 Q-10,-10 0,-38 Z" fill="none" stroke="#0284c7" stroke-width="6"/>
      <path d="M0,-14 Q4,-4 14,0 Q4,4 0,14 Q-4,4 -14,0 Q-4,-4 0,-14 Z" fill="#0284c7"/>
    </g>
    <!-- Crimson Red Four-Petal Flower -->
    <g transform="translate(75, 225) scale(0.75)">
      <path d="M0,-36 C12,-12 12,-12 36,0 C12,12 12,12 0,36 C-12,12 -12,12 -36,0 C-12,-12 -12,-12 0,-36 Z" fill="#991b1b"/>
      <circle cx="0" cy="0" r="6" fill="${bg}"/>
    </g>
    <!-- Purple Circle Flower -->
    <g transform="translate(240, 265) scale(0.78)">
      <circle cx="0" cy="0" r="34" fill="#7e22ce"/>
      <ellipse cx="0" cy="-16" rx="8" ry="12" fill="${bg}"/>
      <ellipse cx="0" cy="16" rx="8" ry="12" fill="${bg}"/>
      <ellipse cx="-16" cy="0" rx="12" ry="8" fill="${bg}"/>
      <ellipse cx="16" cy="0" rx="12" ry="8" fill="${bg}"/>
      <circle cx="0" cy="0" r="5" fill="#7e22ce"/>
    </g>
    <!-- Lime Green Flower -->
    <g transform="translate(300, 225) scale(0.8)">
      <path d="M0,-34 C10,-10 10,-10 34,0 C10,10 10,10 0,34 C-10,10 -10,10 -34,0 C-10,-10 -10,-10 0,-34 Z" fill="#bef264"/>
      <circle cx="0" cy="0" r="6" fill="${bg}"/>
    </g>
    <!-- Soft Pink Top Left Flower -->
    <g transform="translate(45, 45) scale(0.8)">
      <path d="M0,-36 Q9,-9 36,0 Q9,9 0,36 Q-9,9 -36,0 Q-9,-9 0,-36 Z" fill="none" stroke="#f9a8d4" stroke-width="6"/>
      <circle cx="0" cy="0" r="7" fill="#f9a8d4"/>
    </g>
    <!-- Lavender Star -->
    <g transform="translate(175, 235) scale(0.75)">
      <path d="M0,-34 C10,-10 10,-10 34,0 C10,10 10,10 0,34 C-10,10 -10,10 -34,0 C-10,-10 -10,-10 0,-34 Z" fill="#c4b5fd"/>
      <circle cx="0" cy="0" r="5" fill="${bg}"/>
    </g>
    <!-- Navy Top Monogram Accent -->
    <g transform="translate(230, 50) scale(0.8)">
      <path d="M0,-36 Q9,-9 36,0 Q9,9 0,36 Q-9,9 -36,0 Q-9,-9 0,-36 Z" fill="none" stroke="#312e81" stroke-width="6"/>
      <circle cx="0" cy="0" r="7" fill="#312e81"/>
    </g>
    <!-- Yellow Circle Flower Bottom Left -->
    <g transform="translate(25, 270) scale(0.7)">
      <circle cx="0" cy="0" r="32" fill="#fde047"/>
      <ellipse cx="0" cy="-15" rx="7" ry="11" fill="${bg}"/>
      <ellipse cx="0" cy="15" rx="7" ry="11" fill="${bg}"/>
      <ellipse cx="-15" cy="0" rx="11" ry="7" fill="${bg}"/>
      <ellipse cx="15" cy="0" rx="11" ry="7" fill="${bg}"/>
    </g>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

// Generate initial rich visual cards matching Reference Image 1 & 2
export function generatePowerpuffVanCardUrl(): string {
  const canvas = document.createElement('canvas');
  canvas.width = 600;
  canvas.height = 750;
  const ctx = canvas.getContext('2d')!;

  // Sunset sky gradient
  const sky = ctx.createLinearGradient(0, 0, 0, 750);
  sky.addColorStop(0, '#38bdf8');
  sky.addColorStop(0.35, '#f472b6');
  sky.addColorStop(0.65, '#fb923c');
  sky.addColorStop(1, '#1e1b4b');
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, 600, 750);

  // Rainbow arch across sky
  const rainbowColors = ['#ff2a85', '#ff7b00', '#ffd500', '#10b981', '#06b6d4', '#8b5cf6'];
  rainbowColors.forEach((col, i) => {
    ctx.beginPath();
    ctx.arc(300, 340, 270 - i * 12, Math.PI, 0, false);
    ctx.strokeStyle = col;
    ctx.lineWidth = 11;
    ctx.globalAlpha = 0.75;
    ctx.stroke();
  });
  ctx.globalAlpha = 1;

  // City skyline silhouette
  ctx.fillStyle = 'rgba(30, 27, 75, 0.55)';
  const buildings = [
    [30, 280, 55, 260],
    [95, 220, 65, 320],
    [175, 260, 50, 280],
    [380, 230, 60, 310],
    [450, 190, 70, 350],
    [530, 250, 50, 290],
  ];
  buildings.forEach(([x, y, w, h]) => ctx.fillRect(x, y, w, h));

  // Road
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(0, 540, 600, 210);

  // Graffiti Pink Camper Van
  ctx.save();
  ctx.fillStyle = '#ec4899';
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.roundRect(90, 360, 420, 230, 28);
  ctx.fill();
  ctx.stroke();

  // Van cyan & yellow graffiti stripes
  ctx.fillStyle = '#06b6d4';
  ctx.beginPath();
  ctx.roundRect(94, 470, 412, 55, 8);
  ctx.fill();

  ctx.fillStyle = '#fde047';
  ctx.font = '900 32px Outfit, sans-serif';
  ctx.fillText('COLORVERSE CREW', 130, 508);

  // Van windshield & headlights
  ctx.fillStyle = '#1e293b';
  ctx.beginPath();
  ctx.roundRect(350, 385, 135, 70, 14);
  ctx.fill();

  // Headlights
  ctx.fillStyle = '#fef08a';
  ctx.beginPath();
  ctx.arc(380, 550, 18, 0, Math.PI * 2);
  ctx.arc(475, 550, 18, 0, Math.PI * 2);
  ctx.fill();

  // Wheels
  ctx.fillStyle = '#09090b';
  ctx.beginPath();
  ctx.arc(185, 595, 42, 0, Math.PI * 2);
  ctx.arc(415, 595, 42, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#e2e8f0';
  ctx.beginPath();
  ctx.arc(185, 595, 20, 0, Math.PI * 2);
  ctx.arc(415, 595, 20, 0, Math.PI * 2);
  ctx.fill();

  // 3 Stylized Tomboy Characters on Van Roof
  const chars = [
    { x: 200, color: '#38bdf8', hat: '#0284c7' },
    { x: 300, color: '#f43f5e', hat: '#e11d48' },
    { x: 400, color: '#22c55e', hat: '#15803d' },
  ];
  chars.forEach((c) => {
    ctx.fillStyle = c.color;
    ctx.beginPath();
    ctx.roundRect(c.x - 32, 275, 64, 85, 16);
    ctx.fill();
    ctx.fillStyle = '#fed7aa';
    ctx.beginPath();
    ctx.arc(c.x, 235, 38, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(c.x - 14, 235, 14, 0, Math.PI * 2);
    ctx.arc(c.x + 14, 235, 14, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#09090b';
    ctx.beginPath();
    ctx.arc(c.x - 12, 235, 8, 0, Math.PI * 2);
    ctx.arc(c.x + 12, 235, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = c.hat;
    ctx.beginPath();
    ctx.roundRect(c.x - 42, 192, 84, 24, 10);
    ctx.fill();
  });
  ctx.restore();

  return canvas.toDataURL('image/jpeg', 0.9);
}

// Generate the exact "N <3 M" neon drawing from Reference Image 2
export function generateNeonHeartDrawingUrl(): string {
  const canvas = document.createElement('canvas');
  canvas.width = 600;
  canvas.height = 600;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#0d0d10';
  ctx.fillRect(0, 0, 600, 600);

  ctx.strokeStyle = '#ec4899';
  ctx.shadowColor = '#ec4899';
  ctx.shadowBlur = 16;
  ctx.lineWidth = 8;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  // Draw 'N'
  ctx.beginPath();
  ctx.moveTo(95, 380);
  ctx.lineTo(105, 220);
  ctx.lineTo(175, 375);
  ctx.lineTo(195, 210);
  ctx.stroke();

  // Draw Heart
  ctx.beginPath();
  ctx.moveTo(295, 265);
  ctx.bezierCurveTo(295, 230, 240, 225, 245, 275);
  ctx.bezierCurveTo(250, 315, 295, 340, 295, 360);
  ctx.bezierCurveTo(295, 340, 340, 315, 345, 275);
  ctx.bezierCurveTo(350, 225, 295, 230, 295, 265);
  ctx.stroke();

  // Draw 'M'
  ctx.beginPath();
  ctx.moveTo(395, 375);
  ctx.lineTo(415, 230);
  ctx.lineTo(455, 325);
  ctx.lineTo(505, 225);
  ctx.lineTo(515, 380);
  ctx.stroke();

  return canvas.toDataURL('image/png');
}

// Generate AI Wallpaper or AI Art on Canvas from any prompt with rich scene illustration
export function generateAIArtworkDataUrl(
  prompt: string,
  aspect: '9:16' | '1:1' | '3:4' = '9:16',
  seedSalt = 0
): string {
  const canvas = document.createElement('canvas');
  canvas.width = 720;
  canvas.height = aspect === '9:16' ? 1280 : aspect === '3:4' ? 960 : 720;
  const ctx = canvas.getContext('2d')!;

  let hash = seedSalt;
  for (let i = 0; i < prompt.length; i++) {
    hash = (hash * 37 + prompt.charCodeAt(i)) % 360;
  }

  const h1 = hash;
  const h2 = (hash + 95) % 360;
  const h3 = (hash + 210) % 360;

  // Deep atmospheric sky gradient
  const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  grad.addColorStop(0, `hsl(${h1}, 85%, 14%)`);
  grad.addColorStop(0.45, `hsl(${h2}, 90%, 28%)`);
  grad.addColorStop(0.75, `hsl(${h3}, 92%, 42%)`);
  grad.addColorStop(1, '#09090f');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Starfield & sparkles
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < 45; i++) {
    const sx = ((hash * (i + 7) * 97) % canvas.width);
    const sy = ((hash * (i + 3) * 53) % (canvas.height * 0.6));
    const sr = (i % 3) + 1;
    ctx.globalAlpha = 0.35 + (i % 5) * 0.12;
    ctx.beginPath();
    ctx.arc(sx, sy, sr, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  // Giant Glowing Retro-Futuristic Sun / Moon
  const sunY = canvas.height * 0.42;
  const sunGrad = ctx.createLinearGradient(0, sunY - 160, 0, sunY + 160);
  sunGrad.addColorStop(0, '#fde047');
  sunGrad.addColorStop(0.5, '#ff2a85');
  sunGrad.addColorStop(1, '#7e22ce');
  ctx.save();
  ctx.shadowColor = '#ff2a85';
  ctx.shadowBlur = 45;
  ctx.fillStyle = sunGrad;
  ctx.beginPath();
  ctx.arc(canvas.width / 2, sunY, 155, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Rainbow Arch Halo
  const rainbowCols = ['#ff2a85', '#ff7b00', '#ffd500', '#10b981', '#06b6d4', '#a855f7'];
  rainbowCols.forEach((col, idx) => {
    ctx.beginPath();
    ctx.arc(canvas.width / 2, sunY + 40, 290 - idx * 10, Math.PI, 0, false);
    ctx.strokeStyle = col;
    ctx.lineWidth = 8;
    ctx.globalAlpha = 0.65;
    ctx.stroke();
  });
  ctx.globalAlpha = 1;

  // City Skyline Silhouette at Horizon
  const horizonY = canvas.height * 0.58;
  ctx.fillStyle = '#090912';
  for (let x = 0; x < canvas.width; x += 48) {
    const bh = 60 + ((x * 29 + hash * 13) % 150);
    ctx.fillRect(x, horizonY - bh, 42, bh + 20);
  }

  // Neon Synthwave Perspective Grid Floor
  ctx.fillStyle = '#07070c';
  ctx.fillRect(0, horizonY, canvas.width, canvas.height - horizonY);

  ctx.strokeStyle = `hsla(${h2}, 95%, 62%, 0.55)`;
  ctx.lineWidth = 2;
  for (let i = -8; i <= 8; i++) {
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2 + i * 25, horizonY);
    ctx.lineTo(canvas.width / 2 + i * 140, canvas.height);
    ctx.stroke();
  }
  for (let y = horizonY + 18; y < canvas.height; y += (y - horizonY) * 0.35 + 12) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }

  // Floating Rainbow LV Monograms & Stars
  for (let i = 0; i < 6; i++) {
    const cx = 90 + (i % 3) * 260;
    const cy = 130 + Math.floor(i / 3) * 210;
    const col = rainbowCols[(i + hash) % rainbowCols.length];
    ctx.save();
    ctx.translate(cx, cy);
    ctx.strokeStyle = col;
    ctx.fillStyle = col;
    ctx.shadowColor = col;
    ctx.shadowBlur = 16;
    ctx.lineWidth = 4;
    if (i % 2 === 0) {
      ctx.beginPath();
      ctx.moveTo(0, -26);
      ctx.quadraticCurveTo(6, -6, 26, 0);
      ctx.quadraticCurveTo(6, 6, 0, 26);
      ctx.quadraticCurveTo(-6, 6, -26, 0);
      ctx.quadraticCurveTo(-6, -6, 0, -26);
      ctx.stroke();
    } else {
      ctx.font = '900 32px Cinzel, Georgia, serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('LV', 0, 0);
    }
    ctx.restore();
  }

  // Central Subject Emblem matching user's prompt
  const emoji = inferEmojiForPrompt(prompt);
  ctx.save();
  ctx.shadowColor = '#06b6d4';
  ctx.shadowBlur = 30;
  ctx.font = '135px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(emoji, canvas.width / 2, sunY - 10);
  ctx.restore();

  // Stylized Prompt Artwork Title Plate at Bottom
  const cleanTitle = (prompt || 'COLORVERSE AI ART')
    .replace(/• \d+$/, '')
    .trim()
    .toUpperCase()
    .slice(0, 28);

  ctx.save();
  ctx.fillStyle = 'rgba(10, 10, 16, 0.82)';
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.roundRect(50, canvas.height - 175, canvas.width - 100, 115, 28);
  ctx.fill();
  ctx.stroke();

  const textGrad = ctx.createLinearGradient(80, 0, canvas.width - 80, 0);
  textGrad.addColorStop(0, '#ff2a85');
  textGrad.addColorStop(0.5, '#ffd500');
  textGrad.addColorStop(1, '#06b6d4');
  ctx.fillStyle = textGrad;
  ctx.font = '900 30px Outfit, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(cleanTitle, canvas.width / 2, canvas.height - 125);

  ctx.fillStyle = '#e2e8f0';
  ctx.font = '700 17px Cinzel, serif';
  ctx.fillText('★ TOMBOY COLORVERSE AI STUDIO ★', canvas.width / 2, canvas.height - 86);
  ctx.restore();

  return canvas.toDataURL('image/jpeg', 0.92);
}

// Async helper that calls server AI image generator to produce real AI art & stickers
export async function generateCustomAiArtAsync(
  prompt: string,
  aspect: '9:16' | '3:4' | '1:1' = '3:4',
  mode: 'art' | 'sticker' = 'art'
): Promise<string> {
  try {
    const res = await fetch('/api/ai/generate-image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, aspect, mode }),
    });
    if (res.ok) {
      const data = await res.json();
      if (data?.imageUrl && typeof data.imageUrl === 'string') {
        return data.imageUrl;
      }
    }
  } catch {
    // Fallback to procedural canvas artwork if offline
  }
  return generateAIArtworkDataUrl(prompt, aspect, Math.floor(Math.random() * 360));
}

// Render Quote Card with Rainbow LV Font or custom background
export function renderQuoteImage(
  quoteText: string,
  fontStyle: 'rainbow-lv' | 'neon' | 'chrome' | 'street',
  bgOption: string,
  customBgDataUrl?: string
): Promise<string> {
  return new Promise((resolve) => {
    const canvas = document.createElement('canvas');
    canvas.width = 720;
    canvas.height = 720;
    const ctx = canvas.getContext('2d')!;

    const drawTextLayer = () => {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.42)';
      ctx.fillRect(0, 0, 720, 720);

      ctx.fillStyle = 'rgba(255,255,255,0.14)';
      ctx.beginPath();
      ctx.roundRect(28, 28, 64, 64, 16);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = '900 26px Cinzel, serif';
      ctx.textAlign = 'center';
      ctx.fillText('LV', 60, 69);

      const words = quoteText.toUpperCase().split(/\s+/);
      const lines: string[] = [];
      let current = '';
      for (const w of words) {
        const test = current ? `${current} ${w}` : w;
        if (test.length > 18 && current) {
          lines.push(current);
          current = w;
        } else {
          current = test;
        }
      }
      if (current) lines.push(current);

      const fontSize = lines.length > 4 ? 42 : 52;
      ctx.font =
        fontStyle === 'rainbow-lv'
          ? `900 ${fontSize}px Cinzel, Georgia, serif`
          : `900 ${fontSize}px Outfit, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      const grad = ctx.createLinearGradient(80, 200, 640, 520);
      if (fontStyle === 'rainbow-lv') {
        grad.addColorStop(0, '#ff2a85');
        grad.addColorStop(0.22, '#ff8800');
        grad.addColorStop(0.45, '#ffea00');
        grad.addColorStop(0.68, '#10b981');
        grad.addColorStop(0.85, '#06b6d4');
        grad.addColorStop(1, '#c084fc');
        ctx.fillStyle = grad;
        ctx.shadowColor = 'rgba(255, 42, 133, 0.6)';
        ctx.shadowBlur = 18;
      } else if (fontStyle === 'neon') {
        ctx.fillStyle = '#00f5d4';
        ctx.shadowColor = '#00f5d4';
        ctx.shadowBlur = 24;
      } else if (fontStyle === 'chrome') {
        grad.addColorStop(0, '#ffffff');
        grad.addColorStop(0.5, '#cbd5e1');
        grad.addColorStop(1, '#f8fafc');
        ctx.fillStyle = grad;
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 12;
      } else {
        ctx.fillStyle = '#fde047';
        ctx.shadowColor = '#f97316';
        ctx.shadowBlur = 16;
      }

      const lineHeight = fontSize * 1.32;
      const startY = 360 - ((lines.length - 1) * lineHeight) / 2;

      lines.forEach((line, idx) => {
        ctx.fillText(line, 360, startY + idx * lineHeight);
      });

      ctx.shadowBlur = 0;
      ctx.fillStyle = 'rgba(255,255,255,0.75)';
      ctx.font = '700 18px Outfit, sans-serif';
      ctx.fillText('TOMBOY COLORVERSE', 360, 675);

      resolve(canvas.toDataURL('image/jpeg', 0.92));
    };

    if (customBgDataUrl) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        ctx.drawImage(img, 0, 0, 720, 720);
        drawTextLayer();
      };
      img.onerror = () => {
        ctx.fillStyle = '#111111';
        ctx.fillRect(0, 0, 720, 720);
        drawTextLayer();
      };
      img.src = customBgDataUrl;
      return;
    }

    if (bgOption === 'lv-rainbow') {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, 720, 720);
        drawTextLayer();
      };
      img.src = getRainbowLVWallpaperSvg('dark');
      return;
    }

    const bgGrad = ctx.createLinearGradient(0, 0, 720, 720);
    if (bgOption === 'cyber-pink') {
      bgGrad.addColorStop(0, '#831843');
      bgGrad.addColorStop(0.5, '#311042');
      bgGrad.addColorStop(1, '#0f172a');
    } else if (bgOption === 'sunset-gold') {
      bgGrad.addColorStop(0, '#7c2d12');
      bgGrad.addColorStop(0.5, '#be185d');
      bgGrad.addColorStop(1, '#1e1b4b');
    } else if (bgOption === 'emerald-matrix') {
      bgGrad.addColorStop(0, '#064e3b');
      bgGrad.addColorStop(0.5, '#0f172a');
      bgGrad.addColorStop(1, '#022c22');
    } else if (bgOption.startsWith('#')) {
      bgGrad.addColorStop(0, bgOption);
      bgGrad.addColorStop(1, '#09090b');
    } else {
      bgGrad.addColorStop(0, '#09090b');
      bgGrad.addColorStop(1, '#18181b');
    }
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, 720, 720);
    drawTextLayer();
  });
}

// Extract 11-character YouTube Video ID from any YouTube URL (watch, youtu.be, shorts, embed) or raw ID
export function extractYouTubeId(input: string): string | null {
  const trimmed = (input || '').trim();
  if (!trimmed) return null;
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/|youtube\.com\/live\/)([a-zA-Z0-9_-]{11})/,
    /[?&]v=([a-zA-Z0-9_-]{11})/,
  ];
  for (const regex of patterns) {
    const match = trimmed.match(regex);
    if (match && match[1]) {
      return match[1];
    }
  }
  return null;
}

// Default Custom Avatar Configuration
export const DEFAULT_AVATAR_CONFIG: AvatarCustomizationConfig = {
  gender: 'female',
  skinTone: '#e0a96d',
  hairStyle: 'snapback',
  hairColor: '#18181b',
  hatColor: '#ec4899',
  eyewear: 'lv-shades',
  outfit: 'lv-hoodie',
  outfitColor: '#9333ea',
  expression: 'smirk',
  bgStyle: 'rainbow',
};

// Render a rich stylized Tomboy Colorverse Female or Male character avatar SVG from customization options
export function renderCustomAvatarSvg(
  config: AvatarCustomizationConfig = DEFAULT_AVATAR_CONFIG
): string {
  const isFemale = (config.gender || 'female') === 'female';
  let bgDefs = '';
  let bgRect = '';

  if (config.bgStyle === 'rainbow') {
    bgDefs = `<linearGradient id="avBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ff007f"/>
      <stop offset="25%" stop-color="#ff7b00"/>
      <stop offset="50%" stop-color="#ffe600"/>
      <stop offset="75%" stop-color="#00d4ff"/>
      <stop offset="100%" stop-color="#8b5cf6"/>
    </linearGradient>`;
    bgRect = `<rect width="240" height="240" rx="120" fill="url(#avBg)"/>`;
  } else if (config.bgStyle === 'cyber-cyan') {
    bgDefs = `<linearGradient id="avBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#06b6d4"/>
      <stop offset="100%" stop-color="#1e1b4b"/>
    </linearGradient>`;
    bgRect = `<rect width="240" height="240" rx="120" fill="url(#avBg)"/>`;
  } else if (config.bgStyle === 'sunset-pink') {
    bgDefs = `<linearGradient id="avBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#f43f5e"/>
      <stop offset="50%" stop-color="#fb923c"/>
      <stop offset="100%" stop-color="#581c87"/>
    </linearGradient>`;
    bgRect = `<rect width="240" height="240" rx="120" fill="url(#avBg)"/>`;
  } else if (config.bgStyle === 'midnight-gold') {
    bgDefs = `<linearGradient id="avBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#09090b"/>
      <stop offset="100%" stop-color="#422006"/>
    </linearGradient>`;
    bgRect = `<rect width="240" height="240" rx="120" fill="url(#avBg)"/>
      <circle cx="48" cy="52" r="3" fill="#fde047"/>
      <circle cx="195" cy="60" r="4" fill="#fde047"/>
      <circle cx="185" cy="175" r="2.5" fill="#fde047"/>`;
  } else {
    bgDefs = `<linearGradient id="avBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#10b981"/>
      <stop offset="100%" stop-color="#064e3b"/>
    </linearGradient>`;
    bgRect = `<rect width="240" height="240" rx="120" fill="url(#avBg)"/>`;
  }

  // Back hair layer for long female hairstyles
  let backHairSvg = '';
  if (
    config.hairStyle === 'long-waves' ||
    (isFemale &&
      (config.hairStyle === 'snapback' ||
        config.hairStyle === 'beanie' ||
        config.hairStyle === 'bucket'))
  ) {
    backHairSvg = `
      <path d="M66,95 C52,135 54,182 68,205 L92,205 L85,110 Z" fill="${config.hairColor}"/>
      <path d="M174,95 C188,135 186,182 172,205 L148,205 L155,110 Z" fill="${config.hairColor}"/>
    `;
  } else if (config.hairStyle === 'ponytail') {
    backHairSvg = `
      <circle cx="120" cy="40" r="24" fill="${config.hairColor}"/>
      <path d="M120,38 Q168,38 178,108 Q154,96 144,64 Z" fill="${config.hairColor}"/>
    `;
  } else if (config.hairStyle === 'space-buns') {
    backHairSvg = `
      <circle cx="72" cy="54" r="24" fill="${config.hairColor}" stroke="#facc15" stroke-width="2.5"/>
      <circle cx="168" cy="54" r="24" fill="${config.hairColor}" stroke="#facc15" stroke-width="2.5"/>
    `;
  }

  // Outfit SVG layer (Male has broader shoulder silhouette)
  const shoulderLeft = isFemale ? 48 : 38;
  const shoulderRight = isFemale ? 192 : 202;
  let outfitSvg = '';
  if (config.outfit === 'lv-hoodie') {
    outfitSvg = `
      <path d="M${shoulderLeft},240 C${shoulderLeft},172 80,164 120,164 C160,164 ${shoulderRight},172 ${shoulderRight},240 Z" fill="${config.outfitColor}" stroke="#ffffff" stroke-width="3"/>
      <path d="M85,168 Q120,196 155,168" fill="none" stroke="#fde047" stroke-width="4"/>
      <text x="120" y="218" text-anchor="middle" font-family="Georgia, serif" font-weight="900" font-size="26" fill="#fde047">LV</text>
    `;
  } else if (config.outfit === 'bomber') {
    outfitSvg = `
      <path d="M${shoulderLeft - 2},240 C${shoulderLeft - 2},170 78,163 120,163 C162,163 ${shoulderRight + 2},170 ${shoulderRight + 2},240 Z" fill="${config.outfitColor}" stroke="#18181b" stroke-width="3"/>
      <rect x="114" y="168" width="12" height="72" fill="#27272a"/>
      <path d="M88,166 L120,192 L152,166" fill="none" stroke="#ffffff" stroke-width="4"/>
    `;
  } else if (config.outfit === 'track-jacket') {
    outfitSvg = `
      <path d="M${shoulderLeft},240 C${shoulderLeft},172 80,164 120,164 C160,164 ${shoulderRight},172 ${shoulderRight},240 Z" fill="${config.outfitColor}"/>
      <line x1="72" y1="175" x2="62" y2="240" stroke="#00f5d4" stroke-width="6"/>
      <line x1="168" y1="175" x2="178" y2="240" stroke="#00f5d4" stroke-width="6"/>
      <line x1="120" y1="168" x2="120" y2="240" stroke="#ffffff" stroke-width="3"/>
    `;
  } else if (config.outfit === 'gold-chain') {
    outfitSvg = `
      <path d="M${shoulderLeft},240 C${shoulderLeft},172 80,164 120,164 C160,164 ${shoulderRight},172 ${shoulderRight},240 Z" fill="#111827"/>
      <path d="M88,172 Q120,214 152,172" fill="none" stroke="#facc15" stroke-width="7" stroke-dasharray="8,3"/>
      <circle cx="120" cy="204" r="9" fill="#facc15" stroke="#ca8a04" stroke-width="2"/>
    `;
  } else {
    outfitSvg = `
      <path d="M${shoulderLeft},240 C${shoulderLeft},172 80,164 120,164 C160,164 ${shoulderRight},172 ${shoulderRight},240 Z" fill="${config.outfitColor}"/>
      <text x="120" y="216" text-anchor="middle" font-family="Outfit, sans-serif" font-weight="900" font-size="18" fill="#ffffff">COLORVERSE</text>
    `;
  }

  // Expression / Mouth SVG (Female has fuller lip accent, Male has clean smirk/smile + subtle chin contour)
  let mouthSvg = '';
  if (config.expression === 'smile') {
    mouthSvg = isFemale
      ? `<path d="M102,141 Q120,157 138,141 Z" fill="#ffffff" stroke="#e11d48" stroke-width="3"/>`
      : `<path d="M102,142 Q120,156 138,142 Z" fill="#ffffff" stroke="#18181b" stroke-width="2.5"/>`;
  } else if (config.expression === 'wink') {
    mouthSvg = isFemale
      ? `<path d="M105,143 Q122,153 136,139" fill="none" stroke="#be185d" stroke-width="4" stroke-linecap="round"/>`
      : `<path d="M106,144 Q122,154 136,140" fill="none" stroke="#18181b" stroke-width="3.5" stroke-linecap="round"/>`;
  } else if (config.expression === 'chill') {
    mouthSvg = isFemale
      ? `<path d="M107,144 Q120,147 133,144" fill="none" stroke="#be185d" stroke-width="4" stroke-linecap="round"/>`
      : `<line x1="106" y1="145" x2="134" y2="145" stroke="#18181b" stroke-width="3.5" stroke-linecap="round"/>`;
  } else if (config.expression === 'bubblegum') {
    mouthSvg = `<circle cx="132" cy="145" r="14" fill="#f472b6" stroke="#db2777" stroke-width="2.5" opacity="0.92"/>
      <circle cx="127" cy="140" r="4" fill="#ffffff" opacity="0.7"/>`;
  } else {
    // smirk
    mouthSvg = isFemale
      ? `<path d="M105,144 Q123,149 138,137" fill="none" stroke="#be185d" stroke-width="4" stroke-linecap="round"/>`
      : `<path d="M106,145 Q124,148 138,137" fill="none" stroke="#18181b" stroke-width="3.5" stroke-linecap="round"/>`;
  }

  // Male subtle chin shadow / goatee accent vs Female cheek blush
  const genderFaceAccentSvg = isFemale
    ? `<ellipse cx="88" cy="128" rx="8" ry="4.5" fill="#fb7185" opacity="0.35"/>
       <ellipse cx="152" cy="128" rx="8" ry="4.5" fill="#fb7185" opacity="0.35"/>`
    : `<path d="M112,157 Q120,161 128,157" fill="none" stroke="${config.hairColor}" stroke-width="3.5" stroke-linecap="round" opacity="0.65"/>`;

  // Eyes (with eyelashes for Female)
  const lashesSvg = isFemale
    ? `<path d="M91,109 L86,104 M95,107 L92,101 M149,109 L154,104 M145,107 L148,101" stroke="#18181b" stroke-width="2.2" stroke-linecap="round"/>`
    : '';
  const leftEyeSvg =
    config.expression === 'wink'
      ? `<path d="M90,114 Q99,107 108,114" fill="none" stroke="#18181b" stroke-width="3.5" stroke-linecap="round"/>`
      : `<circle cx="99" cy="113" r="6" fill="#18181b"/><circle cx="97" cy="111" r="2" fill="#ffffff"/>`;
  const rightEyeSvg = `<circle cx="141" cy="113" r="6" fill="#18181b"/><circle cx="139" cy="111" r="2" fill="#ffffff"/>`;

  // Eyewear SVG
  let eyewearSvg = '';
  if (config.eyewear === 'lv-shades') {
    eyewearSvg = `
      <rect x="78" y="99" width="38" height="24" rx="6" fill="#09090b" stroke="#facc15" stroke-width="3"/>
      <rect x="124" y="99" width="38" height="24" rx="6" fill="#09090b" stroke="#facc15" stroke-width="3"/>
      <line x1="116" y1="108" x2="124" y2="108" stroke="#facc15" stroke-width="3"/>
      <text x="97" y="115" text-anchor="middle" font-family="Georgia, serif" font-weight="900" font-size="10" fill="#facc15">LV</text>
    `;
  } else if (config.eyewear === 'cyber-visor') {
    eyewearSvg = `
      <path d="M74,98 L166,98 L160,122 L80,122 Z" fill="#00f5d4" opacity="0.85" stroke="#ffffff" stroke-width="2.5"/>
      <line x1="84" y1="104" x2="156" y2="104" stroke="#ffffff" stroke-width="2"/>
    `;
  } else if (config.eyewear === 'star-glasses') {
    eyewearSvg = `
      <polygon points="98,92 103,104 116,104 105,112 109,124 98,116 87,124 91,112 80,104 93,104" fill="#ec4899" stroke="#ffffff" stroke-width="2"/>
      <polygon points="142,92 147,104 160,104 149,112 153,124 142,116 131,124 135,112 124,104 137,104" fill="#ec4899" stroke="#ffffff" stroke-width="2"/>
      <line x1="112" y1="108" x2="128" y2="108" stroke="#ffffff" stroke-width="2.5"/>
    `;
  } else if (config.eyewear === 'round-gold') {
    eyewearSvg = `
      <circle cx="98" cy="112" r="15" fill="rgba(24,24,27,0.45)" stroke="#facc15" stroke-width="3"/>
      <circle cx="142" cy="112" r="15" fill="rgba(24,24,27,0.45)" stroke="#facc15" stroke-width="3"/>
      <line x1="113" y1="112" x2="127" y2="112" stroke="#facc15" stroke-width="3"/>
    `;
  }

  // Hair & Hat SVG
  let hairAndHatSvg = '';
  if (config.hairStyle === 'snapback') {
    hairAndHatSvg = `
      <path d="M72,94 C64,105 66,122 74,126" fill="none" stroke="${config.hairColor}" stroke-width="10" stroke-linecap="round"/>
      <path d="M168,94 C176,105 174,122 166,126" fill="none" stroke="${config.hairColor}" stroke-width="10" stroke-linecap="round"/>
      <path d="M72,92 C72,48 168,48 168,92 Z" fill="${config.hatColor}" stroke="#ffffff" stroke-width="2.5"/>
      <rect x="64" y="84" width="124" height="14" rx="7" fill="${config.hatColor}" stroke="#18181b" stroke-width="2.5"/>
      <text x="120" y="77" text-anchor="middle" font-family="Georgia, serif" font-weight="900" font-size="16" fill="#ffffff">LV</text>
    `;
  } else if (config.hairStyle === 'beanie') {
    hairAndHatSvg = `
      <path d="M70,98 C65,112 68,128 75,134" fill="none" stroke="${config.hairColor}" stroke-width="9" stroke-linecap="round"/>
      <path d="M170,98 C175,112 172,128 165,134" fill="none" stroke="${config.hairColor}" stroke-width="9" stroke-linecap="round"/>
      <path d="M72,94 C72,42 168,42 168,94 Z" fill="${config.hatColor}"/>
      <rect x="68" y="80" width="104" height="20" rx="8" fill="${config.hatColor}" stroke="#ffffff" stroke-width="2.5"/>
      <rect x="104" y="85" width="32" height="10" rx="3" fill="#18181b"/>
    `;
  } else if (config.hairStyle === 'locs') {
    hairAndHatSvg = `
      <path d="M72,88 C72,50 168,50 168,88 Z" fill="${config.hairColor}"/>
      <rect x="64" y="78" width="14" height="72" rx="7" fill="${config.hairColor}" stroke="#09090b" stroke-width="1.5"/>
      <rect x="76" y="72" width="14" height="78" rx="7" fill="${config.hairColor}" stroke="#09090b" stroke-width="1.5"/>
      <rect x="150" y="72" width="14" height="78" rx="7" fill="${config.hairColor}" stroke="#09090b" stroke-width="1.5"/>
      <rect x="162" y="78" width="14" height="72" rx="7" fill="${config.hairColor}" stroke="#09090b" stroke-width="1.5"/>
      <rect x="64" y="115" width="14" height="5" fill="#facc15"/>
      <rect x="162" y="115" width="14" height="5" fill="#facc15"/>
    `;
  } else if (config.hairStyle === 'spiky') {
    hairAndHatSvg = `
      <polygon points="65,95 55,62 88,74 82,42 114,66 125,36 142,66 170,46 160,78 188,68 172,98" fill="${config.hairColor}" stroke="#18181b" stroke-width="2"/>
    `;
  } else if (config.hairStyle === 'bucket') {
    hairAndHatSvg = `
      <path d="M76,88 L84,54 L156,54 L164,88 Z" fill="${config.hatColor}" stroke="#ffffff" stroke-width="2"/>
      <path d="M56,94 Q120,78 184,94 L176,104 Q120,90 64,104 Z" fill="${config.hatColor}" stroke="#ffffff" stroke-width="2"/>
    `;
  } else if (config.hairStyle === 'afro') {
    hairAndHatSvg = `
      <circle cx="82" cy="78" r="28" fill="${config.hairColor}"/>
      <circle cx="120" cy="64" r="34" fill="${config.hairColor}"/>
      <circle cx="158" cy="78" r="28" fill="${config.hairColor}"/>
      <circle cx="70" cy="102" r="22" fill="${config.hairColor}"/>
      <circle cx="170" cy="102" r="22" fill="${config.hairColor}"/>
    `;
  } else if (config.hairStyle === 'long-waves') {
    hairAndHatSvg = `
      <path d="M72,96 C72,46 168,46 168,96 C148,74 92,74 72,96 Z" fill="${config.hairColor}"/>
    `;
  } else if (config.hairStyle === 'space-buns' || config.hairStyle === 'ponytail') {
    hairAndHatSvg = `
      <path d="M74,94 C74,52 166,52 166,94 C146,78 94,78 74,94 Z" fill="${config.hairColor}"/>
    `;
  } else {
    // waves / fade
    hairAndHatSvg = `
      <path d="M72,96 C72,54 168,54 168,96 C152,86 88,86 72,96 Z" fill="${config.hairColor}"/>
      <path d="M84,72 Q120,62 156,72" fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="3" stroke-linecap="round"/>
    `;
  }

  // Head shape & Earrings (Female: softer rounded face + gold hoops; Male: angular jaw + diamond studs)
  const headShapeSvg = isFemale
    ? `<rect x="75" y="68" width="90" height="94" rx="45" fill="${config.skinTone}"/>`
    : `<path d="M74,76 C74,66 166,66 166,76 L163,134 L140,162 L100,162 L77,134 Z" fill="${config.skinTone}"/>`;

  const earringsSvg = isFemale
    ? `<circle cx="68" cy="126" r="7" fill="none" stroke="#facc15" stroke-width="2.8"/>
       <circle cx="172" cy="126" r="7" fill="none" stroke="#facc15" stroke-width="2.8"/>`
    : `<circle cx="70" cy="122" r="4" fill="#e0f2fe" stroke="#38bdf8" stroke-width="1.5"/>
       <circle cx="170" cy="122" r="4" fill="#e0f2fe" stroke="#38bdf8" stroke-width="1.5"/>`;

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 240">
    <defs>${bgDefs}</defs>
    ${bgRect}
    <!-- Back Hair Layer -->
    ${backHairSvg}
    <!-- Neck -->
    <rect x="${isFemale ? 105 : 100}" y="148" width="${isFemale ? 30 : 40}" height="32" rx="10" fill="${config.skinTone}"/>
    <!-- Streetwear Outfit -->
    ${outfitSvg}
    <!-- Ears & Earrings -->
    <circle cx="72" cy="116" r="10" fill="${config.skinTone}"/>
    <circle cx="168" cy="116" r="10" fill="${config.skinTone}"/>
    ${earringsSvg}
    <!-- Head -->
    ${headShapeSvg}
    <!-- Eyebrows -->
    <path d="M88,98 Q99,93 108,97" fill="none" stroke="${config.hairColor}" stroke-width="${isFemale ? '3' : '4.5'}" stroke-linecap="round"/>
    <path d="M132,97 Q141,93 152,98" fill="none" stroke="${config.hairColor}" stroke-width="${isFemale ? '3' : '4.5'}" stroke-linecap="round"/>
    <!-- Eyes & Lashes -->
    ${lashesSvg}
    ${leftEyeSvg}
    ${rightEyeSvg}
    <!-- Nose -->
    <path d="M120,114 L116,128 L124,129" fill="none" stroke="rgba(0,0,0,0.28)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
    <!-- Cheek / Chin Accent -->
    ${genderFaceAccentSvg}
    <!-- Mouth / Expression -->
    ${mouthSvg}
    <!-- Eyewear -->
    ${eyewearSvg}
    <!-- Hair & Hat -->
    ${hairAndHatSvg}
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export interface PresetProfileSong {
  id: string;
  title: string;
  freq: number;
  durationSec: number;
}

export const PRESET_PROFILE_SONGS: PresetProfileSong[] = [
  {
    id: 'song-lv-anthem',
    title: 'Rainbow LV Streetwear Anthem (808 Drop)',
    freq: 110,
    durationSec: 8,
  },
  {
    id: 'song-neon-cruise',
    title: 'Midnight Neon Skatepark Cruise',
    freq: 130.81,
    durationSec: 8,
  },
  {
    id: 'song-cloud-vibes',
    title: 'Dreamy Colorverse Cloud Synth',
    freq: 146.83,
    durationSec: 8,
  },
  {
    id: 'song-emerald-bounce',
    title: 'Emerald City West Coast Bounce',
    freq: 98,
    durationSec: 8,
  },
  {
    id: 'song-cyber-star',
    title: 'Cyber Tomboy Hyperpop Melody',
    freq: 164.81,
    durationSec: 8,
  },
];

// Create default avatars and story thumbnails
export function createAvatarSvg(name: string, bgHex: string): string {
  const initials = (name || 'TC').slice(0, 2).toUpperCase();
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120">
    <defs>
      <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${bgHex}"/>
        <stop offset="100%" stop-color="#111827"/>
      </linearGradient>
    </defs>
    <rect width="120" height="120" rx="60" fill="url(#g)"/>
    <text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle" font-family="Outfit, sans-serif" font-weight="800" font-size="44" fill="#ffffff">${initials}</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function getInitialSeedData(): {
  accounts: UserAccount[];
  posts: FeedPost[];
  stories: StoryReel[];
} {
  const beat1 = createSynthBeatWavUrl(110, 6);
  const beat2 = createSynthBeatWavUrl(146, 6);
  const beat3 = createSynthBeatWavUrl(98, 6);

  const queenAvatarConfig: AvatarCustomizationConfig = {
    ...DEFAULT_AVATAR_CONFIG,
    skinTone: '#e0a96d',
    hairStyle: 'snapback',
    hatColor: '#ec4899',
    eyewear: 'lv-shades',
    outfit: 'lv-hoodie',
    outfitColor: '#9333ea',
    expression: 'smirk',
    bgStyle: 'rainbow',
  };

  const guestAvatarConfig: AvatarCustomizationConfig = {
    ...DEFAULT_AVATAR_CONFIG,
    skinTone: '#c68642',
    hairStyle: 'beanie',
    hatColor: '#06b6d4',
    eyewear: 'cyber-visor',
    outfit: 'track-jacket',
    outfitColor: '#18181b',
    expression: 'smile',
    bgStyle: 'cyber-cyan',
  };

  const SEED_BASE_TIME = 1700000000000;

  const guestAccount: UserAccount = {
    id: 'user-guest',
    username: 'ColorverseQueen',
    password: '123',
    avatar: renderCustomAvatarSvg(queenAvatarConfig),
    avatarConfig: queenAvatarConfig,
    bio: 'Rainbow LV Creator • Music, Reels & Streetwear Drip 🌈👑',
    wallpaperMode: 'lv-light',
    profileSongUrl: beat1,
    profileSongTitle: 'Rainbow LV Streetwear Anthem (808 Drop)',
    createdAt: SEED_BASE_TIME - 86400000,
    updatedAt: 0,
    isSeed: true,
  };

  const skaterAccount: UserAccount = {
    id: 'user-skater',
    username: 'Guest',
    password: '123',
    avatar: renderCustomAvatarSvg(guestAvatarConfig),
    avatarConfig: guestAvatarConfig,
    bio: '90s Skate & Neon Beats',
    wallpaperMode: 'lv-dark',
    profileSongUrl: beat2,
    profileSongTitle: 'Dreamy Colorverse Cloud Synth',
    createdAt: SEED_BASE_TIME - 72000000,
    updatedAt: 0,
    isSeed: true,
  };

  const stories: StoryReel[] = [
    {
      id: 'story-1',
      authorId: 'user-skater',
      authorName: 'Guest',
      authorAvatar: createAvatarSvg('G1', '#10b981'),
      mediaType: 'video',
      mediaUrl: generateAIArtworkDataUrl('Neon Streetwear Gift Hoodie Drip', '9:16'),
      audioUrl: beat1,
      caption: 'Holiday Streetwear Drop 🔥 Tap for full reel!',
      likes: ['user-guest'],
      createdAt: SEED_BASE_TIME - 14400000,
      updatedAt: 0,
      isSeed: true,
      beatFreq: 110,
    },
    {
      id: 'story-2',
      authorId: 'user-skater',
      authorName: 'Guest',
      authorAvatar: createAvatarSvg('G2', '#f59e0b'),
      mediaType: 'video',
      mediaUrl: generateAIArtworkDataUrl('Tuxedo Cat Gang Streetwear Squad', '9:16'),
      audioUrl: beat2,
      caption: 'Squad Goals in Full Color 🐾✨',
      likes: [],
      createdAt: SEED_BASE_TIME - 10800000,
      updatedAt: 0,
      isSeed: true,
      beatFreq: 146,
    },
    {
      id: 'story-3',
      authorId: 'user-guest',
      authorName: 'Guest',
      authorAvatar: createAvatarSvg('G3', '#3b82f6'),
      mediaType: 'image',
      mediaUrl: generateAIArtworkDataUrl('Rainbow Polka Dot Drip Fit Check', '9:16'),
      audioUrl: beat3,
      caption: 'Rainbow LV Fit Check 🌈💎',
      likes: ['user-skater'],
      createdAt: SEED_BASE_TIME - 7200000,
      updatedAt: 0,
      isSeed: true,
      beatFreq: 98,
    },
    {
      id: 'story-4',
      authorId: 'user-guest',
      authorName: 'Guest',
      authorAvatar: createAvatarSvg('G4', '#a855f7'),
      mediaType: 'video',
      mediaUrl: generateAIArtworkDataUrl('Cyberpunk Neon Alley Late Night Vibe', '9:16'),
      audioUrl: beat1,
      caption: 'Late Night Neon Vibes 🌃🎵',
      likes: ['user-skater'],
      createdAt: SEED_BASE_TIME - 3600000,
      updatedAt: 0,
      isSeed: true,
      beatFreq: 130,
    },
  ];

  const posts: FeedPost[] = [
    {
      id: 'post-1',
      authorId: 'user-guest',
      authorName: 'ColorverseQueen',
      authorAvatar: guestAccount.avatar,
      type: 'image',
      title: 'POWERPUFF GIRL GANG',
      mediaUrl: generatePowerpuffVanCardUrl(),
      audioUrl: beat2,
      likes: ['user-skater'],
      comments: [
        {
          id: 'c-1',
          authorId: 'user-skater',
          authorName: 'Guest',
          authorAvatar: skaterAccount.avatar,
          text: 'This van artwork goes crazy hard!! 🔥🌈',
          createdAt: SEED_BASE_TIME - 500000,
        },
      ],
      createdAt: SEED_BASE_TIME - 7200000,
      updatedAt: 0,
      isSeed: true,
      beatFreq: 146,
    },
    {
      id: 'post-2',
      authorId: 'user-guest',
      authorName: 'ColorverseQueen',
      authorAvatar: guestAccount.avatar,
      type: 'video',
      title: 'COLORVERSE SYNTH REEL',
      mediaUrl: generateAIArtworkDataUrl('Midnight Neon Bass Drop Reel', '3:4'),
      audioUrl: beat1,
      likes: ['user-guest', 'user-skater'],
      comments: [],
      createdAt: SEED_BASE_TIME - 5400000,
      updatedAt: 0,
      isSeed: true,
      beatFreq: 110,
    },
    {
      id: 'post-3',
      authorId: 'user-guest',
      authorName: 'ColorverseQueen',
      authorAvatar: guestAccount.avatar,
      type: 'drawing',
      title: 'N 💖 M',
      mediaUrl: generateNeonHeartDrawingUrl(),
      audioUrl: beat3,
      likes: ['user-skater'],
      comments: [],
      createdAt: SEED_BASE_TIME - 3600000,
      updatedAt: 0,
      isSeed: true,
      beatFreq: 130,
    },
    {
      id: 'post-4',
      authorId: 'user-skater',
      authorName: 'Guest',
      authorAvatar: skaterAccount.avatar,
      type: 'music',
      title: 'RAINBOW LV BASSLINE 808',
      mediaUrl: generateAIArtworkDataUrl('Golden Lights Streetwear Anthem', '3:4'),
      audioUrl: beat2,
      likes: ['user-guest'],
      comments: [],
      createdAt: SEED_BASE_TIME - 1800000,
      updatedAt: 0,
      isSeed: true,
      beatFreq: 164,
    },
  ];

  return {
    accounts: [guestAccount, skaterAccount],
    posts,
    stories,
  };
}
