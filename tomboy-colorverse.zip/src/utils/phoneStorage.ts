import { FeedPost, StoryReel, UserAccount, ChatMessage } from '../types';

const DB_NAME = 'TomboyColorversePhoneDB';
const DB_VERSION = 1;
const CACHE_NAME = 'tomboy-colorverse-phone-cache-v1';

let cachedDbPromise: Promise<IDBDatabase> | null = null;

// Ask mobile browser (iOS Safari / Android Chrome) to mark phone storage as persistent
if (typeof window !== 'undefined' && navigator.storage && navigator.storage.persist) {
  navigator.storage.persist().catch(() => {});
}

function openDB(): Promise<IDBDatabase> {
  if (cachedDbPromise) return cachedDbPromise;
  cachedDbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('kv')) {
        db.createObjectStore('kv');
      }
    };
    req.onsuccess = () => {
      const db = req.result;
      db.onclose = () => {
        cachedDbPromise = null;
      };
      resolve(db);
    };
    req.onerror = () => {
      cachedDbPromise = null;
      reject(req.error);
    };
  });
  return cachedDbPromise;
}

/**
 * Creates a quota-safe version of a value for localStorage fallback ONLY when
 * the raw value exceeds localStorage's 5MB limit (e.g. multiple 8MB MP3 files).
 * Full binary Data URLs are always stored intact in IndexedDB, Cache Storage, and the server backup.
 */
function makeLocalStorageSafeCopy<T>(key: string, value: T): T {
  if (key === 'accounts' && Array.isArray(value)) {
    return value.map((acc: any) => ({
      ...acc,
      profileSongUrl:
        typeof acc?.profileSongUrl === 'string' && acc.profileSongUrl.length > 150000
          ? undefined
          : acc?.profileSongUrl,
      customWallpaperUrl:
        typeof acc?.customWallpaperUrl === 'string' && acc.customWallpaperUrl.length > 250000
          ? undefined
          : acc?.customWallpaperUrl,
    })) as unknown as T;
  }
  if (key === 'posts' && Array.isArray(value)) {
    return value.map((post: any) => ({
      ...post,
      audioUrl:
        typeof post?.audioUrl === 'string' && post.audioUrl.length > 150000
          ? undefined
          : post?.audioUrl,
      mediaUrl:
        typeof post?.mediaUrl === 'string' && post.mediaUrl.length > 450000
          ? undefined
          : post?.mediaUrl,
    })) as unknown as T;
  }
  return value;
}

export function getInstantPhoneStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(`tcv_${key}`);
    if (raw !== null) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(fallback) && !Array.isArray(parsed)) {
        return fallback;
      }
      return parsed as T;
    }
  } catch {
    // Ignore parse error
  }
  return fallback;
}

export async function saveToPhoneStorage<T>(key: string, value: T): Promise<void> {
  // 1. Save full data (including large MP3s, videos, avatars, wallpapers) to IndexedDB Phone Storage
  try {
    const db = await openDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('kv', 'readwrite');
      const store = tx.objectStore('kv');
      store.put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // Continue to Cache Storage & localStorage below
  }

  // 2. Also save to Service Worker Cache Storage (supports large binary/JSON payloads on iOS/Android)
  if (typeof window !== 'undefined' && 'caches' in window) {
    try {
      const cache = await window.caches.open(CACHE_NAME);
      const response = new Response(JSON.stringify({ value, savedAt: Date.now() }), {
        headers: { 'Content-Type': 'application/json' },
      });
      await cache.put(`/__phone_storage__/${key}`, response);
    } catch {
      // Continue to localStorage mirror below
    }
  }

  // 3. Mirror to localStorage for instant synchronous startup; never delete the key on QuotaExceededError
  try {
    const serialized = JSON.stringify(value);
    localStorage.setItem(`tcv_${key}`, serialized);
    localStorage.setItem('tcv_lastSavedAt', String(Date.now()));
  } catch {
    try {
      const compactCopy = makeLocalStorageSafeCopy(key, value);
      localStorage.setItem(`tcv_${key}`, JSON.stringify(compactCopy));
      localStorage.setItem('tcv_lastSavedAt', String(Date.now()));
    } catch {
      // Keep existing localStorage entry if even compact copy exceeds quota
    }
  }
}

/**
 * Loads raw saved value from IndexedDB, Cache Storage, or localStorage.
 * Returns `undefined` if this key has NOT been saved locally (so callers never mistake seed fallbacks for real local data).
 */
export async function loadRawPhoneStorage<T>(key: string): Promise<T | undefined> {
  // 1. Try IndexedDB first
  try {
    const db = await openDB();
    const result = await new Promise<T | undefined>((resolve, reject) => {
      const tx = db.transaction('kv', 'readonly');
      const store = tx.objectStore('kv');
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result as T | undefined);
      req.onerror = () => reject(req.error);
    });
    if (result !== undefined) {
      return result;
    }
  } catch {
    // Fallback to Cache Storage below
  }

  // 2. Try Cache Storage second
  if (typeof window !== 'undefined' && 'caches' in window) {
    try {
      const cache = await window.caches.open(CACHE_NAME);
      const match = await cache.match(`/__phone_storage__/${key}`);
      if (match) {
        const parsed = await match.json();
        if (parsed && parsed.value !== undefined) {
          return parsed.value as T;
        }
      }
    } catch {
      // Fallback to localStorage below
    }
  }

  // 3. Try localStorage third
  try {
    const raw = localStorage.getItem(`tcv_${key}`);
    if (raw !== null) {
      return JSON.parse(raw) as T;
    }
  } catch {
    // Ignore parse error
  }

  return undefined;
}

export async function loadFromPhoneStorage<T>(key: string, fallback: T): Promise<T> {
  const raw = await loadRawPhoneStorage<T>(key);
  return raw !== undefined ? raw : fallback;
}

export interface FullPhoneStorageSnapshot {
  accounts: UserAccount[];
  currentUserId: string | null;
  explicitlyLoggedOut?: boolean;
  explicitAccountSwitch?: boolean;
  feedFilter: string;
  posts: FeedPost[];
  stories: StoryReel[];
  messages: ChatMessage[];
  deletedIds: string[];
}

export async function flushAllToPhoneStorage(
  snapshot: FullPhoneStorageSnapshot,
  useBeacon = false
): Promise<void> {
  await Promise.all([
    saveToPhoneStorage('accounts', snapshot.accounts),
    saveToPhoneStorage('currentUserId', snapshot.currentUserId),
    saveToPhoneStorage('explicitlyLoggedOut', Boolean(snapshot.explicitlyLoggedOut)),
    saveToPhoneStorage('feedFilter', snapshot.feedFilter),
    saveToPhoneStorage('posts', snapshot.posts),
    saveToPhoneStorage('stories', snapshot.stories),
    saveToPhoneStorage('messages', snapshot.messages),
    saveToPhoneStorage('deletedIds', snapshot.deletedIds),
  ]);

  const payload = JSON.stringify({
    accounts: snapshot.accounts,
    currentUserId: snapshot.currentUserId,
    explicitlyLoggedOut: Boolean(snapshot.explicitlyLoggedOut),
    explicitAccountSwitch: Boolean(snapshot.explicitAccountSwitch),
    feedFilter: snapshot.feedFilter,
    posts: snapshot.posts,
    stories: snapshot.stories,
    messages: snapshot.messages,
    deletedIds: snapshot.deletedIds,
  });

  if (useBeacon && typeof navigator !== 'undefined' && navigator.sendBeacon) {
    try {
      const blob = new Blob([payload], { type: 'application/json' });
      navigator.sendBeacon('/api/community/sync', blob);
      return;
    } catch {
      // Fall through to fetch
    }
  }

  try {
    await fetch('/api/community/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: payload,
      keepalive: true,
    });
  } catch {
    // Offline phone storage already succeeded
  }
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}
